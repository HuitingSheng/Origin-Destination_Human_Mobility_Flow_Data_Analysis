/*Gaussian model for links

	Author:	Jason Wyse, 
			School of Computer Science and Statistics,
			Trinity College Dublin,
			Dublin 2, Ireland.
			email: wyseja@tcd.ie
			
Last modified: Fri 24 Jul 2015 02:59:16 PM IST   */


#include "Gaussian_Gamma_model.h"

struct model *set_up_Gaussian_Gamma_model()
{
	struct model *model = malloc(sizeof(struct model));
	model->create_hyperparameters = &Gaussian_Gamma_create_hyperparameters;
	model->destroy_hyperparameters = &Gaussian_Gamma_destroy_hyperparameters;
	model->set_hyperparameters = &Gaussian_Gamma_set_hyperparameters;
	model->create_new_block = &Gaussian_Gamma_create_new_block;
	model->destroy_block = &Gaussian_Gamma_destroy_block;
	model->copy_block = &Gaussian_Gamma_copy_block;
	model->add_to_stats = &Gaussian_Gamma_add_to_stats;
	model->reset_stats = &Gaussian_Gamma_reset_stats;
	model->add_block_stats = &Gaussian_Gamma_add_block_stats;
	model->compare_stats = &Gaussian_Gamma_compare_stats;
	model->compute_log_marginal_likelihood_from_stats = &Gaussian_Gamma_compute_log_marginal_likelihood_from_stats;
	//model->print_stats = &Gaussian_Gamma_print_stats;
	model->dimensions = calloc(2,sizeof(int));
	
	//this is just a dummy to distract the program (fix later)
	//model->set_up_hyperparameter_sampling = &Multivariate_Gaussian_Gamma_set_up_hyperparameter_sampling;
	//model->destroy_hyperparameter_sampling = &Multivariate_Gaussian_Gamma_destroy_hyperparameter_sampling;
	//model->sample_hyperparameters = &Multivariate_Gaussian_Gamma_sample_hyperparameters;
	
	return(model);
}

void tidy_up_Gaussian_Gamma_model(struct model *model)
{
	free(model->dimensions);
	return;
}

void Gaussian_Gamma_create_hyperparameters(struct model *model)
{
	struct Gaussian_Gamma_hyper * hyper = malloc( sizeof( struct Gaussian_Gamma_hyper ) );
	model->hyperparameters = (void *)hyper;
	return;
}

void Gaussian_Gamma_destroy_hyperparameters(void *hyper)
{
	struct Gaussian_Gamma_hyper * h = (struct Gaussian_Gamma_hyper *) hyper ;
	free(h);
	return; 
}

void Gaussian_Gamma_set_hyperparameters(struct model *model,double *model_hyperparameters)
{
	int i;
	
	//				   [0] - kappa for prior on block mean
	//				   [1] - delta for twice rate on precision
	//				   [2] - gamma for twice shape on precision
	//				   [3] - prior mean on block mean
	
	struct Gaussian_Gamma_hyper * h = (struct Gaussian_Gamma_hyper *)model->hyperparameters;
	
	h->kappa = model_hyperparameters[1];
	h->delta = model_hyperparameters[2];
	h->gamma = model_hyperparameters[3];
	h->xi = model_hyperparameters[4];
	return;
}

struct block * Gaussian_Gamma_create_new_block(int *dimensions)
{
	struct block *block = malloc(sizeof(struct block));
	block->stats = (void *)Gaussian_Gamma_create_stats( dimensions[0] );
	
	block->log_marginal_likelihood = -DBL_MAX;
	return(block);
}

void Gaussian_Gamma_destroy_block(struct block *block)
{
	Gaussian_Gamma_destroy_stats(block->stats);
	free(block);
	return;
}

struct Gaussian_Gamma_stats *Gaussian_Gamma_create_stats(int dim)
{
	struct Gaussian_Gamma_stats *stats = malloc(sizeof(struct Gaussian_Gamma_stats));
	stats->n = 0;
	stats->sum = 0.;
	stats->sum_sq = 0.;
	return(stats);
}

void Gaussian_Gamma_destroy_stats(void *stats)
{
	struct Gaussian_Gamma_stats *s = (struct Gaussian_Gamma_stats *)stats;
	free(s);
	return;
}

void Gaussian_Gamma_copy_block(struct block *source,struct block *target)
{
	struct Gaussian_Gamma_stats *s = (struct Gaussian_Gamma_stats *)source->stats,
						  *t = (struct Gaussian_Gamma_stats *)target->stats;
	
	int i;
	t->n = s->n;
	t->sum = s->sum;
	t->sum_sq = s->sum_sq;
	target->log_marginal_likelihood = source->log_marginal_likelihood;
	return;
}

void Gaussian_Gamma_add_to_stats(double x,void *stats,int add)
{
	double sgn = (add == 1) ? 1. : -1.;
	struct Gaussian_Gamma_stats *s = (struct Gaussian_Gamma_stats *)stats;
	s->n += add;
	s->sum += sgn*x;
	s->sum_sq += sgn*x*x;
	return;
}

void Gaussian_Gamma_add_zeros_to_stats(int n,void *stats,int add)
{
	double sgn = (add == 1) ? 1.:-1.;
	struct Gaussian_Gamma_stats *s = (struct Gaussian_Gamma_stats *)stats;
	s->n += add*n;
	return;
}

void Gaussian_Gamma_reset_stats(void *stats)
{
	int i;
	struct Gaussian_Gamma_stats *s = (struct Gaussian_Gamma_stats *)stats;
	s->n = 0;
	s->sum = 0.;
	s->sum_sq = 0.;
}

double Gaussian_Gamma_compute_log_marginal_likelihood_from_stats(void *stats,void *hyperparams)
{
	double l=0.,x;
	struct Gaussian_Gamma_stats *s = (struct Gaussian_Gamma_stats *)stats;
	struct Gaussian_Gamma_hyper *h = (struct Gaussian_Gamma_hyper *)hyperparams;
	x = s->sum_sq + h->kappa * h->xi * h->xi
		- ( s->sum + h->kappa * h->xi ) * ( s->sum + h->kappa * h->xi ) / ( s->n+ h->kappa ) + h->delta ;
	l = -.5*s->n*M_LNPI + .5*( log( h->kappa )
		+ h->gamma * log( h->delta ) ) 
		+ lgamma(.5*( s->n + h->gamma )) 
		- lgamma(.5* h->gamma)
		-.5*( s->n + h->gamma )*log(x);
	return(l);
}

void Gaussian_Gamma_add_block_stats(void *stats_source,void *stats_target)
{
	int i;
	struct Gaussian_Gamma_stats *src = (struct Gaussian_Gamma_stats *)stats_source, *trgt = (struct Gaussian_Gamma_stats *)stats_target;
	trgt->n += src->n;
	trgt->sum += src->sum;
	trgt->sum_sq += src->sum_sq;
	return;
}

int Gaussian_Gamma_compare_stats(void *stats_a,void *stats_b)
{
	int i,r=0;
	struct Gaussian_Gamma_stats *st_a = (struct Gaussian_Gamma_stats *)stats_a,
						  *st_b = (struct Gaussian_Gamma_stats *)stats_b;
	
	r += (st_a->n == st_b->n ? 0 : 1)
	   + (st_a->sum == st_b->sum ? 0 : 1)
	   + (st_a->sum_sq == st_b->sum_sq ? 0 : 1);	
	i = r > 0 ? 1:0;
	return(i);
}

/*void Gaussian_Gamma_print_stats(void *stats,FILE *fp)
{
	int i;
	struct Gaussian_Gamma_stats *s = (struct Gaussian_Gamma_stats *)stats;
	fprintf(fp,"\n");
	fprintf(fp,"n = %d, sum = %.5f, sum_sq = %.5f ",s->n,s->sum,s->sum_sq);
}*/



