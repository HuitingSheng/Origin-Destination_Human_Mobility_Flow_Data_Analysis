/*Sparse matrix representations and operations

	Author:	Jason Wyse, 
			School of Computer Science and Statistics,
			Trinity College Dublin,
			Dublin 2, Ireland.
			email: wyseja@tcd.ie
			
Last modified: Fri 14 Mar 2014 12:56:38 GMT */

#include "sparse.h"

struct triplet *create_triplet(int *iidx,int *jidx,double *x,size_t nrow,size_t ncol,size_t nnz)
{
	int i;
	struct triplet *t = (struct triplet *)malloc(sizeof(struct triplet));
	t->ridx = calloc(nnz,sizeof(int));
	t->cidx = calloc(nnz,sizeof(int));
	t->x = calloc(nnz,sizeof(double));
	
	t->nrow = nrow;
	t->ncol = ncol;
	t->nnz = nnz;
	
	for(i=0;i<(int)nnz;i++)
	{
		t->ridx[i] = iidx[i];
		t->cidx[i] = jidx[i];
		t->x[i] = x[i];
	}
	return(t);
}

struct triplet *clone_triplet(struct triplet *t)
{
	size_t i;
	struct triplet *ct = (struct triplet *)malloc(sizeof(struct triplet));
	ct->nrow = t->nrow;
	ct->ncol = t->ncol;
	ct->nnz = t->nnz;
	
	ct->ridx = calloc(ct->nnz,sizeof(int));
	ct->cidx = calloc(ct->nnz,sizeof(int));
	ct->x = calloc(ct->nnz,sizeof(double));
	
	for(i=0;i<ct->nnz;i++)
	{
		ct->ridx[i] = t->ridx[i];
		ct->cidx[i] = t->cidx[i];
		ct->x[i] = t->x[i];
	}
	return(ct);
}

void destroy_triplet(struct triplet *t)
{
	free(t->ridx);
	free(t->cidx);
	free(t->x);
	free(t);
	return;
}

struct sparse *triplet_to_sparse(struct triplet *t,int orientation)
{
	int i,j;
	int c,idx;
	int *point_to,*fill_in,dim_p;
	if(orientation)
	{
		//column oriented:: col major
		point_to = t->cidx;
		fill_in = t->ridx;
		dim_p = t->ncol;
		
	}
	else
	{
		//row oriented:: row major
		point_to = t->ridx;
		fill_in = t->cidx;
		dim_p = t->nrow;
	}
	struct sparse *s = (struct sparse *)malloc(sizeof(struct sparse));
	s->orientation = orientation;
	s->nrow = t->nrow;
	s->ncol = t->ncol;
	s->nnz = t->nnz;
	s->p = calloc(dim_p+1,sizeof(int));
	s->i = calloc(s->nnz,sizeof(int));
	s->x = calloc(s->nnz,sizeof(double));
	
	//cycle through the point_to vector finding entries in row/col i
	idx=0;
	for(i=0;i<dim_p;i++)
	{
		s->p[i] = idx;
		for(j=0;j<s->nnz;j++)
		{
			if(point_to[j]==i)
			{
				c++;
				s->i[idx] = fill_in[j];
				s->x[idx] = t->x[j];
				idx++;
			}
		}
	
	}
	s->p[dim_p] = s->nnz;
	
	//destroy_triplet(t);
	
	return(s);
}

void destroy_sparse(struct sparse *s)
{
	free(s->p);
	free(s->i);
	free(s->x);
	free(s);
	return;
}

/*void print_sparse(struct sparse *s,FILE *fp)
{
	int i,j,n;
	n = (s->orientation == 1) ? s->ncol : s->nrow;
	fprintf(fp,"\n");
	for(i=0;i<n+1;i++)
	{
		if(s->orientation) 
			fprintf(fp,"\n Values in col %d:",i);
		else
			fprintf(fp,"\n Values in row %d:",i);
			
		for(j=s->p[i];j<s->p[i+1];j++)
		{
			fprintf(fp,"\nidx: %d, val = %lf",s->i[j],s->x[j]);
		}
	}
	return;
}*/

/*for debug only*/
/*void print_sparse_as_full_matrix(struct sparse *s)
{
	int nrow = s->nrow,ncol=s->ncol,i,j;
	double **fmat;
	fmat = calloc(s->nrow,sizeof(double*));
	for(i=0;i<s->nrow;i++) fmat[i] = calloc(s->ncol,sizeof(double));
	int n = (s->orientation == 1)? s->ncol : s->nrow;
	for(i=0;i<n;i++)
	{
		for(j=s->p[i];j<s->p[i+1];j++)
		{
			if(!s->orientation) fmat[i][s->i[j]] = s->x[j]; else fmat[s->i[j]][i] = s->x[j];
		}
	
	}
	
	for(i=0;i<s->nrow;i++)
	{
		for(j=0;j<s->ncol;j++)
		{
			printf("%.1f,",fmat[i][j]);
		}
		printf("\n");
	}
	
	printf("\n\n\n\n\n");
	
	return;
}*/
