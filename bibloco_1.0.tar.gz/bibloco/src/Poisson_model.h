/*Poisson model for links

	Author:	Jason Wyse, 
			School of Computer Science and Statistics,
			Trinity College Dublin,
			Dublin 2, Ireland.
			email: wyseja@tcd.ie
			
Last modified: Fri 14 Mar 2014 12:57:46 GMT  */

#ifndef __POISSONMODEL_H__
#define __POISSONMODEL_H__

#include "bcluster.h"

struct Poisson_stats
{	
	double n;
	double sumlfact;
	double sumdata;
};

struct Poisson_hyper
{
	double delta;
	double lambda;
};

struct model *set_up_Poisson_model();

void tidy_up_Poisson_model(struct model *model);

void Poisson_create_hyperparameters(struct model *model);

void Poisson_destroy_hyperparameters(void *hyper);

void Poisson_set_hyperparameters(struct model *model,double *model_hyperparameters);

struct block *Poisson_create_new_block(int *dimensions);

struct Poisson_stats *Poisson_create_stats(int dim);

void Poisson_destroy_stats(void *stats);

void Poisson_destroy_block(struct block *block);

void Poisson_copy_block(struct block *source,struct block *target);

void Poisson_add_to_stats(double x,void *stats,int add);

void Poisson_add_zeros_to_stats(int n,void *stats,int add);

void Poisson_reset_stats(void *stats);

double Poisson_compute_log_marginal_likelihood_from_stats(void *stats,void *hyperparams);

void Poisson_add_block_stats(void *stats_source,void *stats_target);

int Poisson_compare_stats(void *stats_a,void *stats_b);

//void Poisson_print_stats(void *stats,FILE *fp);

#endif
