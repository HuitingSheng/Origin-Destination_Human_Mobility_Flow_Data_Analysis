/*Poisson model for links

	Author:	Jason Wyse, 
			School of Computer Science and Statistics,
			Trinity College Dublin,
			Dublin 2, Ireland.
			email: wyseja@tcd.ie
			
Last modified: Fri 14 Mar 2014 12:57:46 GMT  */


#include "Poisson_model.h"

struct model *set_up_Poisson_model()
{
	struct model *model = malloc(sizeof(struct model));
	model->create_hyperparameters = &Poisson_create_hyperparameters;
	model->destroy_hyperparameters = &Poisson_destroy_hyperparameters;
	model->set_hyperparameters = &Poisson_set_hyperparameters;
	model->create_new_block = &Poisson_create_new_block;
	model->destroy_block = &Poisson_destroy_block;
	model->copy_block = &Poisson_copy_block;
	model->add_to_stats = &Poisson_add_to_stats;
	model->add_zeros_to_stats = &Poisson_add_zeros_to_stats;
	model->reset_stats = &Poisson_reset_stats;
	model->add_block_stats = &Poisson_add_block_stats;
	model->compare_stats = &Poisson_compare_stats;
	model->compute_log_marginal_likelihood_from_stats = &Poisson_compute_log_marginal_likelihood_from_stats;
	//model->print_stats = &Poisson_print_stats;
	model->dimensions = calloc(2,sizeof(int));
	
	//this is just a dummy to distract the program (fix later)
	/*model->set_up_hyperparameter_sampling = &Multivariate_Gaussian_Gamma_set_up_hyperparameter_sampling;
	model->destroy_hyperparameter_sampling = &Multivariate_Gaussian_Gamma_destroy_hyperparameter_sampling;
	model->sample_hyperparameters = &Multivariate_Gaussian_Gamma_sample_hyperparameters;*/
	
	return(model);
}

void tidy_up_Poisson_model(struct model *model)
{	
	free(model->dimensions);
	return;
}

void Poisson_create_hyperparameters(struct model *model )
{
	struct Poisson_hyper *hyper = malloc( sizeof( struct Poisson_hyper ));
	model->hyperparameters = (void *)hyper;
	return;
}

void Poisson_destroy_hyperparameters(void *hyper)
{
	struct Poisson_hyper *h = (struct Poisson_hyper *)hyper;
	free(h);
	return;
}

void Poisson_set_hyperparameters(struct model *model,double *model_hyperparameters)
{
	int i;
	
	struct Poisson_hyper *h = (struct Poisson_hyper *)model->hyperparameters ;
	
	h->delta = model_hyperparameters[1];
	h->lambda = model_hyperparameters[2];

	return;
}

struct block * Poisson_create_new_block(int *dimensions)
{
	struct block *block = malloc(sizeof(struct block));
	block->stats = (void *)Poisson_create_stats( dimensions[0] );
	
	block->log_marginal_likelihood = -DBL_MAX;
	return(block);
}

void Poisson_destroy_block(struct block *block)
{
	Poisson_destroy_stats(block->stats);
	free(block);
	return;
}

struct Poisson_stats *Poisson_create_stats(int dim)
{
	struct Poisson_stats *stats = malloc(sizeof(struct Poisson_stats));
	stats->n = 0.;
	stats->sumlfact = 0.;
	stats->sumdata = 0.;
	return(stats);
}

void Poisson_destroy_stats(void *stats)
{
	struct Poisson_stats *s = stats;
	free(s);
	return;
}

void Poisson_copy_block(struct block *source,struct block *target)
{
	struct Poisson_stats *s = (struct Poisson_stats *)source->stats,
						  *t = (struct Poisson_stats *)target->stats;

	t->n = s->n;
	t->sumlfact = s->sumlfact;
	t->sumdata = s->sumdata;
	
	target->log_marginal_likelihood = source->log_marginal_likelihood;
	return;
}

void Poisson_add_to_stats(double x,void *stats,int add)
{
	double sgn = (add == 1) ? 1. : -1.;
	struct Poisson_stats *s = (struct Poisson_stats *)stats;	
	s->n += sgn;
	s->sumlfact += sgn*lgamma(x+1.);
	s->sumdata += sgn*x;
	return;
}

void Poisson_add_zeros_to_stats(int n,void *stats,int add)
{
	double sgn = (add == 1) ? 1.:-1.;
	struct Poisson_stats *s = (struct Poisson_stats *)stats;
	s->n += sgn*n;
	return;
}

void Poisson_reset_stats(void *stats)
{
	int i;
	struct Poisson_stats *s = (struct Poisson_stats *)stats;
	s->n = 0.;
	s->sumlfact = 0.;
	s->sumdata = 0.;
}

double Poisson_compute_log_marginal_likelihood_from_stats(void *stats,void *hyperparams)
{
	double l;
	struct Poisson_stats *s = (struct Poisson_stats *)stats;
	struct Poisson_hyper *h = (struct Poisson_hyper *)hyperparams;
	l = h->delta * log( h->lambda ) - lgamma( h->delta ) - s->sumlfact + lgamma( s->sumdata + h->delta ) - ( s->sumdata + h->delta )*log( h->lambda + s->n );
	return(l);
}

void Poisson_add_block_stats(void *stats_source,void *stats_target)
{
	int i;
	struct Poisson_stats *src = (struct Poisson_stats *)stats_source, *trgt = (struct Poisson_stats *)stats_target;
	trgt->n += src->n;
	trgt->sumlfact += src->sumlfact;
	trgt->sumdata += src->sumdata;
	return;
}

int Poisson_compare_stats(void *stats_a,void *stats_b)
{
	int i,r=0;
	struct Poisson_stats *st_a = (struct Poisson_stats *)stats_a,
						  *st_b = (struct Poisson_stats *)stats_b;
	
	r += (st_a->n == st_b->n) + (st_a->sumlfact == st_b->sumlfact) + (st_a->sumdata == st_b->sumdata);
	i = r > 0 ? 1:0;
	return(i);
}

/*void Poisson_print_stats(void *stats,FILE *fp)
{
	int i;
	struct Poisson_stats *s = (struct Poisson_stats *)stats;
	fprintf(fp,"\n");
	fprintf(fp,"%lf,%lf",s->sumlfact,s->sumdata);
}*/










