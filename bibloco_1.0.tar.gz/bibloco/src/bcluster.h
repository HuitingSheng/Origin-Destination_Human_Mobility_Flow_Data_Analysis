/*C functions to do clustering for the 
	latent block model (bipartite networks/data matrices)

	Author:	Jason Wyse, 
			School of Computer Science and Statistics,
			Trinity College Dublin,
			Dublin 2, Ireland.
			email: wyseja@tcd.ie
			
Last modified: Fri 14 Mar 2014 13:00:01 GMT  */ 

//constant and macro definitions

#ifndef __BCLUSTER_H__
#define __BCLUSTER_H__

#define M_LNPI 1.1447298858494001639

#define TRUE 1
#define FALSE 0

#define MULTINOMMODEL 0
#define GAUSSIANGAMMAMODEL 1
#define POISSMODEL 2

#define debug TRUE

//#include "Rinternals.h"
#include <stddef.h>
//#include <cstdlib>
#include <stdlib.h>
#include <stdio.h>

#include <math.h>
#include <time.h>
#include <float.h>
#include <string.h>
#include <R.h>
#include <Rmath.h>

#include "atable.h"


//margin: structure storing quantities along a side of the matrix
struct margin 
{
	int Gmax; //max no. groups allowed
	int G; //no. groups
	int n; //no. data items
	int *z; //memberships (labels)
	int *ng; //number items in each group
	double **Y; //data matrix row major for this margin
	struct sparse *sparse_Y; //sparse form of the matrix if used
	int **idxz; //indexes of data items in each group
	int *in_use; //is the component in use? TRUE or FALSE
	int *where_is; //in what place is the component stored- this allows for quick look up
	int *where_is_inv; //inverse of where is for greedy fast search
	int **component_search;//for greedy_fast:: which components to look at
	int *n_component_search;//number of components for i in greedy_fast
};
//block: structure giving the basic structure for any block
struct block
{
	void *stats; //void pointer to be recast when needed for a particular model
	double log_marginal_likelihood; //log marginal likelihood of the block
};

//bcluster: the structure storing pretty much everything
struct bcluster
{
	int model_type;
	int model_dims;
	int nmargin;
	struct margin **margins;//structure holding margin information
	struct block ***blocks;//blocks holding statistics for each block
	struct model *model;
	int *nmx; //parameters for the Gibbs sampling- how many rows to sample each time
	double alpha; //Dirichlet parameter for the groups
	struct block *refblock; //for debugging
	FILE *fp_debug;
	int greedy; //logical: greedy algorithm or not?
	int allow_greedy;
	int greedy_fast; //logical: testing at moment
	double log_marginal_likelihood_empty; //for the greedy search algorithm;
	double greedy_store_full_log_posterior;
	int greedy_merge;
	double merge_thresh;
	int greedy_prune; //if true prune off components that don't need to be searched
	double greedy_prune_thresh;//threshold for pruning off in terms of ICL difference
	int sparse; //use a sparse form of the observed data?
	int refresh; //logical: only for memory positions of components for algorithm restart..
	double delta;
	int mcmc_alg;
	double *table_a;
	int tidy_empty_only;
	int multivariate_model;//logical whether the model is multivariate
};

//model: structure giving the model specific function pointers and hyperprameters
struct model
{
	void (*create_hyperparameters)(struct model * ); //create a model specific struct to hold hyperparameters
	void (*destroy_hyperparameters)(void *); //destroy the structure for the hyperparameters
	void (*set_hyperparameters)(struct model *,double *);//set the hyperparameters of the model
	void (*set_up_hyperparameter_sampling)( struct model * , int * ); //set up whatever is needed for the hyperparameter sampling
	void (*destroy_hyperparameter_sampling)(void *); //destroy the hyperparameter sampling
	void (*sample_hyperparameters)(struct bcluster *); //sample the hyperparameters of the model
	struct block * (*create_new_block)(int *); //create a pointer to a block and allocate
	void (*destroy_block)(struct block *); //deallocate the block and free pointer
	void (*copy_block)(struct block *,struct block *); //copy the contents of two blocks
	void (*add_to_stats)(double,void *,int); //add an entry to the block statistics
	void (*add_to_stats_multivariate)(double *,void *,int); //add an entry to the block of statistics multivariate 
	void (*add_zeros_to_stats)(int ,void *,int);
	void (*reset_stats)(void *);//reset all of the statistics to empty block
	double (*compute_log_marginal_likelihood_from_stats)(void *,void *);//compute marginal likelihood
	void (*add_block_stats)(void *,void *);
	int (*compare_stats)(void *,void *);
	void (*print_stats)(void *,FILE *);
	void *hyperparameters;//the hyperparameters of the model
	void *hyperparameter_sampling; //space for the efficient sampling of hyperparameters
	int *dimensions; // dimension of the model
	int do_hyperparam_sampling; //logical- sample the hyperparameters for the model?
};


//results: store the results of a sampler run
struct results
{
	int n;
	int nstored;
	int **labels;
	int *ngroups;
};
//rates: records the acceptance rates of an mcmc run
struct rates
{
	int proposed_m1;
	int accepted_m1;
	int proposed_m2;
	int accepted_m2;
	int proposed_m3;
	int accepted_m3;
	int proposed_eject;
	int accepted_eject;
	int proposed_absorb;
	int accepted_absorb;
};


#include "Multinom_model.h"
#include "Gaussian_Gamma_model.h"
#include "Poisson_model.h"
#include "Multivariate_Gaussian_Gamma_model.h"
#include "sparse.h"


//memory management
struct bcluster * set_up_problem(int model_type,int nmargin,int *Gmax,int *n,double **Y,int *nmx,int greedy,int greedy_fast,int mcmc_alg,double *model_hyperparameters,int sparse,struct triplet *t,int *dimensions,int sample_hyperparameters);
void tidy_up_problem(struct bcluster *bc);

struct model *allocate_model();
void free_model(struct model *model);

struct margin * allocate_margin(int dir,int Gmax,int *n,double **Y,int greedy_fast,int sparse,struct triplet *t);
void free_margin(struct margin *margin,int greedy_fast,int sparse);

struct results * allocate_margin_results(int n,int niteration,int nburn);
void free_margin_results(struct results *res);


struct rates * allocate_rates();
void tidy_up_rates(struct rates * rt);

//initialization and refreshing
void initialize_problem(struct bcluster *bc,int *initG);
void initialize_problem_with_labels(struct bcluster *bc,int *initG,int *rmemberships,int *cmemberships);
void recompute_all_blocks(struct bcluster *bc);
void sparse_recompute_all_blocks(struct bcluster *bc);

//updates and update related functions
void update_allocations(struct bcluster *bc, int mrgn);
void update_allocations_greedy_fast(struct bcluster *bc,int mrgn);
int update_allocations_with_metropolis_move_1(struct bcluster *bc,int mrgn,int *accepted,int *proposed);
int update_allocations_with_metropolis_move_2(struct bcluster *bc,int mrgn,int *accepted,int *proposed);
int update_allocations_with_metropolis_move_3(struct bcluster *bc,int mrgn,int *accepted,int *proposed);
int update_allocations_with_eject_move(struct bcluster *bc,int mrgn,int *accepted,int *proposed,double pr_ej_G,double pr_ej_Gp1);
int update_allocations_with_absorb_move(struct bcluster *bc,int mrgn,int *accepted,int *proposed,double pr_ej_G,double pr_ej_Gm1);
int update_allocations_with_eject_move_x(struct bcluster *bc,int mrgn,int *accepted,int *proposed,double pr_ej_G,double pr_ej_Gp1);
int update_allocations_with_absorb_move_x(struct bcluster *bc,int mrgn,int *accepted,int *proposed,double pr_ej_G,double pr_ej_Gm1);
void swap_component_labels(struct bcluster *bc,int mrgn,int g1,int g2);
void combine_clusters_for_greedy_search(struct bcluster *bc);
double get_log_relative_probability_Gibbs(struct bcluster *bc,int mrgn,double *x,int g,int gn);
void sparse_rep_get_log_relative_probability_Gibbs(struct bcluster *bc,int mrgn,int idx,double *pr,int *groups,int nsearch);
void merge_clusters_for_greedy_search(struct bcluster *bc,int mrgn);

//likelihood and book-keeping
double compute_log_marginal_likelihood_block_with_inc_rm(struct bcluster *bc,int mrgn,double *x,int rcl,int ccl,int add);
void move_to_new_component(struct bcluster *bc,int mrgn,double *x,int idx,int cl_old,int cl_new,int empty,int compute_marginal_likelihood);
void sparse_rep_move_to_new_component(struct bcluster *bc,int mrgn,int idx,int cl_old,int cl_new,int empty);
double get_full_log_posterior_of_model(struct bcluster *bc);
double get_log_normalizing_constant_margin(struct bcluster *bc,int mrgn,int G);

//results handling
struct results ** set_up_results(struct bcluster *bc,int nstored);
void tidy_up_results(struct bcluster *bc,struct results **Result);
struct results * allocate_results(struct margin *margin,int nstored);
void free_results(struct results *results);
void write_to_results(struct results *results,struct margin *margin,int idx);
//void write_results_to_file(struct results *results,FILE *fp_labels,FILE *fp_ngroups);

//debugging
int compute_check_stats(struct bcluster *bc,void *compare_stats);
int check_membership_counts_against_labels(struct bcluster *bc,int mrgn);

//simple utils & sampling
double get_max(double *x,int len);
double get_min(double *x,int len);
int sample_discrete( double *weights, int len );

void random_ranshuffle( int *a, int n );

#endif
