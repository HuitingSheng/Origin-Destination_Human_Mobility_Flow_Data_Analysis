
#ifndef __MV_GAUSSIAN_GAMMA_MODEL__
#define __MV_GAUSSIAN_GAMMA_MODEL__

#endif
