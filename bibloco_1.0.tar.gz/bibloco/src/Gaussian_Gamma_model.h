/*Gaussian model for links

	Author:	Jason Wyse, 
			School of Computer Science and Statistics,
			Trinity College Dublin,
			Dublin 2, Ireland.
			email: wyseja@tcd.ie
			
Last modified: Fri 24 Jul 2015 03:05:30 PM IST   */

#ifndef __GAUSSIAN_GAMMAMODEL_H__
#define __GAUSSIAN_GAMMAMODEL_H__

#include "bcluster.h"

struct Gaussian_Gamma_stats
{
	int n; //number of items in a block
	double sum; //sum of the items in a block
	double sum_sq; //sum of squares of items in a block
};

struct Gaussian_Gamma_hyper
{
	double kappa;
	double delta;
	double gamma;
	double xi;
};

struct model *set_up_Gaussian_Gamma_model();

void tidy_up_Gaussian_Gamma_model(struct model *model);

void Gaussian_Gamma_create_hyperparameters(struct model *model);

void Gaussian_Gamma_destroy_hyperparameters(void *hyper);

void Gaussian_Gamma_set_hyperparameters(struct model *model,double *model_hyperparameters);

struct block * Gaussian_Gamma_create_new_block(int *dimensions);

struct Gaussian_Gamma_stats *Gaussian_Gamma_create_stats(int dim);

void Gaussian_Gamma_destroy_stats(void *stats);

void Gaussian_Gamma_destroy_block(struct block *block);

void Gaussian_Gamma_copy_block(struct block *source,struct block *target);

void Gaussian_Gamma_add_to_stats(double x,void *stats,int add);

void Gaussian_Gamma_reset_stats(void *stats);

double Gaussian_Gamma_compute_log_marginal_likelihood_from_stats(void *stats,void *hyperparams);

void Gaussian_Gamma_add_block_stats(void *stats_source,void *stats_target);

int Gaussian_Gamma_compare_stats(void *stats_a,void *stats_b);

//void Gaussian_Gamma_print_stats(void *stats,FILE *fp);

#endif 
