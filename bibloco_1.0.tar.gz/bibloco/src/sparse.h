/*Sparse matrix representations and operations

	Author:	Jason Wyse, 
			School of Computer Science and Statistics,
			Trinity College Dublin,
			Dublin 2, Ireland.
			email: wyseja@tcd.ie
			
Last modified: Fri 14 Mar 2014 12:56:38 GMT */

#ifndef __SPARSE_H__
#define __SPARSE_H__

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
#include <string.h>
#include <stddef.h>

struct triplet
{
	size_t nrow;
	size_t ncol;
	size_t nnz;
	int *ridx;
	int *cidx;
	double *x;
};

struct sparse
{
	size_t nrow; //number rows in matrix
	size_t ncol; //number cols in matrix
	size_t nnz; //number of non-zero entries
	int orientation; //0 for row indexed, 1 for col indexed
	int *p; //pointer into oriented data blocks
	int *i; //indexes of the non-zero entries in rows/cols
	double *x; //values of the non-zero entries in rows/cols
};

struct triplet *create_triplet(int *i,int *j,double *x,size_t nrow,size_t ncol,size_t nnz);

struct triplet *clone_triplet(struct triplet *t);

void destroy_triplet(struct triplet *t);

struct sparse *triplet_to_sparse(struct triplet *t,int orientation);

void destroy_sparse(struct sparse *s);

//void print_sparse(struct sparse *s,FILE *fp);

//void print_sparse_as_full_matrix(struct sparse *s);

#endif
