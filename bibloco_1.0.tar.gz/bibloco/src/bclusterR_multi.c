/*C functions (to be called from R) to do clustering for the 
	latent block model (bipartite networks/data matrices)

	Author:	Jason Wyse, 
			School of Computer Science and Statistics,
			Trinity College Dublin,
			Dublin 2, Ireland.
			email: wyseja@tcd.ie
			
Last modified: Fri 11 Sep 2015 02:55:04 PM IST   */



#include "bcluster.h"
#include "cat.h"

//function delarations

void bcluster_mcmc_R(double *data,int *nrow,int *ncol,int *model_type,int *Gmax,int *Ginit,int *r_memb_init,int *c_memb_init,int *init_type,double *hyperparams,
/*mcmc specifications*/
int *niteration, int *nburn, int *thin,int *only_gibbs,int *fix_G,
/*sparse representation*/
int *sparse,int *rowindex, int *colindex, double *values, int *nvalues,
/*return values*/
int *r_membership,int *r_ngroup,int *c_membership,int *c_ngroup,double *lposterior,double *acc_rates,int *use_same_seed , int *nmargin_update, int *dimensions,
/*hyperparameters*/
int *sample_hyperparameters );

void bcluster_greedy_R(double *data,int *nrow,int *ncol,int *model_type,int *Gmax,int *Ginit,int *r_memb_init,int *c_memb_init,int *init_type,int *use_greedy_merge,double *hyperparams,
/*search specifications*/
int *greedy_fast_alg, int *nruns, int *nrestarts,
/*sparse representation*/
int *sparse,int *rowindex, int *colindex, double *values, int *nvalues,
/*return values*/
int *r_memb_greedy,int *c_memb_greedy,double *ICL,int *hardtol,int *use_same_seed,
/*store ICL*/
int *keepICL,double *ICLstore,
/*pruning*/
double *delta , 
/*if clustering but not block clustering*/
int *nmargin_update,
/*dimensions*/
int *dimensions,
/*merge threshold*/
double *merge_thresh
);

void Relabel(int *n_obs,int *n_sample,int *n_groups,int *labels_in,int *labels_out);


void bcluster_greedy_R(double *data,int *nrow,int *ncol,int *model_type,int *Gmax,int *Ginit,int *r_memb_init,int *c_memb_init,int *init_type,int *use_greedy_merge,double *hyperparams,
/*search specifications*/
int *greedy_fast_alg, int *nruns, int *nrestarts,
/*sparse representation*/
int *sparse,int *rowindex, int *colindex, double *values, int *nvalues,
/*return values*/
int *r_memb_greedy,int *c_memb_greedy,double *ICL,int *hardtol,int *use_same_seed,
/*store ICL*/
int *keepICL,double *ICLstore,
/*pruning*/
double *delta , 
/*if clustering but not block clustering*/
int *nmargin_update,
/*dimensions*/
int *dimensions,
/*merge threshold*/
double *merge_thresh
)
{

	int i,j,run,start,*n,*nmx,greedy=TRUE,nstep,greedy_fast=*greedy_fast_alg,maxsteps=1000,**r_memb_runs,**c_memb_runs;
	double **Y,L,tol=1e-6,*minICL_runs,*maxICL_runs;
	
	r_memb_runs = calloc(*nruns,sizeof(int*)); //allocate as needed later...
	c_memb_runs = calloc(*nruns,sizeof(int*));
	minICL_runs = calloc(*nruns,sizeof(double));
	maxICL_runs = calloc(*nruns,sizeof(double));
	
	if(!(*hardtol)) tol=1e-2;
	struct triplet *t;
	if(!(*sparse))
	{
		Y = calloc(*nrow,sizeof(double*));
		for(i=0;i<*nrow;i++) Y[i] = calloc(*ncol,sizeof(double));
		//put data into the matrix- remember col major in R
		for(i=0;i<*nrow;i++)
		{
			for(j=0;j<*ncol;j++)
			{
				Y[i][j] = data[j*(*nrow)+i];
			}
		}

	}
	else
	{
		//make a triplet form from the data
		t = create_triplet(rowindex,colindex,values,(size_t)*nrow,(size_t)*ncol,(size_t)*nvalues);
	}
	n=calloc(2,sizeof(int));
	nmx=calloc(2,sizeof(int));
	n[0] = *nrow; n[1] = *ncol;
	nmx[0]=*nrow;nmx[1]=*ncol;
	//random number generator
	
  	struct bcluster *bc;
  	
  	GetRNGstate();
  	
  	for(run=0;run<*nruns;run++)
  	{
	  	//allocate the model and margins
		bc = set_up_problem(*model_type,2,Gmax,n,Y,nmx,greedy,greedy_fast,FALSE,hyperparams,*sparse,t,dimensions,FALSE);
		if(bc->greedy_fast)
		{
			bc->greedy_prune = TRUE;
			bc->greedy_prune_thresh = -150.;
			bc->delta = *delta;
		}
		bc->greedy_merge=*use_greedy_merge;
		bc->merge_thresh = *merge_thresh; //use a pretty low tolerance on merging clusters.
		
		//it appears to be better to refresh the starting config at each iteration
		
		if( *init_type==0 )
		{
			for(i=0;i<bc->margins[0]->n;i++)
			{
				r_memb_init[i] = (int)( Gmax[0] * runif(0.0,1.0) ) ;//gsl_rng_uniform_int(r,Gmax[0]);
			//	Rprintf(" %d ,",r_memb_init[i]);
			}
			//Rprintf("\n***\n");
			if(Gmax[1] > 1) for(i=0;i<bc->margins[1]->n;i++) c_memb_init[i] = (int)( Gmax[1] * runif(0.0,1.0) ) ;
		}
		
		bc->alpha = hyperparams[1];
		bc->refresh = FALSE;
		for(start=0;start<*nrestarts+1;start++)
		{

			R_CheckUserInterrupt(); 
			switch(*init_type)
			{	
				case 0: 
					initialize_problem(bc,Ginit); 
				break;
				case 1: 
					initialize_problem_with_labels(bc,Ginit,r_memb_init,c_memb_init); 
				break;
				case 2:
					initialize_problem_with_labels(bc,Ginit,r_memb_init,c_memb_init);
				break;
			}
			

			//introduce Gibbs sampling step to perturb:: this was bad
			/*bc->greedy = FALSE;
			for(i=0;i<5;i++)
			{
				for(j=0;j<2;j++) update_allocations(bc,j,r);
			}
			bc->greedy = TRUE;*/
			
			bc->greedy_store_full_log_posterior = get_full_log_posterior_of_model(bc);
			ICL[0] = bc->greedy_store_full_log_posterior;
			if(start == 0) minICL_runs[run] = ICL[0];
			//start greedy algorithm
			L = -DBL_MAX;
			nstep = 1;
			if(bc->greedy_fast) bc->greedy_prune = FALSE;
			
			while(fabs(L-bc->greedy_store_full_log_posterior)>tol && nstep<maxsteps)
			{
			
				if(nstep>1) bc->greedy_store_full_log_posterior = L;
				if(bc->greedy_fast)
				{
					R_CheckUserInterrupt(); 
					for(i=0;i<*nmargin_update;i++) update_allocations_greedy_fast(bc,i);
				}else{
					R_CheckUserInterrupt(); 
					for(i=0;i<*nmargin_update;i++) update_allocations(bc,i);
				}
				//L = get_full_log_posterior_of_model(bc);

				if(nstep == 5 && bc->greedy_fast) bc->greedy_prune = TRUE;
				nstep++;
				
			}

			if(nstep == maxsteps) printf("\nWarning: maximum iterations reached without convergence");
			
			bc->greedy_store_full_log_posterior = L;
			
			if(bc->greedy_merge)
			{	
				if(j>0) bc->greedy_store_full_log_posterior = L;
				for(i=0;i<2;i++) merge_clusters_for_greedy_search(bc,i);
				L = get_full_log_posterior_of_model(bc);
			}
			
			//use the greedy merge step if requested
			ICL[1] = get_full_log_posterior_of_model(bc);
			
			//printf("\nICL after greedy merge = %lf",ICL[1]);
			
			if(*keepICL)
			{
				ICLstore[run] = ICL[1];
			}
		
			*init_type = 1;
				//and do the init vectors too and Ginit...
				//for(i=0;i<bc->margins[0]->n;i++) r_memb_init[i] = bc->margins[0]->z[i];
				//for(i=0;i<bc->margins[1]->n;i++) c_memb_init[i] = bc->margins[1]->z[i];
			Ginit[0] = bc->margins[0]->G;
			Ginit[1] = bc->margins[1]->G;

			bc->refresh = TRUE;
		}
		

		/*j=0;
		if(bc->greedy_merge && j<3)
		{	
			for(i=0;i<2;i++) merge_clusters_for_greedy_search(bc,i,r);
			L = get_full_log_posterior_of_model(bc);
			j++;	
		}*/
		
		maxICL_runs[run] =  ICL[1]; //get_full_log_posterior_of_model(bc);
		
		//store the label vector for this run... 
		
		r_memb_runs[run] = calloc(bc->margins[0]->n,sizeof(int));
		c_memb_runs[run] = calloc(bc->margins[1]->n,sizeof(int));
		
		for(i=0;i<bc->margins[0]->n;i++) r_memb_runs[run][i] = bc->margins[0]->z[i];
		for(i=0;i<bc->margins[1]->n;i++) c_memb_runs[run][i] = bc->margins[1]->z[i];
		
		tidy_up_problem(bc);
		
		for(i=0;i<2;i++) Ginit[i] = Gmax[i]; //reset
		//printf("\nDone to run %d, ICL = %lf",run,ICL[1]);
	}
	
	PutRNGstate();
	
	//printf("\nAll runs complete!");
	//for(j=0;j<*nruns;j++) printf("\nmaxicl[%d] = %lf",j,maxICL_runs[j]);
	//now, find the run that gives the max ICL and return this...
	double max=maxICL_runs[0]; 
	int idx=0;
	j=1;
	while(j<*nruns)
	{
		if(maxICL_runs[j] > max)
		{
			max = maxICL_runs[j];
			idx = j;
		}
		j++;
	}
	
	for(i=0;i<n[0];i++) r_memb_greedy[i] = r_memb_runs[idx][i];
	for(i=0;i<n[1];i++) c_memb_greedy[i] = c_memb_runs[idx][i];
	
	ICL[0] = minICL_runs[idx];
	ICL[1] = maxICL_runs[idx];
	
	for(i=0;i<*nruns;i++)
	{
		free(r_memb_runs[i]);
		free(c_memb_runs[i]);
	}
	free(r_memb_runs);
	free(c_memb_runs);
	free(minICL_runs);
	free(maxICL_runs);
	
	//free up data master copy
	if(!(*sparse))
	{
		for(i=0;i<*nrow;i++) free(Y[i]);
		free(Y);
	}
	else
	{
		destroy_triplet(t);
	}
	
	//tidy up stuff
	free(n);
	free(nmx);
	return;
}


void bcluster_mcmc_R(double *data,int *nrow,int *ncol,int *model_type,int *Gmax,int *Ginit,int *r_memb_init,int *c_memb_init,int *init_type,double *hyperparams,
/*mcmc specifications*/
int *niteration, int *nburn, int *thin,int *only_gibbs,int *fix_G,
/*sparse representation*/
int *sparse,int *rowindex, int *colindex, double *values, int *nvalues,
/*return values*/
int *r_membership,int *r_ngroup,int *c_membership,int *c_ngroup,double *lposterior,double *acc_rates,int *use_same_seed , int *nmargin_update, int *dimensions,
/*hyperparameters*/
int *sample_hyperparameters )
{

	// if nmargin==1 then clustering is done along the rows only -- check to see if this works

	int i, j, k, run, start, *n, *nmx, greedy=FALSE, nstep, greedy_fast=FALSE;
	double **Y, L, pr_ej_G, pr_ej_Gp1, pr_ej_Gm1;
	struct rates **mcmc_rates;

	struct triplet *t;
	if(!(*sparse))
	{
		Y = calloc(*nrow,sizeof(double*));
		for(i=0;i<*nrow;i++) Y[i] = calloc(*ncol,sizeof(double));
		//put data into the matrix- remember col major in R
		for(i=0;i<*nrow;i++)
		{
			for(j=0;j<*ncol;j++){
				Y[i][j] = data[j*(*nrow)+i];
			}
		}	
	}
	else
	{
		//make a triplet form from the data
		t = create_triplet(rowindex,colindex,values,(size_t)*nrow,(size_t)*ncol,(size_t)*nvalues);
	}
	n=calloc(2,sizeof(int));
	nmx=calloc(2,sizeof(int));
	n[0] = *nrow; n[1] = *ncol;
	nmx[0]=*nrow;nmx[1]=*ncol;

  	struct bcluster *bc;
  	
  	GetRNGstate();

	bc = set_up_problem(*model_type,2,Gmax,n,Y,nmx,greedy,greedy_fast,TRUE,hyperparams,*sparse,t,dimensions,*sample_hyperparameters);
	bc->tidy_empty_only = TRUE; 
	
	
	mcmc_rates = (struct rates **)malloc(2*sizeof(struct rates *));
	for(i=0;i<2;i++) mcmc_rates[i] = allocate_rates();
	
	//free up data master copy as no longer needed (copies in bc struct)

	bc->greedy_merge=FALSE;
		
	//it appears to be better to refresh the starting config at each iteration
	
	if(!(Ginit[0] == 1))
	{
		for(i=0;i<bc->margins[0]->n;i++) r_memb_init[i] = (int)( runif(0.0,1.0) * Ginit[0] );
	}
	if(!(Ginit[1] == 1))
	{	
		for(i=0;i<bc->margins[1]->n;i++) c_memb_init[i] = (int)( runif(0.0,1.0) * Ginit[1] );
	}
	
	bc->alpha = hyperparams[0];
	bc->refresh = FALSE;
	 
	switch(*init_type)
	{	
			case 0: 
				initialize_problem(bc,Ginit); 
			break;
			case 1: 
				initialize_problem_with_labels(bc,Ginit,r_memb_init,c_memb_init); 
			break;				
	}
	
	
	for(int iter=1;iter<*niteration+1;iter++)
	{
		/*this is the mcmc loop-- store the iterations appropriately*/
		//check for user interrupt
		R_CheckUserInterrupt();
		
		for(i=0;i<*nmargin_update;i++)
		{
		
			update_allocations(bc,i);
			//j = check_membership_counts_against_labels(bc,i);
			//if(j) Rprintf("\nFailure in Gibbs");
		
		}
		
		for(i=0;i<*nmargin_update;i++)
		{
			
			if(!(*only_gibbs))
			{
				update_allocations_with_metropolis_move_1(bc,i,&(mcmc_rates[i]->accepted_m1),&(mcmc_rates[i]->proposed_m1));
				
				update_allocations_with_metropolis_move_2(bc,i,&(mcmc_rates[i]->accepted_m2),&(mcmc_rates[i]->proposed_m2));
				
				update_allocations_with_metropolis_move_3(bc,i,&(mcmc_rates[i]->accepted_m3),&(mcmc_rates[i]->proposed_m3));
			}
			
		}
		
		for(i=0;i<*nmargin_update;i++)
		{
			
			if(!(*fix_G))
			{
				int ej_case;
				
				if(bc->margins[i]->G == 1)
				{
					ej_case=0;
				}
				else if(bc->margins[i]->G == bc->margins[i]->Gmax)
				{
					ej_case=1;
				}
				else if(bc->margins[i]->G == 2)
				{
				 	ej_case=2;
				}
				else if(bc->margins[i]->G == bc->margins[i]->Gmax-1)
				{
					ej_case = 3;
				}
				else
				{
					ej_case = 4;
				}
				
				switch(ej_case)
				{
					case 0:
						pr_ej_G = 1.;
						pr_ej_Gp1 = .5;
						pr_ej_Gm1 = 0.;
					break;
			
					case 1:
						pr_ej_G = 0.;
						pr_ej_Gp1 = 0.;
						pr_ej_Gm1 = .5;
					break;
		
					case 2:
						pr_ej_G = .5;
						pr_ej_Gp1 = .5;
						pr_ej_Gm1 = 1.;
					break;
			
					case 3:
						pr_ej_G = 0.5;
						pr_ej_Gp1 = 0.;
						pr_ej_Gm1 = 0.5;
					break;
			
					case 4:
						pr_ej_G = 0.5;
						pr_ej_Gp1 = 0.5;
						pr_ej_Gm1 = 0.5;
					break;
				}
				
				if( runif(0.0,1.0) < pr_ej_G)
				{
					update_allocations_with_eject_move_x(bc,i,&(mcmc_rates[i]->accepted_eject),&(mcmc_rates[i]->proposed_eject), pr_ej_G,pr_ej_Gp1);
					//j = check_membership_counts_against_labels(bc,i);
					//if(j) Rprintf("\nFailure in eject move");
				}else{
					update_allocations_with_absorb_move_x(bc,i,&(mcmc_rates[i]->accepted_absorb),&(mcmc_rates[i]->proposed_absorb), pr_ej_G,pr_ej_Gm1);
					//j = check_membership_counts_against_labels(bc,i);
					//if(j) Rprintf("\nFailure in absorb move");
				}				
			
			}
		
		}
		
		if(bc->model->do_hyperparam_sampling) bc->model->sample_hyperparameters( bc );

		if(iter>*nburn)
		{
			if((iter-*nburn)%(*thin) == 0)
			{
				j = (iter-*nburn)/(*thin)-1;
				/*store*/
				
				for(k=0;k<bc->nmargin;k++)
				{
					for(i=0;i<bc->margins[k]->n;i++)  r_membership[j*bc->margins[0]->n +i] = bc->margins[0]->z[i];
					if( k==0 ) r_ngroup[j] = bc->margins[0]->G;
					if( k==1 ) c_ngroup[j] = bc->margins[1]->G;
				}
				
				lposterior[j] = get_full_log_posterior_of_model(bc) - lgamma(bc->margins[0]->G + 1.) - ( *nmargin_update == 2 ) * lgamma(bc->margins[1]->G + 1.);
				
			}
			
		}
	
	}
	
	PutRNGstate();
	
	for(i=0;i<bc->nmargin;i++)
	{
		acc_rates[0 + 5*i] =  100.*((double)mcmc_rates[i]->accepted_m1/(double)mcmc_rates[i]->proposed_m1);
		acc_rates[1 + 5*i] = 100.*((double)mcmc_rates[i]->accepted_m2/(double)mcmc_rates[i]->proposed_m2);
		acc_rates[2 + 5*i] =  100.*((double)mcmc_rates[i]->accepted_m3/(double)mcmc_rates[i]->proposed_m3);
		acc_rates[3 + 5*i] = 100.*((double)mcmc_rates[i]->accepted_eject/(double)mcmc_rates[i]->proposed_eject);
		acc_rates[4 + 5*i] = 100.*((double)mcmc_rates[i]->accepted_absorb/(double)mcmc_rates[i]->proposed_absorb);
	}
	
	for(i=0;i<bc->nmargin;i++)
	{
		tidy_up_rates(mcmc_rates[i]);
	}
	free(mcmc_rates);
	
	tidy_up_problem(bc);
	
	if(!(*sparse))
	{
		for(i=0;i<*nrow;i++) free(Y[i]);
		free(Y);
	}
	else
	{
		destroy_triplet(t);
	}
	
	free(n);
	free(nmx);
	
	return;
}



//label switching algorithm

void Relabel(int *n_obs,int *n_sample,int *n_groups,int *labels_in,int *labels_out)
{

	int n,g,**raw,**relab,**summary,
		i,j,k,t,N,T,**cost,*lab;
	
	/*n and no. of groups*/
	n=n_obs[0];
	g=n_groups[0];
	/*N = number of samples to undo label switching for*/
	N=n_sample[0];

	T=0;

	/*allocate memory and initialize*/
	raw = imatrix(1,N,1,n);
	relab = imatrix(1,N,1,n);
	summary = imatrix(1,g,1,n);
	cost = imatrix(1,g,1,g+1);
	lab = ivector(1,g);


	/*copy from labels_in to raw_r*/
	for(i=0;i<N;i++){
		for(j=0;j<n;j++){
			raw[i+1][j+1] = labels_in[ i + j*N ];
		}	
	}


	for(i=1;i<g+1;i++){
		for(j=1;j<n+1;j++){
			summary[i][j]=0;
		}
	}

	/*use the first allocation in raw as the first labelling*/

	for(i=1;i<n+1;i++){
		summary[raw[1][i]][i]+=1;
	}

	for(i=1;i<n+1;i++){
		relab[1][i] = raw[1][i];
	}
	

	for(t=2;t<N+1;t++){

	/*row t*/
	/*compute the cost matrix*/
	for(i=1;i<g+1;i++){
	
		for(j=1;j<g+1;j++){
	
			cost[i][j]=0;
		
			for(k=1;k<n+1;k++){
		
				if(raw[t][k]==j){
					cost[i][j]+=summary[i][k];
				}
			
			} 
		
			cost[i][j]=n*(t-1)-cost[i][j];
		
		}
		cost[i][g+1]=0;
	
		}

		T=0;
		
		assct(g,cost,lab,&T);

		/*relabel based on output from assct*/
		/*update the summary matrix*/
		for(i=1;i<n+1;i++){
			relab[t][i]=lab[raw[t][i]];
			summary[lab[raw[t][i]]][i]+=1;
		}

	}


	for(i=0;i<N;i++){
		for(j=0;j<n;j++){
			labels_out[ i + j*N ] = relab[i+1][j+1];
		}	
	}	
	
	free_imatrix(raw,1,N,1,n);
	free_imatrix(relab,1,N,1,n);
	free_imatrix(summary,1,g,1,n);
	free_imatrix(cost,1,g,1,g+1);
	free_ivector(lab,1,g);

	return;
}





