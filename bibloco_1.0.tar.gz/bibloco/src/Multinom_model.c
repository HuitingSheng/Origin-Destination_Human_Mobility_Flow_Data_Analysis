/*Multinomial model for links

	Author:	Jason Wyse, 
			School of Computer Science and Statistics,
			Trinity College Dublin,
			Dublin 2, Ireland.
			email: wyseja@tcd.ie
			
Last modified: Fri 14 Mar 2014 12:57:46 GMT  */


#include "Multinom_model.h"

struct model *set_up_Multinom_model()
{
	struct model *model = malloc(sizeof(struct model));
	model->create_hyperparameters = &Multinom_create_hyperparameters;
	model->destroy_hyperparameters = &Multinom_destroy_hyperparameters;
	model->set_hyperparameters = &Multinom_set_hyperparameters;
	model->create_new_block = &Multinom_create_new_block;
	model->destroy_block = &Multinom_destroy_block;
	model->copy_block = &Multinom_copy_block;
	model->add_to_stats = &Multinom_add_to_stats;
	model->add_zeros_to_stats = &Multinom_add_zeros_to_stats;
	model->reset_stats = &Multinom_reset_stats;
	model->add_block_stats = &Multinom_add_block_stats;
	model->compare_stats = &Multinom_compare_stats;
	model->compute_log_marginal_likelihood_from_stats = &Multinom_compute_log_marginal_likelihood_from_stats;
	//model->print_stats = &Multinom_print_stats;
	model->dimensions = calloc(2,sizeof(int));
	
	//this is just a dummy to distract the program (fix later)
	/*model->set_up_hyperparameter_sampling = &Multivariate_Gaussian_Gamma_set_up_hyperparameter_sampling;
	model->destroy_hyperparameter_sampling = &Multivariate_Gaussian_Gamma_destroy_hyperparameter_sampling;
	model->sample_hyperparameters = &Multivariate_Gaussian_Gamma_sample_hyperparameters;*/
	
	return(model);
}

void tidy_up_Multinom_model(struct model *model)
{	
	free(model->dimensions);
	return;
}

void Multinom_create_hyperparameters(struct model *model)
{
	struct Multinom_hyper *hyper = malloc( sizeof(struct Multinom_hyper));
	model->hyperparameters = (void *)hyper;
	return;
}

void Multinom_destroy_hyperparameters( void *hyper )
{
	struct Multinom_hyper *h = (struct Multinom_hyper *)hyper;
	free(h);
	return;
}

void Multinom_set_hyperparameters(struct model *model,double *model_hyperparameters)
{
	struct Multinom_hyper *h = (struct Multinom_hyper *)model->hyperparameters;
	//	[2] beta for Multinomial probabilities
	h->beta = model_hyperparameters[2];
	return;
}

struct block * Multinom_create_new_block(int *dimensions)
{
	struct block *block = malloc(sizeof(struct block));
	block->stats = (void *)Multinom_create_stats( dimensions );
	
	block->log_marginal_likelihood = -DBL_MAX;
	return(block);
}

void Multinom_destroy_block(struct block *block)
{
	Multinom_destroy_stats(block->stats);
	free(block);
	return;
}

struct Multinom_stats *Multinom_create_stats(int *dimensions)
{
	struct Multinom_stats *stats = malloc(sizeof(struct Multinom_stats));
	stats->ncat = dimensions[0];
	stats->counts = calloc(dimensions[0],sizeof(double));
	return(stats);
}

void Multinom_destroy_stats(void *stats)
{
	struct Multinom_stats *s = stats;
	free(s->counts);
	free(s);
	return;
}

void Multinom_copy_block(struct block *source,struct block *target)
{
	struct Multinom_stats *s = (struct Multinom_stats *)source->stats,
						  *t = (struct Multinom_stats *)target->stats;
	
	int i;
	for(i=0;i<s->ncat;i++)
	{
		t->counts[i] = s->counts[i];
	}
	target->log_marginal_likelihood = source->log_marginal_likelihood;
	return;
}

void Multinom_add_to_stats(double x,void *stats,int add)
{
	double sgn = (add == 1) ? 1. : -1.;
	struct Multinom_stats *s = (struct Multinom_stats *)stats;
	int ix = x;
	s->counts[ix] += sgn;
	return;
}

void Multinom_add_zeros_to_stats(int n,void *stats,int add)
{
	double sgn = (add == 1) ? 1. : -1.;
	struct Multinom_stats *s = (struct Multinom_stats *)stats;
	s->counts[0] +=  sgn*n;
	return;
}

void Multinom_reset_stats(void *stats)
{
	int i;
	struct Multinom_stats *s = (struct Multinom_stats *)stats;
	for(i=0;i<s->ncat;i++) s->counts[i] = 0.;
}


double Multinom_compute_log_marginal_likelihood_from_stats(void *stats,void *hyperparams)
{
	int i;
	double l=0.,n=0.;
	struct Multinom_stats *s = (struct Multinom_stats *)stats;
	struct Multinom_hyper *h = (struct Multinom_hyper *)hyperparams;
	for(i=0;i<s->ncat;i++)
	{
		n += s->counts[i];
		l += lgamma( s->counts[i] + h->beta );
	}
	l += lgamma( s->ncat * h->beta ) - s->ncat * lgamma( h->beta ) - lgamma( n + s->ncat * h->beta );
	return(l);
}


void Multinom_add_block_stats(void *stats_source,void *stats_target)
{
	int i;
	struct Multinom_stats *src = (struct Multinom_stats *)stats_source, *trgt = (struct Multinom_stats *)stats_target;
	for(i=0;i<src->ncat;i++)
	{
		trgt->counts[i] += src->counts[i];
	}
	return;
}

int Multinom_compare_stats(void *stats_a,void *stats_b)
{
	int i,r=0;
	struct Multinom_stats *st_a = (struct Multinom_stats *)stats_a,
						  *st_b = (struct Multinom_stats *)stats_b;
	for(i=0;i<st_a->ncat;i++)
	{
		r += (st_a->counts[i] == st_b->counts[i] ? 0 : 1);
	}	
	i = r > 0 ? 1:0;
	return(i);
}

/*void Multinom_print_stats(void *stats,FILE *fp)
{
	int i;
	struct Multinom_stats *s = (struct Multinom_stats *)stats;
	fprintf(fp,"\n");
	for(i=0;i<s->ncat;i++)
	{
		fprintf(fp," %d ",(int)s->counts[i]);
	}

}*/

