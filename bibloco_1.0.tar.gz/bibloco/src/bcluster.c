/*C functions to do clustering for the 
	latent block model (bipartite networks/data matrices)

	Author:	Jason Wyse, 
			School of Computer Science and Statistics,
			Trinity College Dublin,
			Dublin 2, Ireland.
			email: wyseja@tcd.ie
			
Last modified: Fri 14 Mar 2014 13:00:01 GMT  */ 


#include "bcluster.h"

/******************      memory management    **************************/

struct bcluster * set_up_problem(int model_type,int nmargin,int *Gmax,int *n,double **Y,int *nmx,int greedy,int greedy_fast,int mcmc_alg,double *model_hyperparameters,int sparse,struct triplet *t,int *dimensions,int sample_hyperparameters)
{
	int i,j;
	struct bcluster *bc = (struct bcluster *)malloc(sizeof(struct bcluster));
	bc->model_type = model_type;
	bc->nmargin = nmargin;
	bc->greedy = greedy;
	bc->greedy_fast = greedy_fast;
	bc->sparse = sparse;
	bc->mcmc_alg = mcmc_alg;
	switch(bc->model_type)
	{
		case 0:
			//Multinom model 
			bc->multivariate_model = 0;
			bc->model = set_up_Multinom_model();
			bc->model->dimensions[0] = dimensions[0];
		break;
		case 1:
			//Gaussian model
			bc->multivariate_model = 0;
			bc->model = set_up_Gaussian_Gamma_model();
			bc->model->dimensions[0] = 0;
		break;
		case 2:
			//Poisson model
			bc->multivariate_model = 0;
			bc->model = set_up_Poisson_model();
			bc->model->dimensions[0] = 0;
		break;
		case 3:
			//Multivariate Gaussian model
			bc->multivariate_model = 1;
//			bc->model = set_up_Multivariate_Gaussian_Gamma_model();
			bc->model->dimensions[0] = dimensions[0];
		break;
	}
	
	// model hyperparameters 
	bc->alpha = model_hyperparameters[0];
	bc->model->create_hyperparameters(bc->model);
	bc->model->set_hyperparameters(bc->model,model_hyperparameters);
	bc->model->do_hyperparam_sampling = sample_hyperparameters;
	if( bc->model->do_hyperparam_sampling ) bc->model->set_up_hyperparameter_sampling( bc->model , Gmax );
	
	bc->margins = (struct margin **)malloc(nmargin*sizeof(struct margin *));
	for(i=0;i<nmargin;i++) bc->margins[i] = allocate_margin(i,Gmax[i],n,Y,bc->greedy_fast,bc->sparse,t);
	bc->nmx = calloc(nmargin,sizeof(int));
	for(i=0;i<bc->nmargin;i++) bc->nmx[i] = nmx[i];
	bc->blocks = (struct block ***)malloc(Gmax[0]*sizeof(struct block **));
	for(i=0;i<Gmax[0];i++)
	{
		bc->blocks[i] = (struct block **)malloc(Gmax[1]*sizeof(struct block *));
		for(j=0;j<Gmax[1];j++) bc->blocks[i][j] = bc->model->create_new_block(bc->model->dimensions);
	}
	bc->refblock = bc->model->create_new_block(bc->model->dimensions);
	int maxn = n[0] > n[1] ? n[0] : n[1];
	//if(bc->mcmc_alg) bc->table_a = calloc(maxn,sizeof(double));
	bc->tidy_empty_only = FALSE;
	return(bc);
}

void tidy_up_problem(struct bcluster *bc)
{
	int i,j;
	if(!bc->greedy)
	{
		for(i=0;i<bc->margins[0]->Gmax;i++)
		{
			for(j=0;j<bc->margins[1]->Gmax;j++) bc->model->destroy_block(bc->blocks[i][j]);
			free(bc->blocks[i]);
		}
	}
	else
	{
		for(i=0;i<bc->margins[0]->G;i++)
		{
			for(j=0;j<bc->margins[1]->G;j++){
				bc->model->destroy_block(bc->blocks[bc->margins[0]->where_is[i] ][bc->margins[1]->where_is[j] ]);
			}
			free(bc->blocks[ bc->margins[0]->where_is[i] ]);
		}	
	}
	free(bc->blocks);
	bc->model->destroy_block(bc->refblock);
	for(i=0;i<bc->nmargin;i++) free_margin(bc->margins[i],bc->greedy_fast,bc->sparse);
	free(bc->margins);
	free(bc->nmx);
	
	//tidy up the hyperparameters
	bc->model->destroy_hyperparameters( bc->model->hyperparameters );
	if( bc->model->do_hyperparam_sampling ) bc->model->destroy_hyperparameter_sampling( bc->model->hyperparameter_sampling );
	
	free_model(bc->model);
	//if(bc->mcmc_alg) free(bc->table_a);
	free(bc);
	return;
}

struct model * allocate_model()
{
	struct model *m= (struct model *)malloc(sizeof(struct model));
	return(m);
}

void free_model(struct model *model)
{
	free(model);
}

struct margin * allocate_margin(int mrgn,int Gmax,int *n,double **Y,int greedy_fast,int sparse,struct triplet *t)
{
	int i,j;
	struct margin *margin = (struct margin *)malloc(sizeof(struct margin));
	margin->Gmax = Gmax;
	margin->n = n[mrgn];
	margin->z = calloc(margin->n,sizeof(int));
	if(!sparse)
	{
		margin->Y = calloc(margin->n,sizeof(double *));
		for(i=0;i<margin->n;i++) margin->Y[i] = calloc(n[1-mrgn],sizeof(double));
		//fill up Y while here
		for(i=0;i<n[mrgn];i++)
		{
			for(j=0;j<n[1-mrgn];j++)
			{
				margin->Y[i][j] = (1-mrgn) ? Y[i][j] : Y[j][i];
			}
		}
	}
	else
	{
		//clone the triplet and convert it to a sparse form
		//struct triplet *tc = clone_triplet(t);
		margin->sparse_Y = triplet_to_sparse(t,mrgn);
	}
	margin->ng = calloc(Gmax,sizeof(int));
	margin->idxz = calloc(Gmax,sizeof(int *));
	margin->in_use = calloc(Gmax,sizeof(int));
	for(i=0;i<Gmax;i++) margin->idxz[i] = calloc(margin->n,sizeof(int));
	margin->where_is = calloc(Gmax,sizeof(int));
	if(greedy_fast)
	{
		margin->where_is_inv = calloc(Gmax,sizeof(int));
		margin->component_search = calloc(margin->n,sizeof(int*));
		for(i=0;i<margin->n;i++) margin->component_search[i] = calloc(Gmax,sizeof(int));
		margin->n_component_search = calloc(margin->n,sizeof(int));
	}
	return(margin);
}

void free_margin(struct margin *margin,int greedy_fast,int sparse)
{
	int i;
	free(margin->z);
	if(!sparse)
	{
		for(i=0;i<margin->n;i++) free(margin->Y[i]);
		free(margin->Y);
	}
	else
	{
		destroy_sparse(margin->sparse_Y);
	}
	free(margin->ng);
	free(margin->in_use);
	for(i=0;i<margin->Gmax;i++) free(margin->idxz[i]);
	free(margin->idxz);
	free(margin->where_is);
	if(greedy_fast)
	{
		free(margin->where_is_inv);
		for(i=0;i<margin->n;i++) free(margin->component_search[i]);
		free(margin->component_search);
		free(margin->n_component_search);
	}
	free(margin);
	return;
}


struct results * allocate_margin_results(int n,int niteration,int nburn)
{
	int i;
	struct results *res = (struct results *)malloc(sizeof(struct results));
	res->n = n;
	res->nstored = niteration-nburn;
	res->labels = calloc(res->nstored,sizeof(int *));
	for(i=0;i<res->nstored;i++)
	{
		res->labels[i] = calloc(n,sizeof(int));
	}
	res->ngroups = calloc(res->nstored,sizeof(int));
	return(res);
}

void free_margin_results(struct results *res)
{
	int i;
	for(i=0;i<res->nstored;i++)
	{
		free(res->labels[i]);
	}
	free(res->labels);
	free(res->ngroups);
	return;
}

struct rates * allocate_rates()
{
	struct rates *rt = (struct rates *)malloc(sizeof(struct rates));
	rt->proposed_m1 = 0;
	rt->accepted_m1 = 0;
	rt->proposed_m2 = 0;
	rt->accepted_m2 = 0;
	rt->proposed_m3 = 0;
	rt->accepted_m3 = 0;
	rt->proposed_eject = 0;
	rt->accepted_eject = 0;
	rt->proposed_absorb = 0;
	rt->accepted_absorb = 0;
	return(rt);
}

void tidy_up_rates(struct rates * rt)
{
	free(rt);
}

/*************************************************************************************/

/************************ initialization ***********************************/

void initialize_problem(struct bcluster *bc,int *initG)
{
	//simple initialization strategy- just dump 
	int i,j,g,n,ng,nr;
	//printf("\n Initializing prblm");
	for(i=0;i<bc->nmargin;i++)
	{
		n = bc->margins[i]->n;
		bc->margins[i]->G = initG[i];
		//printf("\n the val in margins is %d and initg is %d",bc->margins[i]->G,initG[i]);
		ng = (int)n/initG[i];
		nr = n-initG[i]*ng;
		for(g=0;g<initG[i];g++)
		{
			if(!bc->refresh) bc->margins[i]->where_is[g] = g;
			for(j=0;j<ng;j++)
			{
				bc->margins[i]->idxz[ bc->margins[i]->where_is[g] ][j] = g*ng + j;
				bc->margins[i]->z[g*ng+j] = g;
			}
			bc->margins[i]->ng[g] = ng;
			if(g == initG[i]-1)
			{
				for(j=ng;j<ng+nr;j++)
				{
					bc->margins[i]->idxz[ bc->margins[i]->where_is[g] ][j] = g*ng + j;
					bc->margins[i]->z[g*ng+j] = g;
				}
				bc->margins[i]->ng[g] += nr;
			}
			bc->margins[i]->in_use[g] = TRUE;
		}

		if(bc->greedy_fast)
		{
			//put all things in place in structures
			for(j=0;j<n;j++)
			{
				bc->margins[i]->n_component_search[j] = initG[i];
				for(g=0;g<bc->margins[i]->n_component_search[j];g++) bc->margins[i]->component_search[j][g] = g;
			}
			for(g=0;g<initG[i];g++) bc->margins[i]->where_is_inv[g] = g;
		}
	}
		
	//compute the stats for the initialization
	if(!bc->sparse) recompute_all_blocks(bc); else sparse_recompute_all_blocks(bc);
	return;
}

void initialize_problem_with_labels(struct bcluster *bc,int *initG,int *rmemberships,int *cmemberships)
{
	int i,j,g,mrgn,n;
	for(mrgn=0;mrgn<bc->nmargin;mrgn++)
	{	
		bc->margins[mrgn]->G = initG[mrgn];
		n = bc->margins[mrgn]->n;
		if(!bc->refresh) 
		{
			//printf("\nWe're getting into here");
			for(g=0;g<bc->margins[mrgn]->G;g++)
			{
				bc->margins[mrgn]->where_is[g] = g; //if we are not refreshing a previous structure then this has to be reset..				
				j=0;
				for(i=0;i<n;i++)
				{
					if(!mrgn)
					{
						if(rmemberships[i]==g)
						{
							bc->margins[mrgn]->z[i] = g;
							bc->margins[mrgn]->idxz[ bc->margins[mrgn]->where_is[g] ][j] = i;
							j++;
						}
					}
					else
					{
						if(cmemberships[i]==g)
						{
							bc->margins[mrgn]->z[i] = g;
							bc->margins[mrgn]->idxz[ bc->margins[mrgn]->where_is[g] ][j] = i;
							j++;
						}				
					}
				}
				bc->margins[mrgn]->ng[g] = j;
				bc->margins[mrgn]->in_use[g] = TRUE;
			}
		}
		
		if(bc->greedy_fast)
		{
			//put all things in place in structures
			for(i=0;i<n;i++)
			{
				bc->margins[mrgn]->n_component_search[i] = initG[mrgn];
				for(g=0;g<bc->margins[mrgn]->n_component_search[i];g++) bc->margins[mrgn]->component_search[i][g] = bc->margins[mrgn]->where_is[g];
			}
			
			for(g=0;g<initG[mrgn];g++) 
			{
				i = bc->margins[mrgn]->where_is[g];
				bc->margins[mrgn]->where_is_inv[ i ] = g;
			}
			
		}		
		
		
		
	}
	/*for(mrgn=0;mrgn<bc->nmargin;mrgn++)
	{
		printf("\n");
		for(i=0;i<initG[mrgn];i++) printf(" %d ",bc->margins[mrgn]->where_is[i]);
		printf("\n");
		printf("\nvalue of G = %d in mrgn %d\n",bc->margins[mrgn]->G,mrgn);
	}	*/

	if(!bc->sparse) recompute_all_blocks(bc); else sparse_recompute_all_blocks(bc);
	
	return;
}


void recompute_all_blocks(struct bcluster *bc)
{
	//this needs modifying for the sparse case!! 
	
	//this wipes all the blocks in the structure and computes statistics and 
	//marginal likelihoods from fresh using the given allocations
	//printf("\nInside compute all blocks bc %d, %d",bc->margins[0]->G,bc->margins[1]->G);
	int i,j,ii,jj,g,k,wk,wg,mrgn=0;
	
	//set up marginal likelihood of empty component for greedy search if reqd
	if(bc->greedy)
	{
		struct block *b = bc->model->create_new_block(bc->model->dimensions);
		bc->log_marginal_likelihood_empty = bc->model->compute_log_marginal_likelihood_from_stats(b->stats,bc->model->hyperparameters);
		bc->model->destroy_block(b);
	}
	
	
	for(g=0;g<bc->margins[mrgn]->G;g++)
	{
		for(k=0;k<bc->margins[1-mrgn]->G;k++)
		{
			wg = bc->margins[mrgn]->where_is[g];
			wk = bc->margins[1-mrgn]->where_is[k];
			
			bc->model->reset_stats(bc->blocks[wg][wk]->stats);
			
			for(i=0;i<bc->margins[mrgn]->ng[g];i++)
			{
				//for the multivariate case, we add the row to the stats
				if( bc->multivariate_model )
				{
					ii = bc->margins[mrgn]->idxz[wg][i];
					bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],bc->blocks[wg][wk]->stats,TRUE);
				}
				else
				{
					for(j=0;j<bc->margins[1-mrgn]->ng[k];j++)
					{
						ii = bc->margins[mrgn]->idxz[wg][i];
						jj = bc->margins[1-mrgn]->idxz[wk][j];
						bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jj],bc->blocks[wg][wk]->stats,TRUE);
					}	
				}
			
			}
			bc->blocks[wg][wk]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(bc->blocks[wg][wk]->stats,bc->model->hyperparameters);
			//FILE *tt;
			//bc->model->print_stats(bc->blocks[wg][wk]->stats, tt);
		}
	}
	return;
}


void sparse_recompute_all_blocks(struct bcluster *bc)
{
	int i,j,z,g,k,idx,wk,wg,mrgn=0,st,end;
	int *numzero,*numnonzero;
	double **values;
	numzero = calloc(bc->margins[1-mrgn]->G,sizeof(int));
	numnonzero = calloc(bc->margins[1-mrgn]->G,sizeof(int));
	values = calloc(bc->margins[1-mrgn]->G,sizeof(double*));
	for(i=0;i<bc->margins[1-mrgn]->G;i++) values[i] = calloc(bc->margins[mrgn]->sparse_Y->nnz,sizeof(double));

	//set up marginal likelihood of empty component for greedy search if reqd
	if(bc->greedy)
	{
		bc->model->reset_stats(bc->blocks[bc->margins[0]->where_is[0]][bc->margins[1]->where_is[0]]->stats);
		bc->log_marginal_likelihood_empty = bc->model->compute_log_marginal_likelihood_from_stats(bc->blocks[bc->margins[0]->where_is[0]][bc->margins[1]->where_is[0]]->stats,bc->model->hyperparameters);
	}
	
	for(g=0;g<bc->margins[0]->G;g++)
	{
		for(k=0;k<bc->margins[1]->G;k++)
		{
			bc->model->reset_stats(bc->blocks[ bc->margins[0]->where_is[g] ][ bc->margins[1]->where_is[k] ]->stats);
		}
	}	
	
	for(g=0;g<bc->margins[mrgn]->G;g++)
	{
		wg = bc->margins[mrgn]->where_is[g];
		for(i=0;i<bc->margins[mrgn]->ng[g];i++)
		{
			//add row i to the block
			idx = bc->margins[mrgn]->idxz[wg][i];
			st = bc->margins[mrgn]->sparse_Y->p[idx];
			end = bc->margins[mrgn]->sparse_Y->p[idx+1];
			for(k=0;k<bc->margins[1-mrgn]->G;k++)
			{
				numzero[k] = bc->margins[1-mrgn]->ng[k];
			}
			for(j=st;j<end;j++)
			{
				z = bc->margins[1-mrgn]->z[ bc->margins[mrgn]->sparse_Y->i[j] ];
				wk = bc->margins[1-mrgn]->where_is[z];
				numzero[z] -= 1;
				bc->model->add_to_stats(bc->margins[mrgn]->sparse_Y->x[j],bc->blocks[wg][wk]->stats,1);
			}
			for(k=0;k<bc->margins[1-mrgn]->G;k++)
			{
				wk = bc->margins[1-mrgn]->where_is[k];
				bc->model->add_zeros_to_stats(numzero[k],bc->blocks[wg][wk]->stats,1);
			}
		}
	}
	
	for(g=0;g<bc->margins[mrgn]->G;g++)
	{
		wg = bc->margins[mrgn]->where_is[g];
		for(k=0;k<bc->margins[1-mrgn]->G;k++)
		{	
			wk = bc->margins[1-mrgn]->where_is[k];
			bc->blocks[wg][wk]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(bc->blocks[wg][wk]->stats,bc->model->hyperparameters);
		}
	}	
	
	free(numzero);
	free(numnonzero);
	for(i=0;i<bc->margins[1-mrgn]->G;i++) free(values[i]);
	free(values);

	return;
}


/*************************************************************************/


/************************ Gibbs sampling/greedy search for allocations *********************************/
	

void update_allocations( struct bcluster *bc, int mrgn )
{

	int i,j,idx,g,gnew,G = bc->margins[mrgn]->G,n = bc->margins[mrgn]->n,*ord,empty=FALSE,*groups/*only greedy can alter the value of empty*/;
	double *pr,*x,max,nc,xtra,L;

	
	pr = calloc(G,sizeof(double));
	ord = calloc(n,sizeof(int));
	groups = calloc(G,sizeof(int));
	for(j=0;j<G;j++)
	{
		groups[j] = j; 
	}
	
	for(i=0;i<n;i++) ord[i] = i;
		
	random_ranshuffle( ord, n ); //randomize order of update
	
	
	for(i=0;i<n;i++)
	{
		idx = ord[i];
		g =bc->margins[mrgn]->z[idx]; //current allocation
		if(!bc->sparse) x = bc->margins[mrgn]->Y[idx];//we may need two copies for efficient margin use
		if(!bc->sparse)
		{
			for(j=0;j<bc->margins[mrgn]->G;j++)
			{
				if(!(g==j)){ 
					pr[j] = get_log_relative_probability_Gibbs(bc,mrgn,x,g,j);
				}else{
					pr[j] = 0.;
				}
			}
		}
		else
		{
			sparse_rep_get_log_relative_probability_Gibbs(bc,mrgn,idx,pr,groups,bc->margins[mrgn]->G);
		}
		
		//if(i == 0 && mrgn==0) printf("\nSparse %d, and pr :",bc->sparse);
		//for(j=0;j<bc->margins[mrgn]->G;j++) printf("%lf,",pr[j]);
		
		if(bc->greedy)
		{
			//this is the part for the greedy search
			empty = (bc->margins[mrgn]->ng[g] == 1) ? TRUE : FALSE;
			//empty = FALSE;
			if(empty)
			{
				xtra = (- lgamma(bc->alpha) - bc->margins[1-mrgn]->G*bc->log_marginal_likelihood_empty
							+ get_log_normalizing_constant_margin(bc,mrgn,bc->margins[mrgn]->G-1)
							- get_log_normalizing_constant_margin(bc,mrgn,bc->margins[mrgn]->G) );
				for(j=0;j<bc->margins[mrgn]->G;j++)
				{
					if(!(g==j)) pr[j] += xtra;
				}
			}
			//find the group that gives the maximum difference in ICL
			gnew = 0;
			max = pr[0];
			for(j=1;j<bc->margins[mrgn]->G;j++)
			{
				if(pr[j]>max)
				{
					gnew = j;
					max = pr[j];
				}
			}
		}
		else
		{
			//renormalize and do Gibbs sampling
			max = get_max(pr,bc->margins[mrgn]->G);
			nc = 0.;
			for(j=0;j<G;j++)
			{
				pr[j] -= max;
				pr[j] = exp(pr[j]);
				nc += pr[j];	
			}
			for(j=0;j<bc->margins[mrgn]->G;j++) pr[j] /= nc;
			gnew = sample_discrete(pr,bc->margins[mrgn]->G);
		}
		
		if(!(gnew == g))
		{
			//need to handle this carefully for the empty and non-empty case...
			//update the components if sampled label is different to previous as normal
			if(bc->greedy && max>0.){
				if(!bc->sparse)
				{
					move_to_new_component(bc,mrgn,x,idx,g,gnew,empty,TRUE);
				}
				else
				{
					sparse_rep_move_to_new_component(bc,mrgn,idx,g,gnew,empty);
				}
			}else if(!bc->greedy){
				if(!bc->sparse)
				{
					move_to_new_component(bc,mrgn,x,idx,g,gnew,empty,TRUE);
				}
				else
				{
					sparse_rep_move_to_new_component(bc,mrgn,idx,g,gnew,empty);
				}
				
			}
			
		}
	}
	free(ord);
	free(pr);
	free(groups);
	return;
}


void update_allocations_alternating( struct bcluster *bc )
{
	//updates row and columns in alternating fashion
	int i,j,mrgn,idx,idmindim,ref,mindim,g,gnew,**ord,**update,empty=FALSE;
	double **pr,*x,max,xtra;

	idmindim = (bc->margins[0]->n > bc->margins[1]->n) ? 0 : 1;
	mindim = (bc->margins[0]->n < bc->margins[1]->n) ? bc->margins[0]->n : bc->margins[1]->n;

	pr = calloc(2,sizeof(double*));
	ord = calloc(2,sizeof(int*));
	update = calloc(2,sizeof(int*));
	for(i=0;i<2;i++)
	{
		pr[i] = calloc(bc->margins[i]->G,sizeof(double));
		ord[i] = calloc(bc->margins[i]->n,sizeof(int));
		update[i] = calloc(bc->margins[i]->n,sizeof(int));
		for(j=0;j<bc->margins[i]->n;j++) ord[i][j] = j;
		//randomize the order the rows and columns are processed in
		random_ranshuffle( ord[i], bc->margins[i]->n );
	}
	
	for(i=0;i<mindim;i++)
	{
		update[idmindim][ ord[1-idmindim][i] ] = 1; //this updates the rows at random within the scan
	}
	for(i=0;i<bc->margins[1-idmindim]->n;i++) update[1-idmindim][i] = 1;
	
	//this bit is special as we want to alternating between the margins
	int rcount = 0;
	int ccount = 0;
	for(i=0;i<bc->margins[1-idmindim]->n;i++)
	{
		for(mrgn=0;mrgn<2;mrgn++)
		{
			if(update[mrgn][i])
			{
				ref = mrgn ? ccount : rcount;
				idx = ord[mrgn][ref];
				g =bc->margins[mrgn]->z[idx]; //current allocation
				x = bc->margins[mrgn]->Y[idx];//we may need two copies for efficient margin use
				for(j=0;j<bc->margins[mrgn]->G;j++)
				{
					if(!(g==j)){ //error here??? 
						pr[mrgn][j] = get_log_relative_probability_Gibbs(bc,mrgn,x,g,j);
					}else{
						pr[mrgn][j] = 0.;
					}
				}
				
				if(bc->greedy)
				{
					//this is the part for the greedy search
					empty = (bc->margins[mrgn]->ng[g] == 1) ? TRUE : FALSE;
					//empty = FALSE;
					if(empty)
					{
						xtra = (- lgamma(bc->alpha) - bc->margins[1-mrgn]->G*bc->log_marginal_likelihood_empty
								+ get_log_normalizing_constant_margin(bc,mrgn,bc->margins[mrgn]->G-1)
								- get_log_normalizing_constant_margin(bc,mrgn,bc->margins[mrgn]->G) );
						for(j=0;j<bc->margins[mrgn]->G;j++)
						{
						if(!(g==j)) pr[mrgn][j] += xtra;
						}
					}
					//find the group that gives the maximum difference in ICL
					gnew = 0;
					max = pr[mrgn][0];
					for(j=1;j<bc->margins[mrgn]->G;j++)
					{
						if(pr[mrgn][j]>max)
						{
							gnew = j;
							max = pr[mrgn][j];
						}
					}
				}
				
				if(!(gnew == g))
				{
					//need to handle this carefully for the empty and non-empty case...
					//update the components if sampled label is different to previous as normal
					move_to_new_component(bc,mrgn,x,idx,g,gnew,empty,TRUE);
				}					
		
				if(mrgn) ccount++; else rcount++;
			}
		}
	
	}
	
	
	for(i=0;i<2;i++)
	{
		free(pr[i]);
		free(ord[i]);
		free(update[i]);
	}
	free(pr);
	free(ord);
	free(update);
	return;
}

void merge_clusters_for_greedy_search(struct bcluster *bc,int mrgn)
{
	//do greedy search over merging two components along the margin if the ICL is 
	//	increased by doing so...
	int g1,g2,gg1,gg2,wg1,wg2,wci,i,j,idx,k=1-mrgn;
	struct block **tblocks = malloc(bc->margins[1-mrgn]->G*sizeof(struct block *));
	for(i=0;i<bc->margins[k]->G;i++) tblocks[i] = bc->model->create_new_block(bc->model->dimensions);
	double *change_ICL = calloc(bc->margins[mrgn]->G,sizeof(double)),dICL=0.,max;
	//if merging, always merge to the cluster with the lower index
	for(g1=0;g1<bc->margins[mrgn]->G;g1++)
	{
		change_ICL[g1] = 0.;
		for(g2=0;g2<bc->margins[mrgn]->G;g2++)
		{
			if(g2!=g1)
			{
				dICL = 0.;
				wg1 = bc->margins[mrgn]->where_is[g1];
				wg2 = bc->margins[mrgn]->where_is[g2];
				//reset the stats
				for(i=0;i<bc->margins[k]->G;i++)
				{
					bc->model->reset_stats(tblocks[i]->stats);
					wci = bc->margins[k]->where_is[i];
					//add stats from both clusters
					if(k)
					{
						bc->model->add_block_stats(bc->blocks[wg1][wci]->stats,tblocks[i]->stats);
						bc->model->add_block_stats(bc->blocks[wg2][wci]->stats,tblocks[i]->stats);
						tblocks[i]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(tblocks[i]->stats,bc->model->hyperparameters);
						dICL -= (bc->blocks[wg1][wci]->log_marginal_likelihood + bc->blocks[wg2][wci]->log_marginal_likelihood);
					}else{
						bc->model->add_block_stats(bc->blocks[wci][wg1]->stats,tblocks[i]->stats);
						bc->model->add_block_stats(bc->blocks[wci][wg2]->stats,tblocks[i]->stats);
						tblocks[i]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(tblocks[i]->stats,bc->model->hyperparameters);
						dICL -= (bc->blocks[wci][wg1]->log_marginal_likelihood + bc->blocks[wci][wg2]->log_marginal_likelihood);
					}
					dICL += tblocks[i]->log_marginal_likelihood;
				}
				dICL += lgamma(bc->margins[mrgn]->ng[g1]+bc->margins[mrgn]->ng[g2]+bc->alpha) 
						- lgamma(bc->margins[mrgn]->ng[g1]+bc->alpha) - lgamma(bc->margins[mrgn]->ng[g2]+bc->alpha);
				dICL += get_log_normalizing_constant_margin(bc,mrgn,bc->margins[mrgn]->G-1) - get_log_normalizing_constant_margin(bc,mrgn,bc->margins[mrgn]->G);
			}
			change_ICL[g2] = dICL;
		}
		//now decide whether to merge g1 and g2... we always merge into the component with the lower index of the two. 
		j = 0;
		max = change_ICL[0];
		for(g2=0;g2<bc->margins[mrgn]->G;g2++)
		{
			if(change_ICL[g2]>max)
			{
				j=g2;
				max=change_ICL[g2];
			}
		}
		g2 = j;
		if(g2!=g1 && max>bc->merge_thresh)
		{
			//printf("\n Merging clusters %d and %d",g1,g2);
			//absorb into the component with the lower index...
			if(g2<g1)
			{
				gg1=g2;
				gg2=g1;
			}else{
				gg1=g1;
				gg2=g2;
			}
			wg1 = bc->margins[mrgn]->where_is[gg1];
			wg2 = bc->margins[mrgn]->where_is[gg2];
			
			for(i=0;i<bc->margins[k]->G;i++)
			{
				wci = bc->margins[k]->where_is[i];
				if(k)
				{
					bc->model->add_block_stats(bc->blocks[wg2][wci]->stats,bc->blocks[wg1][wci]->stats);
					bc->model->destroy_block(bc->blocks[wg2][wci]);
					bc->blocks[wg1][wci]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(bc->blocks[wg1][wci]->stats,bc->model->hyperparameters);
				}else{
					bc->model->add_block_stats(bc->blocks[wci][wg2]->stats,bc->blocks[wci][wg1]->stats);
					bc->model->destroy_block(bc->blocks[wci][wg2]);
					bc->blocks[wci][wg1]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(bc->blocks[wci][wg1]->stats,bc->model->hyperparameters);
				}
				
			}
			for(i=0;i<bc->margins[mrgn]->ng[gg2];i++)
			{
				bc->margins[mrgn]->idxz[wg1][ bc->margins[mrgn]->ng[gg1] + i ] = bc->margins[mrgn]->idxz[wg2][i];
			}
			bc->margins[mrgn]->ng[gg1] += bc->margins[mrgn]->ng[gg2];
			for(i=0;i<bc->margins[mrgn]->n;i++)
			{
				if(bc->margins[mrgn]->z[i] == gg2) bc->margins[mrgn]->z[i] = gg1;
			}
			
			for(i=gg2+1;i<bc->margins[mrgn]->G;i++)
			{
				j = bc->margins[mrgn]->where_is[i];
				bc->margins[mrgn]->where_is[i-1]=j;
				bc->margins[mrgn]->ng[i-1] = bc->margins[mrgn]->ng[i];
				for(j=0;j<bc->margins[mrgn]->n;j++)
				{
					if(bc->margins[mrgn]->z[j] == i) bc->margins[mrgn]->z[j] -= 1;
				}
			}
			bc->margins[mrgn]->G -= 1;	
			
			if(bc->greedy_fast)
			{
				for(i=0;i<bc->margins[mrgn]->n;i++)
				{
					
					idx = -1;
					for(j=0;j<bc->margins[mrgn]->n_component_search[i];j++)
					{
						if(bc->margins[mrgn]->component_search[i][j] == wg2)
						{
							idx = j;
							break;
						}
					}
					
					if(idx != -1)
					{
						bc->margins[mrgn]->n_component_search[i] -= 1;
						for(j=idx;j<bc->margins[mrgn]->n_component_search[i];j++)
						{
							bc->margins[mrgn]->component_search[i][j] = bc->margins[mrgn]->component_search[i][j+1];
						}
					}
				}
				
				for(j=0;j<bc->margins[mrgn]->G;j++)
				{
					i = bc->margins[mrgn]->where_is[j];
					bc->margins[mrgn]->where_is_inv[i] = j;
				}
				
			}	
		}
	}	
	
	for(i=0;i<bc->margins[k]->G;i++) bc->model->destroy_block(tblocks[i]);
	free(tblocks);
	free(change_ICL);
	return;
}


/******this function does fast greedy search where very unlikely components are not visited using search history*******/

void update_allocations_greedy_fast(struct bcluster *bc,int mrgn)
{

	int i,j,jj,idx,nsearch,g,k,gnew,*ord,*groups,nprune, where_was_g,empty=FALSE,*prune_out/*only greedy can alter the value of empty*/;
	double *pr,*x,max,xtra;
	
	int n = bc->margins[mrgn]->n;
	pr = calloc(bc->margins[mrgn]->G,sizeof(double));
	groups = calloc(bc->margins[mrgn]->G,sizeof(int));
	prune_out = calloc(bc->margins[mrgn]->G,sizeof(int));
	ord = calloc(n,sizeof(int));
	for(i=0;i<n;i++) ord[i] = i;
	random_ranshuffle( ord, n ); //randomize order of update


	if(bc->greedy_prune)
	{
		//bc->greedy_prune_thresh = log(bc->delta/(1.-bc->delta)) - log(bc->margins[mrgn]->G-1.);
	}
	
	
	for(i=0;i<n;i++)
	{
		idx = ord[i];
		g =bc->margins[mrgn]->z[idx]; //current allocation
		
		if(!bc->sparse)
		{
			x = bc->margins[mrgn]->Y[idx];//we may need two copies for efficient margin use
			nsearch = bc->margins[mrgn]->n_component_search[idx];
			for(j=0;j<nsearch;j++)
			{
				//get component number to propose to move to
				k = bc->margins[mrgn]->where_is_inv[ bc->margins[mrgn]->component_search[idx][j] ]; 
				groups[j] = k;
				if(g!=k)
				{
					pr[j] = get_log_relative_probability_Gibbs(bc,mrgn,x,g,k);
				}else{
					pr[j] = 0.;
				}	
			}
		}
		else
		{
			//this is for the sparse representation of the data matrix... we need to modify the pr[j]
			// calculation as it makes much more sense to process a row at a time fully
			nsearch = bc->margins[mrgn]->n_component_search[idx];
			for(j=0;j<nsearch;j++)
			{
				k = bc->margins[mrgn]->where_is_inv[ bc->margins[mrgn]->component_search[idx][j] ];
				groups[j] = k; 
			}
			sparse_rep_get_log_relative_probability_Gibbs(bc,mrgn,idx,pr,groups,nsearch); //Bug track:: 0
			
		}
		
		/*printf("\nval of prob vector\n");
			for(j=0;j<nsearch;j++) printf(" %lf ",pr[j]);
			printf("\n");*/

		//this is the part for the greedy search
		empty = (bc->margins[mrgn]->ng[g] == 1) ? TRUE : FALSE;
		//empty = FALSE;
		if(empty)
		{
			xtra = (- lgamma(bc->alpha) - bc->margins[1-mrgn]->G*bc->log_marginal_likelihood_empty
						+ get_log_normalizing_constant_margin(bc,mrgn,bc->margins[mrgn]->G-1)
						- get_log_normalizing_constant_margin(bc,mrgn,bc->margins[mrgn]->G) );
			for(j=0;j<nsearch;j++)
			{
				k = groups[j]; 
				if(!(g==k)) pr[j] += xtra;
			}
		}
		//find the group that gives the maximum difference in ICL
		gnew = groups[0];
		max = pr[0];
		for(j=1;j<nsearch;j++)
		{
			if(pr[j]>max)
			{
				gnew = groups[j];
				max = pr[j];
			}
		}
		
		
		if(!(gnew == g))
		{
			where_was_g = bc->margins[mrgn]->where_is[g];
			//need to handle this carefully for the empty and non-empty case...
			//update the components if sampled label is different to previous as normal
			if(!bc->sparse)
			{
				move_to_new_component(bc,mrgn,x,idx,g,gnew,empty,TRUE);
			}
			else
			{
				sparse_rep_move_to_new_component(bc,mrgn,idx,g,gnew,empty); //Bug track:: 1
			}
			
			//where_is[g] has now been modified to allow for empty component
			//if empty then update the where_is_inv
			if(empty)
			{
			
				//bc->greedy_prune_thresh = log(bc->delta/(1.-bc->delta)) - log(bc->margins[mrgn]->G-1.);
			
				//if g has been absorbed we need to tell not to look in g anymore
				// for any of the indexes
				for(j=0;j<n;j++)
				{
					k=0;
					while(k<bc->margins[mrgn]->n_component_search[j])
					{
						if(bc->margins[mrgn]->component_search[j][k] == where_was_g) break;
						k++;
					}
					//the problem was here (now fixed): if g cannot be found in the list, the thing inside TRUE was being carried out anyway
					if(k < bc->margins[mrgn]->n_component_search[j]) //if k is equal to this then component not there anyway
					{
						bc->margins[mrgn]->n_component_search[j] -= 1;
						for(jj=k;jj<bc->margins[mrgn]->n_component_search[j];jj++)
						{
							bc->margins[mrgn]->component_search[j][jj] = bc->margins[mrgn]->component_search[j][jj+1];
						}
					}
				}
				
				
				for(j=0;j<bc->margins[mrgn]->G;j++)
				{
					k = bc->margins[mrgn]->where_is[j];
					bc->margins[mrgn]->where_is_inv[k] = j;
				}
				
				//need special thing here for greedy prune, as this can affect component_search!!!
				if(bc->greedy_prune)
				{
					jj=0;
					while(groups[jj]!=g) jj++;
					for(j=jj;j<bc->margins[mrgn]->n_component_search[idx];j++) pr[j] = pr[j+1];
					
				}
			}
		}
		
		//there is something funny here:: maybe it's good to think about the greedy threshold again when
		// component will become empty
		
		if(bc->greedy_prune)
		{
			//don't bother searching the components that had ICL change of < bc->greedy_prune_thresh
			nprune = 0;
			for(j=0;j<bc->margins[mrgn]->n_component_search[idx];j++)
			{
				if(max - pr[j] > 150.) nprune++;
				
				
				//if(pr[j]<bc->greedy_prune_thresh) nprune++;
			}
			
			
			//printf("\nSize of nprune = %d",nprune);
			//printf("\nSize of nprune = %d",nprune);
			if(nprune>0)
			{
				k=0;
				for(j=0;j<bc->margins[mrgn]->n_component_search[idx];j++)
				{
					if(max - pr[j] > 150./*log((1.-bc->delta)*(bc->margins[mrgn]->G)/bc->delta)*/)
					{
						prune_out[k] = bc->margins[mrgn]->component_search[idx][j];//groups[j];//this operates on the where_is
						k++;
					}
				}
				//now cycle through the elements to be pruned out
				for(j=0;j<nprune;j++)
				{
					k=0;
					while(bc->margins[mrgn]->component_search[idx][k] != prune_out[j]) k++;
					bc->margins[mrgn]->n_component_search[idx] -= 1;
					for(jj=k;jj<bc->margins[mrgn]->n_component_search[idx];jj++) 
						bc->margins[mrgn]->component_search[idx][jj] = bc->margins[mrgn]->component_search[idx][jj+1];
				}
				//free(prune_out);
			}	
		}
	}
	free(prune_out);
	free(pr);
	free(groups);
	free(ord);
	return;


}

void sparse_rep_get_log_relative_probability_Gibbs(struct bcluster *bc,int mrgn,int idx,double *pr,int *groups,int nsearch)
{
	//this function uses the sparse representation of the data to get the log relative probability of the gibbs steps...
	int i,j,k,l,z,r1,r2,c1,c2,*numzero,*numnonzero,wk,wg,wl;
	numzero = calloc(bc->margins[1-mrgn]->G,sizeof(int));
	numnonzero = calloc(bc->margins[1-mrgn]->G,sizeof(int));
	for(i=0;i<bc->margins[1-mrgn]->G;i++) numzero[i] = bc->margins[1-mrgn]->ng[i]; //imagine first that dominantly sparse 
	int st = bc->margins[mrgn]->sparse_Y->p[idx],end = bc->margins[mrgn]->sparse_Y->p[idx+1];
	int nnz = end-st;
	double **values = calloc(bc->margins[1-mrgn]->G,sizeof(double*)),ldiff;
	for(i=0;i<bc->margins[1-mrgn]->G;i++) values[i] = calloc(nnz,sizeof(double));

	for(i=st;i<end;i++)
	{
		//get relevant non-zero row/col
		j = bc->margins[mrgn]->sparse_Y->i[ i ]; //this gives the position of the nz entry in row/col
		//get cluster that this belongs to
		z = bc->margins[1-mrgn]->z[ j ];
		numzero[z] -= 1;
		values[ z ][ numnonzero[z] ] = bc->margins[mrgn]->sparse_Y->x[ i ];
		numnonzero[z] += 1;		
	}
	
	//get current allocation and location of block
	k = bc->margins[mrgn]->z[idx];
	wk = bc->margins[mrgn]->where_is[k];
	
	for(i=0;i<nsearch;i++)
	{
		if(groups[i] != k)
		{
			ldiff = 0.;
			wg = bc->margins[mrgn]->where_is[ groups[i] ]; //this gives the cluster to add to 
			switch(mrgn)
			{
				case 0:
					r1 = wk;
					r2 = wg;
				break;
				case 1:
					c1 = wk;
					c2 = wg;
				break;
			}
						
			for(j=0;j<bc->margins[1-mrgn]->G;j++)
			{
				wl = bc->margins[1-mrgn]->where_is[j];
				switch(mrgn)
				{
					case 0:
						c1 = wl;
						c2 = wl;
					break;
					case 1:
						r1 = wl;
						r2 = wl;
					break;
				}
				
				for(l=0;l<numnonzero[ j ];l++)
				{
					//take out of the current cluster
					bc->model->add_to_stats(values[j][l],bc->blocks[r1][c1]->stats,-1);
					//add to the proposed cluster
					bc->model->add_to_stats(values[j][l],bc->blocks[r2][c2]->stats,1);
				}
				//take all the zeros out of current cluster
				bc->model->add_zeros_to_stats(numzero[j],bc->blocks[r1][c1]->stats,-1);
				//add zeros to proposed cluster
				bc->model->add_zeros_to_stats(numzero[j],bc->blocks[r2][c2]->stats,1);
				
				/*printf("\nStats for row blocks %d and %d and col block %d ",k, groups[i], j);
				printf("\n Counts for zero: %lf and %lf ",((struct Multinom_stats *)bc->blocks[r1][c1]->stats)->counts[0],((struct Multinom_stats *)bc->blocks[r2][c2]->stats)->counts[0]);
				printf("\n Counts for one : %lf and %lf ",((struct Multinom_stats *)bc->blocks[r1][c1]->stats)->counts[1],((struct Multinom_stats *)bc->blocks[r2][c2]->stats)->counts[1]);*/
				
				ldiff += bc->model->compute_log_marginal_likelihood_from_stats(bc->blocks[r1][c1]->stats,bc->model->hyperparameters)
					   + bc->model->compute_log_marginal_likelihood_from_stats(bc->blocks[r2][c2]->stats,bc->model->hyperparameters)
					   - bc->blocks[r1][c1]->log_marginal_likelihood
					   - bc->blocks[r2][c2]->log_marginal_likelihood;
				
				//put the statistics back to how they were
				for(l=0;l<numnonzero[ j ];l++)
				{
					bc->model->add_to_stats(values[j][l],bc->blocks[r1][c1]->stats,1);
					bc->model->add_to_stats(values[j][l],bc->blocks[r2][c2]->stats,-1);
				}
				bc->model->add_zeros_to_stats(numzero[j],bc->blocks[r1][c1]->stats,1);
				bc->model->add_zeros_to_stats(numzero[j],bc->blocks[r2][c2]->stats,-1);
			}
			
			pr[i] = ldiff + log(bc->margins[mrgn]->ng[ groups[i] ] + bc->alpha) - log(bc->margins[mrgn]->ng[k] - 1. + bc->alpha);
			
		}
		else
		{
			pr[i] = 0.;
		}
	
	}
	
	
	free(numzero);
	free(numnonzero);
	for(i=0;i<bc->margins[1-mrgn]->G;i++) free(values[i]);
	free(values);
}


/************ this function performs move 1 from Nobile and Fearnside for sampling of clusterings **************/

int update_allocations_with_metropolis_move_1(struct bcluster *bc,int mrgn,int *accepted,int *proposed)
/*this performs the move M1 taken from Nobile and Fearnside (2007) Stats and Computing 17: p147-162*/
{

	/*don't perform this move unless at least two components in mrgn*/
	if(bc->margins[mrgn]->G<2) return(TRUE);
	
	*proposed += 1;
	
	
	int i,j,k,ii,g1,g2,ig1,ig2,ng1,ng2, w_i,
		jidx,wc,g,ntot,gnew,*indexes,*proposed_alloc;
	double p,log_acceptance,ag1=bc->alpha,ag2=bc->alpha;
	struct block **blocks_g1,**blocks_g2;
	
	g1 = (int)( bc->margins[mrgn]->G * runif(0.0,1.0) );
	g2 = g1;
	while(g2 == g1){
		g2 = (int)( bc->margins[mrgn]->G * runif(0.0,1.0) );
	}
	
	ig1 = bc->margins[mrgn]->where_is[g1];
	ig2 = bc->margins[mrgn]->where_is[g2];
	
	ntot = bc->margins[mrgn]->ng[g1] + bc->margins[mrgn]->ng[g2];
	
	if(ntot == 0) return(TRUE);
	
	blocks_g1 = (struct block **)malloc(bc->margins[1-mrgn]->G*sizeof(struct block *));  
	blocks_g2 = (struct block **)malloc(bc->margins[1-mrgn]->G*sizeof(struct block *));
	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		blocks_g1[i] = bc->model->create_new_block(bc->model->dimensions);
		blocks_g2[i] = bc->model->create_new_block(bc->model->dimensions);
	}
	
	/*create the structures to store the new blocks*/
	blocks_g1 = (struct block **)malloc(bc->margins[1-mrgn]->G*sizeof(struct block *));  
	blocks_g2 = (struct block **)malloc(bc->margins[1-mrgn]->G*sizeof(struct block *));
	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		blocks_g1[i] = bc->model->create_new_block(bc->model->dimensions);
		blocks_g2[i] = bc->model->create_new_block(bc->model->dimensions);
	}
	
	indexes = calloc(ntot,sizeof(int));
	proposed_alloc = calloc(ntot,sizeof(int));
	
	k=0;
	for(i=0;i<bc->margins[mrgn]->n;i++)
	{
		if(bc->margins[mrgn]->z[i] == g1 || bc->margins[mrgn]->z[i] == g2)
		{
			indexes[k] = i;
			k+=1;
		}
	}
	
	p = rbeta(ag1,ag2);
	
	ng1 = 0; ng2 = 0;
	
	for(i=0;i<ntot;i++)
	{
		ii = indexes[i];
		
		if( runif(0.0,1.0) < p)
		{
			/*reallocate to g1*/
			proposed_alloc[i] = g1;
			ng1 += 1;
			/*add the stuff to the stats*/
			for(j=0;j<bc->margins[1-mrgn]->G;j++)
			{
				w_i = bc->margins[1-mrgn]->where_is[j];
				
				if(bc->multivariate_model)
				{
					bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g1[j]->stats,TRUE);
				}else{
					for(k=0;k<bc->margins[1-mrgn]->ng[j];k++)
					{
						jidx = bc->margins[1-mrgn]->idxz[ w_i ][k];
						bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g1[j]->stats,TRUE);
					}
				}
			
			}
				
		}else{
			/*reallocate to g2*/
			proposed_alloc[i] = g2;
			ng2 += 1;
			/*add the stuff to the stats*/
			for(j=0;j<bc->margins[1-mrgn]->G;j++)
			{
				w_i = bc->margins[1-mrgn]->where_is[j];
				
				if(bc->multivariate_model)
				{
					bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g2[j]->stats,TRUE);
				}else
				{
					for(k=0;k<bc->margins[1-mrgn]->ng[j];k++)
					{
						jidx = bc->margins[1-mrgn]->idxz[ w_i ][k];
						bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g2[j]->stats,TRUE);
					}
				}
			}
			
		}
	
	}
	
	
	/*compute the acceptance probability*/
	log_acceptance = 0.;
	
	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		blocks_g1[i]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(blocks_g1[i]->stats,bc->model->hyperparameters);
		blocks_g2[i]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(blocks_g2[i]->stats,bc->model->hyperparameters);
		log_acceptance += blocks_g1[i]->log_marginal_likelihood + blocks_g2[i]->log_marginal_likelihood;
		wc = bc->margins[1-mrgn]->where_is[i];
		if(mrgn)
		{
			log_acceptance -= ( bc->blocks[wc][ig1]->log_marginal_likelihood
							+ bc->blocks[wc][ig2]->log_marginal_likelihood );
		}else{
			log_acceptance -= ( bc->blocks[ig1][wc]->log_marginal_likelihood 
							+ bc->blocks[ig2][wc]->log_marginal_likelihood );
		}
	}
	
	
	if(log( runif(0.0,1.0) ) < log_acceptance)
	{
		*accepted += 1;
		
		for(j=0;j<ntot;j++)
		{
			if(proposed_alloc[ j ] != bc->margins[mrgn]->z[ indexes[j] ] )
			{
				g = bc->margins[mrgn]->z[ indexes[j] ];
				gnew = proposed_alloc[ j ];//here?
				/*if the proposed allocation different to current then move...*/
				move_to_new_component(bc,mrgn,bc->margins[mrgn]->Y[ indexes[j] ],indexes[j],g,gnew,FALSE,FALSE);
			}
		}
		
		for(i=0;i<bc->margins[1-mrgn]->G;i++)
		{
			//the blocks were all updated, just need to recompute the marginal likelihoods now
			if(mrgn)
			{
				bc->blocks[ bc->margins[1-mrgn]->where_is[i] ][ ig1 ]->log_marginal_likelihood = blocks_g1[i]->log_marginal_likelihood;		
				bc->blocks[ bc->margins[1-mrgn]->where_is[i] ][ ig2 ]->log_marginal_likelihood = blocks_g2[i]->log_marginal_likelihood;
			}else{
			
				bc->blocks[ ig1 ][ bc->margins[1-mrgn]->where_is[i] ]->log_marginal_likelihood = blocks_g1[i]->log_marginal_likelihood;	
				bc->blocks[ ig2 ][ bc->margins[1-mrgn]->where_is[i] ]->log_marginal_likelihood = blocks_g2[i]->log_marginal_likelihood;
			}
		}
	
	}
	
	free(indexes);
	free(proposed_alloc);
	
	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		bc->model->destroy_block(blocks_g1[i]);
		bc->model->destroy_block(blocks_g2[i]);
	}
	free(blocks_g1);
	free(blocks_g2);
	
	return(TRUE);
}


int update_allocations_with_metropolis_move_2(struct bcluster *bc,int mrgn,int *accepted,int *proposed)
{

	/*don't perform unless at least two clusters*/
	if(bc->margins[mrgn]->G < 2)
	{
		return(TRUE);
	}
	
	int i,ii,j,k,l,g1,g2,ig1,ig2,g,gnew,curr_n_g1,m,c=0,w_i,wc,jidx;
	int *indexes,*order,n_g1=0,n_g2=0;
	double log_acceptance;
	struct block **blocks_g1,**blocks_g2;
	
	/*sample the two components*/
	g1 = (int)( bc->margins[mrgn]->G * runif(0.0,1.0) );
	g2 = g1;
	while(g2 == g1){
		g2 = (int)( bc->margins[mrgn]->G * runif(0.0,1.0) );
	}	
	
	/*find where the components are*/
	ig1 = bc->margins[mrgn]->where_is[g1];
	ig2 = bc->margins[mrgn]->where_is[g2];
	
	if(bc->margins[mrgn]->ng[g1] == 0)
	{
		/*cannot perform move in this case...*/
		return(TRUE);
	}
	
	/*current component sizes*/
	curr_n_g1 = bc->margins[mrgn]->ng[g1];
	
	/*allocate blocks*/
	blocks_g1 = (struct block **)malloc(bc->margins[1-mrgn]->G*sizeof(struct block *));  
	blocks_g2 = (struct block **)malloc(bc->margins[1-mrgn]->G*sizeof(struct block *));
	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		blocks_g1[i] = bc->model->create_new_block(bc->model->dimensions);
		blocks_g2[i] = bc->model->create_new_block(bc->model->dimensions);
	}
	
	/*create the structures to store the new blocks*/
	blocks_g1 = (struct block **)malloc(bc->margins[1-mrgn]->G*sizeof(struct block *));  
	blocks_g2 = (struct block **)malloc(bc->margins[1-mrgn]->G*sizeof(struct block *));
	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		blocks_g1[i] = bc->model->create_new_block(bc->model->dimensions);
		blocks_g2[i] = bc->model->create_new_block(bc->model->dimensions);
	}	
	
	*proposed += 1;
	
	order = calloc(curr_n_g1,sizeof(int));
	for(i=0;i<curr_n_g1;i++)
	{
		order[i] = i;
	}
	
	/*shuffle order*/
	random_ranshuffle( order, curr_n_g1 );
	
	indexes = calloc(curr_n_g1,sizeof(int));
	for(i=0;i<bc->margins[mrgn]->n;i++)
	{
		if(bc->margins[mrgn]->z[i] == g1)
		{
			indexes[c] = i;
			c+=1;
		}
	}

	m = (int)( curr_n_g1 * runif(0.0,1.0) );
	
	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		j = bc->margins[1-mrgn]->where_is[i];
		if(mrgn)
		{
			bc->model->copy_block(bc->blocks[ j ][ig1],blocks_g1[i]);
			bc->model->copy_block(bc->blocks[ j ][ig2],blocks_g2[i]);
		}
		else
		{
			bc->model->copy_block(bc->blocks[ig1][ j ],blocks_g1[i]);
			bc->model->copy_block(bc->blocks[ig2][ j ],blocks_g2[i]);
		}
	}
	
	for(i=0;i<m;i++)
	{
		/*take the first m shuffled indexes and reallocate from g1 to g2*/
		l = order[i];
		ii = indexes[l];
		
		for(j=0;j<bc->margins[1-mrgn]->G;j++)
		{
			w_i = bc->margins[1-mrgn]->where_is[j];
			
			if(bc->multivariate_model)
			{
				bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g1[j]->stats,FALSE);
				bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g2[j]->stats,TRUE);
			}
			else
			{
				for(k=0;k<bc->margins[1-mrgn]->ng[j];k++)
				{
					jidx = bc->margins[1-mrgn]->idxz[w_i][k];
					bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g1[j]->stats,FALSE);
					bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g2[j]->stats,TRUE);
				}
			}
		
		}		
	}
	
	log_acceptance = 0.;
	
	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		blocks_g1[i]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(blocks_g1[i]->stats,bc->model->hyperparameters);
		blocks_g2[i]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(blocks_g2[i]->stats,bc->model->hyperparameters);
		log_acceptance += blocks_g1[i]->log_marginal_likelihood + blocks_g2[i]->log_marginal_likelihood;
		wc = bc->margins[1-mrgn]->where_is[i];
		if(mrgn)
		{
			log_acceptance -= ( bc->blocks[wc][ig1]->log_marginal_likelihood
							+ bc->blocks[wc][ig2]->log_marginal_likelihood );
		}else{
			log_acceptance -= ( bc->blocks[ig1][wc]->log_marginal_likelihood 
							+ bc->blocks[ig2][wc]->log_marginal_likelihood );
		}
	}
	
	log_acceptance += ( lgamma(bc->margins[mrgn]->ng[g1]-m+bc->alpha) 
					+ lgamma(bc->margins[mrgn]->ng[g2]+m+bc->alpha) 
					- lgamma(bc->margins[mrgn]->ng[g1]+bc->alpha) 
					- lgamma(bc->margins[mrgn]->ng[g2]+bc->alpha) )
					+ log(bc->margins[mrgn]->ng[g1]) - log(bc->margins[mrgn]->ng[g2]+m)
					+lgamma(bc->margins[mrgn]->ng[g1]+1.) 
					+lgamma(bc->margins[mrgn]->ng[g2]+1.)
					-lgamma(bc->margins[mrgn]->ng[g1]-m+1.) 
					-lgamma(bc->margins[mrgn]->ng[g2]+m+1.);
	
	if(log( runif(0.0,1.0) ) < log_acceptance)
	{
		*accepted += 1;
		
		for(j=0;j<m;j++)
		{
		
			l = order[j];
			ii = indexes[l];
			
			g = g1;
			gnew = g2;
			
			move_to_new_component(bc,mrgn,bc->margins[mrgn]->Y[ii],ii,g,gnew,FALSE,FALSE);
		}
		
		for(i=0;i<bc->margins[1-mrgn]->G;i++)
		{
			//the blocks were all updated, just need to recompute the marginal likelihoods now
			if(mrgn)
			{
				bc->blocks[ bc->margins[1-mrgn]->where_is[i] ][ ig1 ]->log_marginal_likelihood = blocks_g1[i]->log_marginal_likelihood;		
				bc->blocks[ bc->margins[1-mrgn]->where_is[i] ][ ig2 ]->log_marginal_likelihood = blocks_g2[i]->log_marginal_likelihood;
			}else{
			
				bc->blocks[ ig1 ][ bc->margins[1-mrgn]->where_is[i] ]->log_marginal_likelihood = blocks_g1[i]->log_marginal_likelihood;	
				bc->blocks[ ig2 ][ bc->margins[1-mrgn]->where_is[i] ]->log_marginal_likelihood = blocks_g2[i]->log_marginal_likelihood;
			}
		}
	
	}
	
	free(indexes);
	free(order);
	
	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		bc->model->destroy_block(blocks_g1[i]);
		bc->model->destroy_block(blocks_g2[i]);
	}
	free(blocks_g1);
	free(blocks_g2);
	

	return(TRUE);
}

int update_allocations_with_metropolis_move_3(struct bcluster *bc,int mrgn,int *accepted,int *proposed)
{

	if(bc->margins[mrgn]->G < 2)
	{
		return(TRUE);
	}

	int i,ii,j,k,l,g1,g2,ig1,ig2,g,gnew,ntot,c=0,w_i,jidx,n_g1=0,n_g2=0,fl;
	int *indexes,*order,*proposed_allocation;
	double w,log_acceptance, log_transition_z_to_zprime=0.,log_transition_zprime_to_z=0.,l1,l2,h1,h2,p1,a;
	struct block **blocks_g1, **blocks_g2;
	
	/*sample the two components*/
	g1 = (int)( bc->margins[mrgn]->G * runif(0.0,1.0) );
	g2 = g1;
	while(g2 == g1)
	{
		g2 = (int)( bc->margins[mrgn]->G * runif(0.0,1.0) );
	}
	
	ig1 = bc->margins[mrgn]->where_is[g1];
	ig2 = bc->margins[mrgn]->where_is[g2];
	
	ntot = bc->margins[mrgn]->ng[g1] + bc->margins[mrgn]->ng[g2];
	
	if(ntot == 0)
	{
		return(TRUE);
	}
	
	*proposed += 1;
	
	indexes = calloc(ntot,sizeof(int));
	order = calloc(ntot,sizeof(int));
	proposed_allocation = calloc(ntot,sizeof(int));
	
	for(i=0;i<bc->margins[mrgn]->n;i++)
	{
		if(bc->margins[mrgn]->z[i] == g1 || bc->margins[mrgn]->z[i] == g2)
		{
			indexes[c] = i;
			c += 1;
		}
	}
	
	for(i=0;i<ntot;i++) order[i] = i;
	
	/*shuffle order of processing*/
	random_ranshuffle( order, ntot );

	/*allocate blocks*/
	blocks_g1 = (struct block **)malloc(bc->margins[1-mrgn]->G*sizeof(struct block *));  
	blocks_g2 = (struct block **)malloc(bc->margins[1-mrgn]->G*sizeof(struct block *));
	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		blocks_g1[i] = bc->model->create_new_block(bc->model->dimensions);
		blocks_g2[i] = bc->model->create_new_block(bc->model->dimensions);
	}
	
	
	/*get first*/
	k = order[0];
	ii = indexes[k];

	
	if(bc->margins[mrgn]->z[ii] == g1)
	{
		for(j=0;j<bc->margins[1-mrgn]->G;j++)
		{
			w_i = bc->margins[1-mrgn]->where_is[j];
			
			if(bc->multivariate_model)
			{
				bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g1[j]->stats,TRUE);
			}
			else
			{
				for(l=0;l<bc->margins[1-mrgn]->ng[j];l++)
				{
					jidx = bc->margins[1-mrgn]->idxz[w_i][l];
					bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g1[j]->stats,TRUE);
				}
			}
		}
		n_g1 += 1;
		proposed_allocation[0] = g1;
		log_transition_z_to_zprime = log(.5);
	}
	else
	{
		for(j=0;j<bc->margins[1-mrgn]->G;j++)
		{
			w_i = bc->margins[1-mrgn]->where_is[j];
			
			if(bc->multivariate_model)
			{
				bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g2[j]->stats,TRUE);
			}
			else
			{
				for(l=0;l<bc->margins[1-mrgn]->ng[j];l++)
				{
					jidx = bc->margins[1-mrgn]->idxz[w_i][l];
					bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g2[j]->stats,TRUE);
				}
			}
		}	
		n_g2 += 1;
		proposed_allocation[0] = g2;
		log_transition_z_to_zprime = log(.5);
	}
	
	log_transition_zprime_to_z = log(.5);
	
	for(i=1;i<ntot;i++)
	{
		//Rprintf("\ni is %d",i);	
		k = order[i];
		ii = indexes[k];
		
		/*compute probability generated from g1*/
		h1=0.;h2=0.;l1=0.;l2=0.;
		for(j=0;j<bc->margins[1-mrgn]->G;j++)
		{
			h1 += bc->model->compute_log_marginal_likelihood_from_stats(blocks_g1[j]->stats,bc->model->hyperparameters); 
			h2 += bc->model->compute_log_marginal_likelihood_from_stats(blocks_g2[j]->stats,bc->model->hyperparameters);
			w_i = bc->margins[1-mrgn]->where_is[j];
			
			if(bc->multivariate_model)
			{
				bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g1[j]->stats,TRUE);
				bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g2[j]->stats,TRUE);
			}
			else
			{
				for(l=0;l<bc->margins[1-mrgn]->ng[j];l++)
				{
					jidx = bc->margins[1-mrgn]->idxz[w_i][l];
					bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g1[j]->stats,TRUE);
					bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g2[j]->stats,TRUE);
				}
			}
			l1 += bc->model->compute_log_marginal_likelihood_from_stats(blocks_g1[j]->stats,bc->model->hyperparameters);
			l2 += bc->model->compute_log_marginal_likelihood_from_stats(blocks_g2[j]->stats,bc->model->hyperparameters);
		}
		
		a = l1 + h2 - l2 - h1;
		w = ((bc->alpha + n_g1)/(bc->alpha + n_g2))*exp(a);
		p1 = w/(1.+w);
		
		fl=FALSE;
		if(p1 == 1.||p1 == 0.)
		{
			fl = TRUE;
		}
		
		/*make a draw*/
		if( runif(0.0,1.0) < p1)
		{
			/*put in g1*/
			n_g1 += 1;
			if(!(bc->margins[mrgn]->z[ii] == g1))
			{
				if(fl){
					if(p1==0.) p1 = 1E-8; else p1 = 1.-1E-8;//approximation for p1 close to 1
				}
				log_transition_z_to_zprime += log(p1);
				log_transition_zprime_to_z += log(1.-p1);
			}
			proposed_allocation[i] = g1;
			/*take the entries out of block g2*/
			for(j=0;j<bc->margins[1-mrgn]->G;j++)
			{
				w_i = bc->margins[1-mrgn]->where_is[j];
				
				if(bc->multivariate_model)
				{
					bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g2[j]->stats,FALSE);
				}
				else
				{
					for(l=0;l<bc->margins[1-mrgn]->ng[j];l++)
					{
						jidx = bc->margins[1-mrgn]->idxz[w_i][l];
						bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g2[j]->stats,FALSE);
					}
				}				
			}
		}
		else
		{
			/*put in g2*/
			n_g2 += 1;
			if(!(bc->margins[mrgn]->z[ii] == g2))
			{
				if(fl){
					if(p1==0.) p1 = 1E-8; else p1 = 1.-1E-8;//approximation for p1 close to 1
				}
				log_transition_z_to_zprime += log(1.-p1);
				log_transition_zprime_to_z += log(p1);
			}
			proposed_allocation[i] = g2;
			/*take entries back out of block g1*/
			for(j=0;j<bc->margins[1-mrgn]->G;j++)
			{
				w_i = bc->margins[1-mrgn]->where_is[j];
				
				if(bc->multivariate_model)
				{
					bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g1[j]->stats,FALSE);
				}
				else
				{
					for(l=0;l<bc->margins[1-mrgn]->ng[j];l++)
					{
						jidx = bc->margins[1-mrgn]->idxz[w_i][l];
						bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g1[j]->stats,FALSE);
					}
				}				
			}			
		}
	
	}
	
	log_acceptance = 0.;
	
	for(j=0;j<bc->margins[1-mrgn]->G;j++)
	{
		blocks_g1[j]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(blocks_g1[j]->stats,bc->model->hyperparameters);
		blocks_g2[j]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(blocks_g2[j]->stats,bc->model->hyperparameters);
		log_acceptance += blocks_g1[j]->log_marginal_likelihood + blocks_g2[j]->log_marginal_likelihood;
		if(mrgn)
		{
			log_acceptance -= ( bc->blocks[ bc->margins[1-mrgn]->where_is[j] ][ig1]->log_marginal_likelihood
						      + bc->blocks[ bc->margins[1-mrgn]->where_is[j] ][ig2]->log_marginal_likelihood);
		}
		else
		{
			log_acceptance -= ( bc->blocks[ig1][ bc->margins[1-mrgn]->where_is[j] ]->log_marginal_likelihood
						      + bc->blocks[ig2][ bc->margins[1-mrgn]->where_is[j] ]->log_marginal_likelihood);		
		}
	}
	
	log_acceptance += lgamma(n_g1 + bc->alpha) + lgamma(n_g2 + bc->alpha) 
					- lgamma(bc->margins[mrgn]->ng[g1]+bc->alpha) - lgamma(bc->margins[mrgn]->ng[g2]+bc->alpha)
					- log_transition_z_to_zprime + log_transition_zprime_to_z;
				
		
	if(log( runif(0.0,1.0) )<log_acceptance)
	{
		//do the acceptance stuff in here
		
		*accepted += 1;
		
		for(j=0;j<ntot;j++)
		{
		
			l = order[j];
			ii = indexes[l];
			
			if(proposed_allocation[j] != bc->margins[mrgn]->z[ii])
			{
				g = (proposed_allocation[j] == g1 ? g2 : g1);
				gnew = (proposed_allocation[j] == g1 ? g1 : g2);
				move_to_new_component(bc,mrgn,bc->margins[mrgn]->Y[ii],ii,g,gnew,FALSE,FALSE);
			}
			
		}
		
		for(i=0;i<bc->margins[1-mrgn]->G;i++)
		{
			//the blocks were all updated, just need to recompute the marginal likelihoods now
			if(mrgn)
			{
				bc->blocks[ bc->margins[1-mrgn]->where_is[i] ][ ig1 ]->log_marginal_likelihood = blocks_g1[i]->log_marginal_likelihood;		
				bc->blocks[ bc->margins[1-mrgn]->where_is[i] ][ ig2 ]->log_marginal_likelihood = blocks_g2[i]->log_marginal_likelihood;
			}else{
			
				bc->blocks[ ig1 ][ bc->margins[1-mrgn]->where_is[i] ]->log_marginal_likelihood = blocks_g1[i]->log_marginal_likelihood;	
				bc->blocks[ ig2 ][ bc->margins[1-mrgn]->where_is[i] ]->log_marginal_likelihood = blocks_g2[i]->log_marginal_likelihood;
			}
		}


		
	}

	free(indexes);
	free(order);
	free(proposed_allocation);
	
	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		bc->model->destroy_block(blocks_g1[i]);
		bc->model->destroy_block(blocks_g2[i]);
	}
	free(blocks_g1);
	free(blocks_g2);
	
	return(TRUE);

}

//moves that change the number of groups

int update_allocations_with_eject_move(struct bcluster *bc,int mrgn,int *accepted,int *proposed,double pr_ej_G,double pr_ej_Gp1)
{

	int i,ii,j,l,g1,g2,ig1,ig2,ng1,ng2,ntot,c=0,w_i,jidx;
	int *indexes,*proposed_allocation,g,gnew;
	double w,a,prob_put_in_g2,log_acceptance
	,log_transition_z_to_zprime=0.,log_transition_zprime_to_z=0.;
	
	struct block **blocks_g1, **blocks_g2;
	
	*proposed += 1;
	
	/*sample the ejecting component*/
	g1 = (int)( bc->margins[mrgn]->G * runif(0.0,1.0) ) ;
	g2 = bc->margins[mrgn]->G;
	
	/*find where in mixmod->components g1 is*/
	ig1 = bc->margins[mrgn]->where_is[g1];	
	
	ntot = bc->margins[mrgn]->ng[g1];

	/*allocate blocks*/
	blocks_g1 = (struct block **)malloc(bc->margins[1-mrgn]->G*sizeof(struct block *));  
	blocks_g2 = (struct block **)malloc(bc->margins[1-mrgn]->G*sizeof(struct block *));
	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		blocks_g1[i] = bc->model->create_new_block(bc->model->dimensions);
		blocks_g2[i] = bc->model->create_new_block(bc->model->dimensions);
	}
	
	if(ntot > 0)
	{
	
		indexes = calloc(ntot,sizeof(int));
		proposed_allocation = calloc(ntot,sizeof(int));
		
		c = 0;
		
		for(i=0;i<bc->margins[mrgn]->n;i++)
		{
			if(bc->margins[mrgn]->z[i] == g1)
			{
				indexes[c] = i;
				c += 1;
			}
		}
		
		//Rprintf("\n ej move: value of c = %d and ng1 = %d",c,bc->margins[mrgn]->ng[g1]);
		
		for(i=0;i<bc->margins[1-mrgn]->G;i++)
		{
			if(mrgn)
			{
				bc->model->copy_block(bc->blocks[ bc->margins[1-mrgn]->where_is[i] ][ig1],blocks_g1[i]);
			}
			else
			{
				bc->model->copy_block(bc->blocks[ig1][ bc->margins[1-mrgn]->where_is[i] ],blocks_g1[i]);
			}
		}
		
		if(ntot < 4)
		{
			a = 100.;
			prob_put_in_g2 = rbeta(a,a) ;
		}
		else
		{
			a = a_table[ntot-1];
			prob_put_in_g2 = rbeta(a,a) ;
		}
		
		ng1 = bc->margins[mrgn]->ng[g1];
		ng2 = 0;
	
		/*now reassign or not*/
		for(i=0;i<ntot;i++)
		{
			ii = indexes[i];
		
			if( runif(0.0,1.0) < prob_put_in_g2)
			{
				/*move this point from g1 to g2*/
			
				for(j=0;j<bc->margins[1-mrgn]->G;j++)
				{
					w_i = bc->margins[1-mrgn]->where_is[j];
					if(bc->multivariate_model)
					{
						bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g1[j]->stats,FALSE);
						bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g2[j]->stats,TRUE);
					}
					else
					{
						for(l=0;l<bc->margins[1-mrgn]->ng[j];l++)
						{
							jidx = bc->margins[1-mrgn]->idxz[w_i][l];
							bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g1[j]->stats,FALSE);
							bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g2[j]->stats,TRUE);
						}
					}
				
				}	
				proposed_allocation[i] = g2;
				ng1 -= 1;
				ng2 += 1;
			}
			else
			{
				proposed_allocation[i] = g1;
			}	
		}
	}	
	
	double l1=0.,l2=0.;
	
	for(j=0;j<bc->margins[1-mrgn]->G;j++)
	{
		blocks_g1[j]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(blocks_g1[j]->stats,bc->model->hyperparameters);
		blocks_g2[j]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(blocks_g2[j]->stats,bc->model->hyperparameters);
		l1 += (blocks_g1[j]->log_marginal_likelihood + blocks_g2[j]->log_marginal_likelihood);
		if(mrgn)
		{
			l2 += bc->blocks[ bc->margins[1-mrgn]->where_is[j] ][ig1]->log_marginal_likelihood;
		}
		else
		{
			l2 += bc->blocks[ig1][ bc->margins[1-mrgn]->where_is[j] ]->log_marginal_likelihood;
		}
	}
	
	l1 += lgamma(bc->alpha*(bc->margins[mrgn]->G+1.))
		- (bc->margins[mrgn]->G+1.)*lgamma(bc->alpha)
		- lgamma(bc->margins[mrgn]->n+bc->alpha*(bc->margins[mrgn]->G + 1.))
		+lgamma(ng1+bc->alpha) + lgamma(ng2+bc->alpha);
	
	l2 += lgamma(bc->alpha*bc->margins[mrgn]->G)
		- bc->margins[mrgn]->G*lgamma(bc->alpha)
		- lgamma(bc->margins[mrgn]->n+bc->alpha*bc->margins[mrgn]->G)
		+ lgamma(bc->margins[mrgn]->ng[g1] + bc->alpha);
	
	if(ntot > 0)
	{
		log_transition_z_to_zprime += log(pr_ej_G) + lgamma(2.*a) - 2.*lgamma(a) + lgamma(a + ng1) + lgamma(a + ng2) - lgamma(2.*a + ntot);
	
	}
	
	log_transition_zprime_to_z = log(1-pr_ej_Gp1);
	
	log_acceptance = l1 - l2 - log_transition_z_to_zprime + log_transition_zprime_to_z - log(bc->margins[mrgn]->G+1.);//+ bc->log_prior[bc->margins[mrgn]->G + 1] - bc->log_prior[bc->margins[mrgn]->G];
	
	//Rprintf("\nValue of log acceptance = %lf",log_acceptance);
	
	if(log( runif(0.0,1.0) ) < log_acceptance)
	{
		*accepted += 1;
	
		//if(!mrgn) Rprintf("\nAccepted row eject");
		//if(mrgn) Rprintf("\nAccepted col eject");
		//Rprintf("\nAccepted!");
		
		
		//bc->margins[mrgn]->ng[bc->margins[mrgn]->G] = ng2;
		
		/*find the new component that we're putting into*/
		
		int new_where_is = 0;
		while(bc->margins[mrgn]->in_use[new_where_is])
		{
			new_where_is += 1;
		}
		
		//Rprintf("\nThe value of new where is = %d",new_where_is);
		
		bc->margins[mrgn]->where_is[bc->margins[mrgn]->G] = new_where_is;
		bc->margins[mrgn]->in_use[new_where_is] = TRUE;
		ig2 = new_where_is;
		
		//Rprintf("\nTHE VALUE of ng is %d",bc->margins[mrgn]->ng[g2]);
		
		if(ntot>0)
		{
			for(i=0;i<ntot;i++)
			{
				ii = indexes[i];
				if(proposed_allocation[i] == g2)
				{
					g = g1;
					gnew = bc->margins[mrgn]->G;
					move_to_new_component(bc,mrgn,bc->margins[mrgn]->Y[ii],ii,g,gnew,FALSE,FALSE);
				}
		
			}
		}
	

		for(i=0;i<bc->margins[1-mrgn]->G;i++)
		{
			//the blocks were all updated, just need to recompute the marginal likelihoods now
			if(mrgn)
			{
				bc->blocks[ bc->margins[1-mrgn]->where_is[i] ][ ig1 ]->log_marginal_likelihood = blocks_g1[i]->log_marginal_likelihood;		
				bc->blocks[ bc->margins[1-mrgn]->where_is[i] ][ ig2 ]->log_marginal_likelihood = blocks_g2[i]->log_marginal_likelihood;
			}else{
			
				bc->blocks[ ig1 ][ bc->margins[1-mrgn]->where_is[i] ]->log_marginal_likelihood = blocks_g1[i]->log_marginal_likelihood;	
				bc->blocks[ ig2 ][ bc->margins[1-mrgn]->where_is[i] ]->log_marginal_likelihood = blocks_g2[i]->log_marginal_likelihood;
			}
		}
		
		
		g1 = (int)( ( bc->margins[mrgn]->G+1 ) * runif(0.0,1.0) );
		
		//j = check_membership_counts_against_labels(bc,mrgn);
		//if(j) Rprintf("\nfail before swap!");
		
		//Rprintf("\nbf comp swap\n");
		//Rprintf("\nng1 = %d, ng2 = %d\n",bc->margins[mrgn]->ng[g1],bc->margins[mrgn]->ng[g2]);
		//for(i=0;i<bc->margins[mrgn]->n;i++) Rprintf("%d  ",bc->margins[mrgn]->z[i]);
		//Rprintf("\n\n");
		
		if(g1 != bc->margins[mrgn]->G)
		{
		
			bc->margins[mrgn]->where_is[ bc->margins[mrgn]->G ] = bc->margins[mrgn]->where_is[g1];
			bc->margins[mrgn]->where_is[g1] = new_where_is; 
		
			j = bc->margins[mrgn]->ng[g1];
			bc->margins[mrgn]->ng[g1] = bc->margins[mrgn]->ng[g2];
			bc->margins[mrgn]->ng[g2] = j;
			
			for(i=0;i<bc->margins[mrgn]->n;i++)
			{
				if(bc->margins[mrgn]->z[i] == g1){
					bc->margins[mrgn]->z[i] = bc->margins[mrgn]->G;
				}else if(bc->margins[mrgn]->z[i] == bc->margins[mrgn]->G){
					bc->margins[mrgn]->z[i] = g1;
				}
			} 
		
		}
		 //swap_component_labels(bc,mrgn,g1,bc->margins[mrgn]->G);	
		
		//Rprintf("\naft comp swap\n");
		//for(i=0;i<bc->margins[mrgn]->n;i++) Rprintf("%d  ",bc->margins[mrgn]->z[i]);
		//Rprintf("\nng1 = %d, ng2 = %d\n",bc->margins[mrgn]->ng[g1],bc->margins[mrgn]->ng[g2]);
		
		//j = check_membership_counts_against_labels(bc,mrgn);
		//if(j) Rprintf("\nFailure after swap!");
		
		bc->margins[mrgn]->G += 1;	
	
	}
	
	/*free everything here...*/
	if(ntot>1)
	{
		free(indexes);
		free(proposed_allocation);
	}
	
	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		bc->model->destroy_block(blocks_g1[i]);
		bc->model->destroy_block(blocks_g2[i]);
	}
	free(blocks_g1);
	free(blocks_g2);	
	
	return(TRUE);

}


int update_allocations_with_absorb_move(struct bcluster *bc,int mrgn,int *accepted,int *proposed,double pr_ej_G,double pr_ej_Gm1)
{

	int i,ii,j,k,g1,g2,ig1,ig2,ntot,c=0,w_i,l,jidx,g,gnew;
	int *indexes,*proposed_allocation,n_g2;
	double w,a,log_acceptance
	,log_transition_z_to_zprime=0.,log_transition_zprime_to_z=0.;	
	
	struct block **blocks_t;
	
	*proposed += 1;
	
	g1 = (int)( bc->margins[mrgn]->G * runif(0.0,1.0) );
	g2 = g1;
	while(g2 == g1)
	{
		g2 = (int)( bc->margins[mrgn]->G * runif(0.0,1.0) );
	}
	
	ig1 = bc->margins[mrgn]->where_is[g1];
	ig2 = bc->margins[mrgn]->where_is[g2];
	
	blocks_t = (struct block **)malloc(bc->margins[1-mrgn]->G*sizeof(struct block *));
	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		blocks_t[i] = bc->model->create_new_block(bc->model->dimensions);
	}
	
	ntot = bc->margins[mrgn]->ng[g1] + bc->margins[mrgn]->ng[g2];
	
	n_g2 = bc->margins[mrgn]->ng[g2];
	
	c = 0;
	for(i=0;i<bc->margins[mrgn]->n;i++){
		if(bc->margins[mrgn]->z[i] == g2) c+= 1;
	}

	
	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		if(mrgn)
		{
			bc->model->copy_block(bc->blocks[bc->margins[1-mrgn]->where_is[i]][ig1],blocks_t[i]);
		}
		else
		{
			bc->model->copy_block(bc->blocks[ig1][bc->margins[1-mrgn]->where_is[i]],blocks_t[i]);
		}
	}
	
	if(n_g2 > 0)
	{
		indexes = calloc(n_g2,sizeof(int));
		proposed_allocation = calloc(n_g2,sizeof(int));
		
		c = 0;
		for(i=0;i<bc->margins[mrgn]->n;i++)
		{
			if(bc->margins[mrgn]->z[i] == g2)
			{
				indexes[c] = i;
				c += 1;
			}
		}
		
		//Rprintf("\nvalue of c = %d and value of n_g2 = %d",c,n_g2);
		
		//put everything in comoponent g1
		for(i=0;i<n_g2;i++)
		{
			ii = indexes[i];
			for(j=0;j<bc->margins[1-mrgn]->G;j++)
			{
				w_i = bc->margins[1-mrgn]->where_is[j];
				if(bc->multivariate_model)
				{
					bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_t[j]->stats,TRUE);
				}
				else
				{
					for(l=0;l<bc->margins[1-mrgn]->ng[j];l++)
					{
						jidx = bc->margins[1-mrgn]->idxz[w_i][l];
						bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_t[j]->stats,TRUE);
					}
				}
			}
		}
	
	}
	
	double l1=0.,l2=0.;
	
	for(j=0;j<bc->margins[1-mrgn]->G;j++)
	{
		blocks_t[j]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(blocks_t[j]->stats,bc->model->hyperparameters);
		l1 += blocks_t[j]->log_marginal_likelihood;
		if(mrgn)
		{
			l2 += ( bc->blocks[bc->margins[1-mrgn]->where_is[j]][ig1]->log_marginal_likelihood
				+ bc->blocks[bc->margins[1-mrgn]->where_is[j]][ig2]->log_marginal_likelihood);
		}
		else
		{
			l2 += ( bc->blocks[ig1][bc->margins[1-mrgn]->where_is[j]]->log_marginal_likelihood
				+ bc->blocks[ig2][bc->margins[1-mrgn]->where_is[j]]->log_marginal_likelihood);
		}
	}
	
	l1 += lgamma(bc->alpha*(bc->margins[mrgn]->G-1.))
		- (bc->margins[mrgn]->G-1.)*lgamma(bc->alpha)
		- lgamma(bc->margins[mrgn]->n+bc->alpha*(bc->margins[mrgn]->G-1.))
		+ lgamma(bc->margins[mrgn]->ng[g1]+bc->margins[mrgn]->ng[g2]+bc->alpha);
		
	l2 += lgamma(bc->alpha*bc->margins[mrgn]->G)
		- bc->margins[mrgn]->G*lgamma(bc->alpha)
		- lgamma(bc->margins[mrgn]->n+bc->alpha*bc->margins[mrgn]->G)
		+ lgamma(bc->margins[mrgn]->ng[g1] + bc->alpha)
		+ lgamma(bc->margins[mrgn]->ng[g2] + bc->alpha);

	log_transition_zprime_to_z = log(pr_ej_Gm1);

	if(ntot>0)
	{
	
		if(ntot<4) a = 100.; else a = a_table[ntot-1];
		
		log_transition_zprime_to_z +=  lgamma(2.*a) - 2.*lgamma(a) + lgamma(a + bc->margins[mrgn]->ng[g1]) + lgamma(a + bc->margins[mrgn]->ng[g2]) - lgamma(2.*a + ntot) ;
	
	}
	
	log_transition_z_to_zprime = log(1.-pr_ej_G);
	
	log_acceptance = l1 - l2 - log_transition_z_to_zprime + log_transition_zprime_to_z + log(bc->margins[mrgn]->G);
	
	//Rprintf("\nlog acceptance = %lf,l1 = %lf, \n\t l2 = %lf, ltzzp = %lf, ltzpz = %lf\n\t ntot = %d, n_g2 = %d ",log_acceptance,l1,l2,log_transition_z_to_zprime,log_transition_zprime_to_z,ntot,n_g2 );
	
	if(log( runif(0.0,1.0) ) < log_acceptance)
	{
		*accepted += 1;
		
		//if(!mrgn) Rprintf("\nAccepted a row absorb");
		//if(mrgn) Rprintf("\nAccepted a col absorb");
		//Rprintf("\n Label vec before: ");
		//for(i=0;i<bc->margins[mrgn]->n;i++) Rprintf(" %d, ",bc->margins[mrgn]->z[i]);
	
		if(n_g2 > 0)
		{
			for(i=0;i<n_g2;i++)
			{
				g = g2;
				gnew = g1;
				ii = indexes[i];
				//Rprintf("\nmoving idx %d... z before %d... ng before %d ",ii,bc->margins[mrgn]->z[ii],bc->margins[mrgn]->ng[g]);
				move_to_new_component(bc,mrgn,bc->margins[mrgn]->Y[ii],ii,g,gnew,FALSE,FALSE);
				//Rprintf("... z after %d... ng after %d",bc->margins[mrgn]->z[ii],bc->margins[mrgn]->ng[g]);
			}
		
		}
		
		//Rprintf("\n Label vec after: ");
		//for(i=0;i<bc->margins[mrgn]->n;i++) Rprintf(" %d, ",bc->margins[mrgn]->z[i]);
		
		//j = check_membership_counts_against_labels(bc,mrgn);
		//if(j) Rprintf("\nFailure here 0 !");
		
		
		//Rprintf("\n ng1 = %d, ng2 = %d",bc->margins[mrgn]->ng[g1],bc->margins[mrgn]->ng[g2]);
		/*check the old component stats here.... */
		/*if(!mrgn)
		{
			struct Multinom_stats *s = (struct Multinom_stats *)bc->blocks[ig2][bc->margins[1]->where_is[0]]->stats; 
			Rprintf("\n-----\n");
			for(i=0;i<s->ncat;i++) Rprintf("%.3f  ",s->counts[i]);
			Rprintf("\n-----\n");
		}else{
			Rprintf("\n-----\n");
			struct Multinom_stats *s = (struct Multinom_stats *)bc->blocks[bc->margins[0]->where_is[0]][ig2]->stats; 
			for(i=0;i<s->ncat;i++) Rprintf("%.3f  ",s->counts[i]);
			Rprintf("\n-----\n");
		}*/
		
		bc->margins[mrgn]->in_use[ ig2 ] = FALSE;
		
		
		for(i=0;i<bc->margins[1-mrgn]->G;i++)
		{
			w_i = bc->margins[1-mrgn]->where_is[i];
			if(mrgn)
			{
				bc->blocks[w_i][ig1]->log_marginal_likelihood = blocks_t[i]->log_marginal_likelihood;
			}
			else
			{
				bc->blocks[ig1][w_i]->log_marginal_likelihood = blocks_t[i]->log_marginal_likelihood;
			}
		}
		
		//tidy up the absorbed component
		
		for(i=g2+1;i<bc->margins[mrgn]->G;i++)
		{
			j = bc->margins[mrgn]->where_is[i];
			bc->margins[mrgn]->where_is[i-1] = j;
			bc->margins[mrgn]->ng[i-1] = bc->margins[mrgn]->ng[i];
		}
		
		for(i=bc->margins[mrgn]->G-1;i<bc->margins[mrgn]->Gmax;i++) bc->margins[mrgn]->ng[i] = 0;
		
		for(i=g2+1;i<bc->margins[mrgn]->G;i++)
		{
			for(j=0;j<bc->margins[mrgn]->n;j++)
			{
				if(bc->margins[mrgn]->z[j] == i) bc->margins[mrgn]->z[j] -= 1;
			}
		}
		
		bc->margins[mrgn]->G -= 1;		
			
		//j = check_membership_counts_against_labels(bc,mrgn);
		//if(j) Rprintf("\nFailure here!");
		
	}
	
	if(n_g2>1)
	{
		free(indexes);
		free(proposed_allocation);
	}

	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		bc->model->destroy_block(blocks_t[i]);
	}
	free(blocks_t);
	
	return(TRUE);
	
	
}

int update_allocations_with_eject_move_x(struct bcluster *bc,int mrgn,int *accepted,int *proposed,double pr_ej_G,double pr_ej_Gp1)
{

	int i,ii,j,k,l,g1,g2,ig1,ig2,g,gnew,ntot,c=0,w_i,jidx,n_g1=0,n_g2=0,fl;
	int *indexes,*order,*proposed_allocation;
	double w,log_acceptance, log_transition_z_to_zprime=0.,log_transition_zprime_to_z=0.,l1,l2,h1,h2,p1,a;
	struct block **blocks_g1, **blocks_g2;
	
	/*sample the component to be ejected from*/
	g1 = (int)( bc->margins[mrgn]->G * runif(0.0,1.0) );
	g2 = bc->margins[mrgn]->G;
	/*while(g2 == g1)
	{
		g2 = gsl_rng_uniform_int(r,bc->margins[mrgn]->G);
	}*/
	
	ig1 = bc->margins[mrgn]->where_is[g1];
	//ig2 = bc->margins[mrgn]->where_is[g2];
	
	ntot = bc->margins[mrgn]->ng[g1];// + bc->margins[mrgn]->ng[g2];
	
	
	*proposed += 1;
	
	indexes = calloc(ntot,sizeof(int));
	order = calloc(ntot,sizeof(int));
	proposed_allocation = calloc(ntot,sizeof(int));
	
	for(i=0;i<bc->margins[mrgn]->n;i++)
	{
		if(bc->margins[mrgn]->z[i] == g1)
		{
			indexes[c] = i;
			c += 1;
		}
	}
	
	for(i=0;i<ntot;i++) order[i] = i;
	
	/*shuffle order of processing*/
	if( ntot > 0 ) random_ranshuffle( order, ntot ); //gsl_ran_shuffle(r,order,ntot,sizeof(int));

	/*allocate blocks*/
	blocks_g1 = (struct block **)malloc(bc->margins[1-mrgn]->G*sizeof(struct block *));  
	blocks_g2 = (struct block **)malloc(bc->margins[1-mrgn]->G*sizeof(struct block *));

	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		blocks_g1[i] = bc->model->create_new_block(bc->model->dimensions);
		blocks_g2[i] = bc->model->create_new_block(bc->model->dimensions);
	}
	
	if( ntot>0 )
	{
		
		for(i=0;i<ntot;i++)
		{
			a = log(n_g1 + bc->alpha) - log(n_g2 + bc->alpha);  //(bc->alpha + n_g1)/(bc->alpha + n_g2)
			//Rprintf("\ni is %d",i);	
			k = order[i];
			ii = indexes[k];
		
			//Rprintf("\nvalue %d is %d",i,ii);
		
			/*compute probability generated from g1*/
			h1=0.;h2=0.;l1=0.;l2=0.;
			for(j=0;j<bc->margins[1-mrgn]->G;j++)
			{
				h1 += bc->model->compute_log_marginal_likelihood_from_stats(blocks_g1[j]->stats,bc->model->hyperparameters); 
				h2 += bc->model->compute_log_marginal_likelihood_from_stats(blocks_g2[j]->stats,bc->model->hyperparameters);
				w_i = bc->margins[1-mrgn]->where_is[j];
			
				if(bc->multivariate_model)
				{
					bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g1[j]->stats,TRUE);
					bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g2[j]->stats,TRUE);
				}
				else
				{
					for(l=0;l<bc->margins[1-mrgn]->ng[j];l++)
					{
						jidx = bc->margins[1-mrgn]->idxz[w_i][l];
						bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g1[j]->stats,TRUE);
						bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g2[j]->stats,TRUE);
					}
				}
				l1 += bc->model->compute_log_marginal_likelihood_from_stats(blocks_g1[j]->stats,bc->model->hyperparameters);
				l2 += bc->model->compute_log_marginal_likelihood_from_stats(blocks_g2[j]->stats,bc->model->hyperparameters);
				//if(i<10) Rprintf("\nvalue is %lf",l1 + h2 - l2 - h1);
			}
			//Rprintf("\n z = %lf",exp(a));
		
		
			a += l1 + h2 - l2 - h1;
			w = /*((bc->alpha + n_g1)/(bc->alpha + n_g2))*/exp(a);
			p1 = w/(1.+w);
		
			//Rprintf("\nvalue of p1 = %lf ",p1);
		
			/*fl=FALSE;
			if(p1 == 1.||p1 == 0.)
			{
				fl = TRUE;
			}*/
		
			/*make a draw*/
			if(runif(0.0,1.0) < p1)
			{
				/*put in g1*/
				n_g1 += 1;
				//if(!(bc->margins[mrgn]->z[ii] == g1))
				//{
			
				log_transition_z_to_zprime += log(p1);
				/*if(fl){
					if(p1==0.) p1 = 1E-8; else p1 = 1.-1E-8;//approximation for p1 close to 1
					log_transition_z_to_zprime += log(p1);
				}else{
					log_transition_z_to_zprime += log(p1);
				}*/
					//log_transition_zprime_to_z += log(1.-p1);
				//}
				proposed_allocation[i] = g1;
				/*take the entries out of block g2*/
				for(j=0;j<bc->margins[1-mrgn]->G;j++)
				{
					w_i = bc->margins[1-mrgn]->where_is[j];
					if(bc->multivariate_model)
					{
						bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g2[j]->stats,FALSE);
					}
					else
					{
						for(l=0;l<bc->margins[1-mrgn]->ng[j];l++)
						{
							jidx = bc->margins[1-mrgn]->idxz[w_i][l];
							bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g2[j]->stats,FALSE);
						}
					}				
				}
			}
			else
			{
				/*put in g2*/
				n_g2 += 1;
				//if(!(bc->margins[mrgn]->z[ii] == g2))
				//{
				log_transition_z_to_zprime += log(1.-p1);
				/*if(fl){
					if(p1==0.) p1 = 1E-8; else p1 = 1.-1E-8;
					log_transition_z_to_zprime += log(1.-p1);
				}else{
					log_transition_z_to_zprime += log(1.-p1);
				}*/
					//log_transition_zprime_to_z += log(p1);
				//}
				proposed_allocation[i] = g2;
				/*take entries back out of block g1*/
				for(j=0;j<bc->margins[1-mrgn]->G;j++)
				{
					w_i = bc->margins[1-mrgn]->where_is[j];
					if(bc->multivariate_model)
					{
						bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g1[j]->stats,FALSE);
					}
					else
					{
						for(l=0;l<bc->margins[1-mrgn]->ng[j];l++)
						{
							jidx = bc->margins[1-mrgn]->idxz[w_i][l];
							bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g1[j]->stats,FALSE);
						}
					}				
				}			
			}
	
		}
	
	}
	
	log_transition_z_to_zprime += log(pr_ej_G);
	
	log_transition_zprime_to_z = log(1. - pr_ej_Gp1);
	
	log_acceptance = 0.;
	
	for(j=0;j<bc->margins[1-mrgn]->G;j++)
	{
		blocks_g1[j]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(blocks_g1[j]->stats,bc->model->hyperparameters);
		blocks_g2[j]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(blocks_g2[j]->stats,bc->model->hyperparameters);
		log_acceptance += blocks_g1[j]->log_marginal_likelihood + blocks_g2[j]->log_marginal_likelihood;
		if(mrgn)
		{
			log_acceptance -= ( bc->blocks[ bc->margins[1-mrgn]->where_is[j] ][ig1]->log_marginal_likelihood
						      /*+ bc->blocks[ bc->margins[1-mrgn]->where_is[j] ][g2]->log_marginal_likelihood*/);
		}
		else
		{
			log_acceptance -= ( bc->blocks[ig1][ bc->margins[1-mrgn]->where_is[j] ]->log_marginal_likelihood
						      /*+ bc->blocks[g2][ bc->margins[1-mrgn]->where_is[j] ]->log_marginal_likelihood*/);		
		}
	}
	
	log_acceptance += lgamma(n_g1 + bc->alpha) + lgamma(n_g2 + bc->alpha) 
					- lgamma(bc->margins[mrgn]->ng[g1]+bc->alpha) /*- lgamma(bc->margins[mrgn]->ng[g2]+bc->alpha)*/
					- log_transition_z_to_zprime + log_transition_zprime_to_z - log(bc->margins[mrgn]->G+1.);
					
	log_acceptance += ( lgamma(bc->alpha*(bc->margins[mrgn]->G+1.)) - (bc->margins[mrgn]->G+1.)*lgamma(bc->alpha) 
	- lgamma(bc->margins[mrgn]->n + bc->alpha*(bc->margins[mrgn]->G+1.)) )
					- ( lgamma(bc->alpha*bc->margins[mrgn]->G) - bc->margins[mrgn]->G*lgamma(bc->alpha) 
		- lgamma(bc->margins[mrgn]->n + bc->alpha*bc->margins[mrgn]->G) );
					
	//Rprintf("\nlog acc ej for marg %d is %.10f",mrgn,log_acceptance);
		
	if(log(runif(0.0,1.0))<log_acceptance)
	{
		//do the acceptance stuff in here
		//Rprintf("\n in acceptance ");
		
		
		//Rprintf("\naccepted eject for %d",mrgn);
		
		*accepted += 1;

		int new_where_is = 0;
		while(bc->margins[mrgn]->in_use[new_where_is])
		{
			new_where_is += 1;
		}
		
		//Rprintf("\nThe value of new where is = %d",new_where_is);
		
		bc->margins[mrgn]->where_is[bc->margins[mrgn]->G] = new_where_is;
		bc->margins[mrgn]->in_use[new_where_is] = TRUE;
		ig2 = new_where_is;
		
		//Rprintf("\nTHE VALUE of ng is %d",bc->margins[mrgn]->ng[g2]);
		
		for(i=0;i<ntot;i++)
		{
			ii = indexes[i];
			if(proposed_allocation[i] == g2)
			{
				g = g1;
				gnew = bc->margins[mrgn]->G;
				move_to_new_component(bc,mrgn,bc->margins[mrgn]->Y[ii],ii,g,gnew,FALSE,FALSE);
			}
		
		}
	

		for(i=0;i<bc->margins[1-mrgn]->G;i++)
		{
			//the blocks were all updated, just need to recompute the marginal likelihoods now
			if(mrgn)
			{
				bc->blocks[ bc->margins[1-mrgn]->where_is[i] ][ ig1 ]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(bc->blocks[ bc->margins[1-mrgn]->where_is[i] ][ ig1 ]->stats,bc->model->hyperparameters);		
				bc->blocks[ bc->margins[1-mrgn]->where_is[i] ][ ig2 ]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(bc->blocks[ bc->margins[1-mrgn]->where_is[i] ][ ig2 ]->stats,bc->model->hyperparameters);
			}else{
				bc->blocks[ ig1 ][ bc->margins[1-mrgn]->where_is[i] ]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(bc->blocks[ ig1 ][ bc->margins[1-mrgn]->where_is[i] ]->stats,bc->model->hyperparameters);	
				bc->blocks[ ig2 ][ bc->margins[1-mrgn]->where_is[i] ]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(bc->blocks[ ig2 ][ bc->margins[1-mrgn]->where_is[i] ]->stats,bc->model->hyperparameters);
			}
		}
		
		
		g1 = (int)( (bc->margins[mrgn]->G + 1) * runif(0.0,1.0) );

		if(g1 != bc->margins[mrgn]->G)
		{
		
			bc->margins[mrgn]->where_is[ bc->margins[mrgn]->G ] = bc->margins[mrgn]->where_is[g1];
			bc->margins[mrgn]->where_is[g1] = new_where_is; 
		
			j = bc->margins[mrgn]->ng[g1];
			bc->margins[mrgn]->ng[g1] = bc->margins[mrgn]->ng[g2];
			bc->margins[mrgn]->ng[g2] = j;
			
			for(i=0;i<bc->margins[mrgn]->n;i++)
			{
				if(bc->margins[mrgn]->z[i] == g1){
					bc->margins[mrgn]->z[i] = bc->margins[mrgn]->G;
				}else if(bc->margins[mrgn]->z[i] == bc->margins[mrgn]->G){
					bc->margins[mrgn]->z[i] = g1;
				}
			} 
		
		}
		 //swap_component_labels(bc,mrgn,g1,bc->margins[mrgn]->G);	
		
		//Rprintf("\naft comp swap\n");
		//for(i=0;i<bc->margins[mrgn]->n;i++) Rprintf("%d  ",bc->margins[mrgn]->z[i]);
		//Rprintf("\nng1 = %d, ng2 = %d\n",bc->margins[mrgn]->ng[g1],bc->margins[mrgn]->ng[g2]);
		
		//j = check_membership_counts_against_labels(bc,mrgn);
//		if(j) Rprintf("\nFailure after swap!");
		
		bc->margins[mrgn]->G += 1;	

	
	}


	free(indexes);
	free(order);
	free(proposed_allocation);
	
//	Rprintf("\n The value of G here is %d",bc->margins[1-mrgn]->G);
	
	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		bc->model->destroy_block(blocks_g1[i]);
		bc->model->destroy_block(blocks_g2[i]);
	}
	free(blocks_g1);
	free(blocks_g2);
	
	return(TRUE);

}

int update_allocations_with_absorb_move_x(struct bcluster *bc,int mrgn,int *accepted,int *proposed,double pr_ej_G,double pr_ej_Gm1)
{

	if(bc->margins[mrgn]->G == 1)
	{
		return(TRUE);
	}

	int i,ii,j,k,l,g1,g2,ig1,ig2,g,gnew,ntot,c=0,w_i,jidx,n_g1=0,n_g2=0,fl;
	int *indexes,*order;
	double w,log_acceptance, log_transition_z_to_zprime=0.,log_transition_zprime_to_z=0.,l1,l2,h1,h2,p1,a;
	struct block **blocks_g1, **blocks_g2, **blocks_new;
	
	/*sample the two components*/
	g1 = (int)( bc->margins[mrgn]->G * runif(0.0,1.0) );
	g2 = g1;
	while(g2 == g1)
	{
		g2 = (int)( bc->margins[mrgn]->G * runif(0.0,1.0) );
	}
	
	ig1 = bc->margins[mrgn]->where_is[g1];
	ig2 = bc->margins[mrgn]->where_is[g2];
	
	ntot = bc->margins[mrgn]->ng[g1] + bc->margins[mrgn]->ng[g2];
	
	*proposed += 1;
	
	indexes = calloc(ntot,sizeof(int));
	order = calloc(ntot,sizeof(int));
	//proposed_allocation = calloc(ntot,sizeof(int));
	
	for(i=0;i<bc->margins[mrgn]->n;i++)
	{
		if(bc->margins[mrgn]->z[i] == g1 || bc->margins[mrgn]->z[i] == g2)
		{
			indexes[c] = i;
			c += 1;
		}
	}
	
	for(i=0;i<ntot;i++) order[i] = i;
	
	/*shuffle order of processing*/
	if( ntot > 0 ) random_ranshuffle( order, ntot );//gsl_ran_shuffle(r,order,ntot,sizeof(int));

	/*allocate blocks*/
	blocks_g1 = (struct block **)malloc(bc->margins[1-mrgn]->G*sizeof(struct block *));  
	blocks_g2 = (struct block **)malloc(bc->margins[1-mrgn]->G*sizeof(struct block *));
	blocks_new = (struct block **)malloc(bc->margins[1-mrgn]->G*sizeof(struct block *));
	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		blocks_g1[i] = bc->model->create_new_block(bc->model->dimensions);
		blocks_g2[i] = bc->model->create_new_block(bc->model->dimensions);
		blocks_new[i] = bc->model->create_new_block(bc->model->dimensions);
	}
	
	
	if( ntot > 0)
	{
		
	/*get first*/
	k = order[0];
	ii = indexes[k];

	
	if(bc->margins[mrgn]->z[ii] == g1)
	{
		for(j=0;j<bc->margins[1-mrgn]->G;j++)
		{
			w_i = bc->margins[1-mrgn]->where_is[j];
			if(bc->multivariate_model)
			{
				bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g1[j]->stats,TRUE);
				bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_new[j]->stats,TRUE);
			}
			else
			{
				for(l=0;l<bc->margins[1-mrgn]->ng[j];l++)
				{
					jidx = bc->margins[1-mrgn]->idxz[w_i][l];
					bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g1[j]->stats,TRUE);
					bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_new[j]->stats,TRUE);
				}
			}
		}
		n_g1 += 1;
		//proposed_allocation[0] = g1;
		//log_transition_z_to_zprime = log(.5);
	}
	else
	{
		for(j=0;j<bc->margins[1-mrgn]->G;j++)
		{
			w_i = bc->margins[1-mrgn]->where_is[j];
			if(bc->multivariate_model)
			{
				bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g2[j]->stats,TRUE);
				bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_new[j]->stats,TRUE);
			}
			else
			{
				for(l=0;l<bc->margins[1-mrgn]->ng[j];l++)
				{
					jidx = bc->margins[1-mrgn]->idxz[w_i][l];
					bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g2[j]->stats,TRUE);
					bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_new[j]->stats,TRUE);
				}
			}
		}	
		n_g2 += 1;
		//proposed_allocation[0] = g2;
		//log_transition_z_to_zprime = log(.5);
	}
	
	//log_transition_zprime_to_z = log(.5);
	
	for(i=1;i<ntot;i++)
	{
		//Rprintf("\ni is %d",i);	
		k = order[i];
		ii = indexes[k];
		
		/*compute probability generated from g1*/
		h1=0.;h2=0.;l1=0.;l2=0.;
		for(j=0;j<bc->margins[1-mrgn]->G;j++)
		{
			h1 += bc->model->compute_log_marginal_likelihood_from_stats(blocks_g1[j]->stats,bc->model->hyperparameters); 
			h2 += bc->model->compute_log_marginal_likelihood_from_stats(blocks_g2[j]->stats,bc->model->hyperparameters);
			w_i = bc->margins[1-mrgn]->where_is[j];
			if(bc->multivariate_model)
			{
				bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g1[j]->stats,TRUE);
				bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g2[j]->stats,TRUE);
				bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_new[j]->stats,TRUE);
			}
			else
			{
				for(l=0;l<bc->margins[1-mrgn]->ng[j];l++)
				{
					jidx = bc->margins[1-mrgn]->idxz[w_i][l];
					bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g1[j]->stats,TRUE);
					bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g2[j]->stats,TRUE);
					bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_new[j]->stats,TRUE);
				}
			}
			l1 += bc->model->compute_log_marginal_likelihood_from_stats(blocks_g1[j]->stats,bc->model->hyperparameters);
			l2 += bc->model->compute_log_marginal_likelihood_from_stats(blocks_g2[j]->stats,bc->model->hyperparameters);
		}
		
		a = l1 + h2 - l2 - h1;
		w = ((bc->alpha + n_g1)/(bc->alpha + n_g2))*exp(a);
		p1 = w/(1.+w);
		
		fl=FALSE;
		if(p1 == 1.||p1 == 0.)
		{
			fl = TRUE;
		}
		
		/*match to the original component*/
		if(bc->margins[mrgn]->z[ii] == g1)
		{
			/*put in g1*/
			n_g1 += 1;
			
			if(fl){
				if(p1 == 0.){
					log_transition_zprime_to_z += log(1E-8);//approximation for p1 close to 1
				}else{
					log_transition_zprime_to_z += log(1.);
				}
			}else{
				log_transition_zprime_to_z += log(p1);
			}
			
			//proposed_allocation[i] = g1;
			/*take the entries out of block g2*/
			for(j=0;j<bc->margins[1-mrgn]->G;j++)
			{
				w_i = bc->margins[1-mrgn]->where_is[j];
				if(bc->multivariate_model)
				{
					bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g2[j]->stats,FALSE);
				}
				else
				{
					for(l=0;l<bc->margins[1-mrgn]->ng[j];l++)
					{
						jidx = bc->margins[1-mrgn]->idxz[w_i][l];
						bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g2[j]->stats,FALSE);
						//bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_new[j]->stats,FALSE);
					}				
				}
			}
		}
		else
		{
			/*put in g2*/
			n_g2 += 1;
			if(fl){
				if(p1 = 1.){
					log_transition_zprime_to_z += log(1E-8);
				}else{
					log_transition_zprime_to_z += log(1.);//approximation for p1 close to 1
				}
			}else{
				log_transition_zprime_to_z += log(1.-p1);
			}
				
			//proposed_allocation[i] = g2;
			/*take entries back out of block g1*/
			for(j=0;j<bc->margins[1-mrgn]->G;j++)
			{
				w_i = bc->margins[1-mrgn]->where_is[j];
				if(bc->multivariate_model)
				{
					bc->model->add_to_stats_multivariate(bc->margins[mrgn]->Y[ii],blocks_g1[j]->stats,FALSE);
				}
				else
				{
					for(l=0;l<bc->margins[1-mrgn]->ng[j];l++)
					{
						jidx = bc->margins[1-mrgn]->idxz[w_i][l];
						bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_g1[j]->stats,FALSE);
						//bc->model->add_to_stats(bc->margins[mrgn]->Y[ii][jidx],blocks_new[j]->stats,FALSE);
					}
				}				
			}			
		}
	
	}
	
	}
	
	log_transition_zprime_to_z += log(pr_ej_Gm1);
	log_transition_z_to_zprime = log(1. - pr_ej_G);
	
	log_acceptance = 0.;
	
	for(j=0;j<bc->margins[1-mrgn]->G;j++)
	{
		blocks_new[j]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(blocks_new[j]->stats,bc->model->hyperparameters);
		log_acceptance += blocks_new[j]->log_marginal_likelihood;
		if(mrgn)
		{
			log_acceptance -= ( bc->blocks[ bc->margins[1-mrgn]->where_is[j] ][ig1]->log_marginal_likelihood
						      + bc->blocks[ bc->margins[1-mrgn]->where_is[j] ][ig2]->log_marginal_likelihood);
		}
		else
		{
			log_acceptance -= ( bc->blocks[ig1][ bc->margins[1-mrgn]->where_is[j] ]->log_marginal_likelihood
						      + bc->blocks[ig2][ bc->margins[1-mrgn]->where_is[j] ]->log_marginal_likelihood);		
		}
	}
	
	log_acceptance += lgamma(ntot + bc->alpha) 
					- lgamma(bc->margins[mrgn]->ng[g1]+bc->alpha) - lgamma(bc->margins[mrgn]->ng[g2]+bc->alpha)
					- log_transition_z_to_zprime + log_transition_zprime_to_z + log(bc->margins[mrgn]->G);
	
	log_acceptance += (lgamma(bc->alpha*(bc->margins[mrgn]->G-1.)) - (bc->margins[mrgn]->G-1.)*lgamma(bc->alpha) - lgamma(bc->margins[mrgn]->n + bc->alpha*(bc->margins[mrgn]->G -1.)))
					- (lgamma(bc->alpha*bc->margins[mrgn]->G) - bc->margins[mrgn]->G*lgamma(bc->alpha) - lgamma(bc->margins[mrgn]->n + bc->alpha*bc->margins[mrgn]->G));
					
	//Rprintf("\nlog acc is %.10f",log_acceptance);
	//Rprintf("\nlog acc ab for marg %d is %.10f",mrgn,log_acceptance);
	
	if(log( runif(0.0,1.0) )<log_acceptance)
	{
		//Rprintf("\naccepted absorb for %d",mrgn);
		//do the acceptance stuff in here
		//Rprintf("\n in acceptance ");

		*accepted += 1;
		
		//if(!mrgn) Rprintf("\nAccepted a row absorb");
		//if(mrgn) Rprintf("\nAccepted a col absorb");
		//Rprintf("\n Label vec before: ");
		//for(i=0;i<bc->margins[mrgn]->n;i++) Rprintf(" %d, ",bc->margins[mrgn]->z[i]);
	
		if(n_g2 > 0)
		{
			for(i=0;i<bc->margins[mrgn]->n;i++)
			{
				if(bc->margins[mrgn]->z[i] == g2)
				{
					g = g2;
					gnew = g1;
					//ii = indexes[i];
					//Rprintf("\nmoving idx %d... z before %d... ng before %d ",ii,bc->margins[mrgn]->z[ii],bc->margins[mrgn]->ng[g]);
					move_to_new_component(bc,mrgn,bc->margins[mrgn]->Y[i],i,g,gnew,FALSE,FALSE);
				}
				//Rprintf("... z after %d... ng after %d",bc->margins[mrgn]->z[ii],bc->margins[mrgn]->ng[g]);
			}
		
		}
		
		
		bc->margins[mrgn]->in_use[ ig2 ] = FALSE;
		
		
		for(i=0;i<bc->margins[1-mrgn]->G;i++)
		{
			w_i = bc->margins[1-mrgn]->where_is[i];
			if(mrgn)
			{
				bc->blocks[w_i][ig1]->log_marginal_likelihood = blocks_new[i]->log_marginal_likelihood;
			}
			else
			{
				bc->blocks[ig1][w_i]->log_marginal_likelihood = blocks_new[i]->log_marginal_likelihood;
			}
		}
		
		//tidy up the absorbed component
		
		for(i=g2+1;i<bc->margins[mrgn]->G;i++)
		{
			j = bc->margins[mrgn]->where_is[i];
			bc->margins[mrgn]->where_is[i-1] = j;
			bc->margins[mrgn]->ng[i-1] = bc->margins[mrgn]->ng[i];
		}
		
		for(i=bc->margins[mrgn]->G-1;i<bc->margins[mrgn]->Gmax;i++) bc->margins[mrgn]->ng[i] = 0;
		
		for(i=g2+1;i<bc->margins[mrgn]->G;i++)
		{
			for(j=0;j<bc->margins[mrgn]->n;j++)
			{
				if(bc->margins[mrgn]->z[j] == i) bc->margins[mrgn]->z[j] -= 1;
			}
		}
		
		bc->margins[mrgn]->G -= 1;		
		
	}

	free(indexes);
	free(order);
	
	for(i=0;i<bc->margins[1-mrgn]->G;i++)
	{
		bc->model->destroy_block(blocks_g1[i]);
		bc->model->destroy_block(blocks_g2[i]);
		bc->model->destroy_block(blocks_new[i]);
	}
	free(blocks_g1);
	free(blocks_g2);
	free(blocks_new);
	
	return(TRUE);



}


void swap_component_labels(struct bcluster *bc,int mrgn,int g1,int g2)
{

	//this function swaps everything between components g1 and g2
	
	int i;
	
	//where_is
	i = bc->margins[mrgn]->where_is[g1];
	bc->margins[mrgn]->where_is[g1] = bc->margins[mrgn]->where_is[g2];
	bc->margins[mrgn]->where_is[g2] = i;
	
	//no. in a component
	i = bc->margins[mrgn]->ng[g1];
	bc->margins[mrgn]->ng[g1] = bc->margins[mrgn]->ng[g2];
	bc->margins[mrgn]->ng[g2] = i;
	
	//label vector
	for(i=0;i<bc->margins[mrgn]->n;i++)
	{
		if(bc->margins[mrgn]->z[i] == g1)
		{
			bc->margins[mrgn]->z[i] = g2;
		}
		else if(bc->margins[mrgn]->z[i] == g2)
		{
			bc->margins[mrgn]->z[i] = g1;
		}
	}
	
	return;
}


/**greedy search for margin**/
/*void update_model_margin_by_greedy_search(struct bcluster *bc,int mrgn,double *x,int g)
{

	int i,j,ii,idx,g,gnew,G = bc->margins[mrgn]->G,n = bc->margins[mrgn]->n,*z,*ord;
	double *pr,*x,max,nc,xtra;
	
	z = bc->margins[mrgn]->z; //current allocations
	
	pr = calloc(G,sizeof(double));
	ord = calloc(n,sizeof(int));
	
	for(i=0;i<n;i++) ord[i] = i;
	gsl_ran_shuffle(r,ord,n,sizeof(int)); //randomize order of update
	for(i=0;i<n;i++)
	{
		idx = ord[i];
		g =z[idx]; //current allocation
		x = bc->margins[mrgn]->Y[idx];//pointer to row/column being updated
		//check to see if moving idx would leave component g empty
		empty = (bc->margins[mrgn]->ng[g] == 1) ? TRUE : FALSE;
		
		if(empty)
		{
			//need to take idx out of cluster g and compute the ml of an empty cluster...
			// this is needed to subtract off the Gibbs rel prob		
			for(j=0;j<G;j++)
			{
				if(!(g==j)){
					pr[j] = get_log_relative_probability_Gibbs(bc,mrgn,x,g,j) 
							- lgamma(bc->alpha) - bc->margins[1-mrgn]->G*bc->log_marginal_likelihood_empty
							+ get_log_normailzing_constant_margin(bc,mrgn,bc->margins[1-mrgn]->G-1)
							- get_log_normalizing_constant_margin(bc,mrgn,bc->margins[1-mrgn]->G);
				}else{
					pr[j] = 0.;
				}
			
			}
		}
		else
		{
			for(j=0;j<G;j++)
			{
				if(!(g==j)){ //error here??? 
					pr[j] = get_log_relative_probability_Gibbs(bc,mrgn,x,g,j);
				}else{
					pr[j] = 0.;
				}
			}
		}
		
		//find the group that gives the maximum difference in ICL
		gnew = 0;
		max = pr[0];
		for(j=1;j<G;j++)
		{
			if(pr[j]>max)
			{
				gnew = j;
				max = pr[j];
			}
		}
		
		
		//renormalize
		
		if(!(gnew == g))
		{
			//need to handle this carefully for the empty and non-empty case...
			//update the components if sampled label is different to previous as normal
			move_to_new_component(bc,mrgn,x,idx,g,gnew,empty);
		}
		
	}
	free(pr);
	free(ord);
	return;	

}*/


double get_log_relative_probability_Gibbs(struct bcluster *bc,int mrgn,double *x,int g,int gn)
{
	//if mrgn is 0 then we go along row clusters otherwise col clusters
	int i,k,wg,wgn,r1,r2,c1,c2;
	double l=0.;
	//index of where the component is stored
	wg = bc->margins[mrgn]->where_is[g];
	wgn = bc->margins[mrgn]->where_is[gn];
	//this gives the opposite margin
	k = 1-mrgn;
	//get appropriate rows and cols
	switch(mrgn)
	{
		case 0:
			r1 = wg;
			r2 = wgn;
		break;
		case 1:
			c1 = wg;
			c2 = wgn;
		break;
	}
	//sum over the opposite margin
	for(i=0;i<bc->margins[k]->G;i++)
	{
		switch(mrgn)
		{
			case 0:
				c1 = bc->margins[k]->where_is[i];
				c2 = c1;
				l += compute_log_marginal_likelihood_block_with_inc_rm(bc,mrgn,x,gn,i,TRUE)
		  + compute_log_marginal_likelihood_block_with_inc_rm(bc,mrgn,x,g,i,FALSE);
			break;
			case 1:
				r1 = bc->margins[k]->where_is[i];
				r2 = r1;
				l += compute_log_marginal_likelihood_block_with_inc_rm(bc,mrgn,x,i,gn,TRUE)
		  + compute_log_marginal_likelihood_block_with_inc_rm(bc,mrgn,x,i,g,FALSE);
			break;
		}	
		//if(isinf(bc->blocks[ r1 ][ c1 ]->log_marginal_likelihood)||isinf(bc->blocks[ r2 ][ c2 ]->log_marginal_likelihood)) printf("\nThe marginal lieklihoods were inf on entry");
		l += (- bc->blocks[ r1 ][ c1 ]->log_marginal_likelihood
		  - bc->blocks[ r2 ][ c2 ]->log_marginal_likelihood);  
	}
	
	l += log(bc->margins[mrgn]->ng[gn] + bc->alpha) - log(bc->margins[mrgn]->ng[g]-1.+bc->alpha);

	return(l);
}

double compute_log_marginal_likelihood_block_with_inc_rm(struct bcluster *bc,int mrgn,double *x,int rcl,int ccl,int add)
{
	//If mrgn == 0, x is a row of the matrix. If mrgn == 1, x is a col of the matrix.
	double l;
	int j,sgn;
	
	int i,lim,idx1 =  bc->margins[0]->where_is[rcl], idx2 = bc->margins[1]->where_is[ccl] ;
	//copy source -->target
	//bc->model->copy_block(bc->blocks[ idx1 ][ idx2 ],blnew);
	// if updating rows, sum over columns already in block cluster and vica versa
	lim = bc->margins[1-mrgn]->ng[ rcl*mrgn + ccl*(1-mrgn) ];
	sgn = add ? 1 : -1;
	
	/*if(!bc->fp_debug)
	{
		fprintf(bc->fp_debug,"\n The block stats before adding: ");
		bc->model->print_stats(bc->blocks[idx1][idx2]->stats,bc->fp_debug);
		fprintf(bc->fp_debug,"\n\nx=[");
	}	*/
	
	if(bc->multivariate_model)
	{
		bc->model->add_to_stats_multivariate(x,bc->blocks[idx1][idx2]->stats,sgn);
	}
	else
	{
		for(i=0;i<lim;i++)
		{
			j = bc->margins[ 1-mrgn ]->idxz[ idx1*mrgn +(1-mrgn)*idx2 ][i];
			bc->model->add_to_stats(x[j],bc->blocks[idx1][idx2]->stats,sgn);
		}
	}

	l = bc->model->compute_log_marginal_likelihood_from_stats(bc->blocks[idx1][idx2]->stats,bc->model->hyperparameters);
	
	//put the block back to how it was
	sgn *= -1;
	
	if(bc->multivariate_model)
	{
		bc->model->add_to_stats_multivariate(x,bc->blocks[idx1][idx2]->stats,sgn);
	}
	else
	{
		for(i=0;i<lim;i++)
		{
			j = bc->margins[ 1-mrgn ]->idxz[ idx1*mrgn +(1-mrgn)*idx2 ][i];
			bc->model->add_to_stats(x[j],bc->blocks[idx1][idx2]->stats,sgn);
		}
	}
	
	return(l);
}

void move_to_new_component(struct bcluster *bc,int mrgn,double *x,int idx,int cl_old,int cl_new,int empty,int compute_marginal_likelihood)
{

	int i,j,ii,l,k,wg_old,wg_new,ng_new,ng_old;
	k = 1-mrgn;
	FILE *TT;
	
	
	wg_old = bc->margins[mrgn]->where_is[cl_old];
	wg_new = bc->margins[mrgn]->where_is[cl_new];
	
	bc->margins[mrgn]->z[idx] = cl_new;
	
	bc->margins[mrgn]->ng[cl_old] -= 1;
	bc->margins[mrgn]->ng[cl_new] += 1;
	
	ng_new = bc->margins[mrgn]->ng[cl_new];
	ng_old = bc->margins[mrgn]->ng[cl_old];
	
	//sum over the other margin
	for(i=0;i<bc->margins[k]->G;i++)
	{
		ii = bc->margins[k]->where_is[i];
		
		if(bc->multivariate_model)
		{
			//only add the entries in row clusters
			bc->model->add_to_stats_multivariate(x,bc->blocks[wg_old][ii]->stats,-1);
			bc->model->add_to_stats_multivariate(x,bc->blocks[wg_new][ii]->stats,1);
		}
		else
		{
			//update the statistics:: 2 cases
			for(j=0;j<bc->margins[k]->ng[i];j++)
			{
				/*if(bc->fp_debug)
				{
		
				}*/
				l = bc->margins[k]->idxz[ii][j];
				if(!mrgn) //add entries in column clusters
				{
					bc->model->add_to_stats(x[l],bc->blocks[wg_old][ii]->stats,-1);
					bc->model->add_to_stats(x[l],bc->blocks[wg_new][ii]->stats,1);

				}else{ //add entries in row clusters
					bc->model->add_to_stats(x[l],bc->blocks[ii][wg_old]->stats,-1);
					bc->model->add_to_stats(x[l],bc->blocks[ii][wg_new]->stats,1);
					/*if(bc->fp_debug)
					{
					
					}*/
				}
			
			}
		
		}
		
		if(!mrgn && compute_marginal_likelihood)
		{
			bc->blocks[wg_old][ii]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats( bc->blocks[wg_old][ii]->stats,bc->model->hyperparameters );
			bc->blocks[wg_new][ii]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats( bc->blocks[wg_new][ii]->stats,bc->model->hyperparameters );
		}else if(mrgn && compute_marginal_likelihood){
			bc->blocks[ii][wg_old]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats( bc->blocks[ii][wg_old]->stats,bc->model->hyperparameters );
			bc->blocks[ii][wg_new]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats( bc->blocks[ii][wg_new]->stats,bc->model->hyperparameters );
		}
			
	}

	
	bc->margins[mrgn]->idxz[wg_new][ ng_new-1 ] = idx;
	j=0;
	while( bc->margins[mrgn]->idxz[ wg_old ][j] != idx )
	{
		j += 1;
	}
	for(i=j;i<ng_old;i++)
	{
		bc->margins[mrgn]->idxz[ wg_old ][i] = bc->margins[mrgn]->idxz[ wg_old ][i+1];
	}
	
		
		
	if(empty)
	{
		//tidy up the old component
		/*for(i=0;i<bc->margins[k]->G;i++)
		{
			ii = bc->margins[k]->where_is[i];
			if(!mrgn){
				bc->model->reset_stats(bc->blocks[wg_old][ii]->stats);
			}else{
				bc->model->reset_stats(bc->blocks[ii][wg_old]->stats);
			}
		}*/
		//bc->margins[mrgn]->in_use[wg_old] = FALSE;
		
		if(bc->greedy)
		{
			//free up the block memory that's not needed anymore
			for(i=0;i<bc->margins[k]->G;i++)
			{
				ii = bc->margins[k]->where_is[i];
				if(!mrgn)
				{
					bc->model->destroy_block(bc->blocks[wg_old][ii]);
				}
				else
				{
					bc->model->destroy_block(bc->blocks[ii][wg_old]);
				}
			}
		}
		
		for(i=cl_old+1;i<bc->margins[mrgn]->G;i++)
		{
			j = bc->margins[mrgn]->where_is[i];
			bc->margins[mrgn]->where_is[i-1] = j;
			bc->margins[mrgn]->ng[i-1] = bc->margins[mrgn]->ng[i];
		}
		
		for(i=cl_old+1;i<bc->margins[mrgn]->G;i++)
		{
			for(j=0;j<bc->margins[mrgn]->n;j++)
			{
				if(bc->margins[mrgn]->z[j] == i) bc->margins[mrgn]->z[j] = i-1;
			}
		}
		
		bc->margins[mrgn]->G -= 1;
	}
	return;
}


void sparse_rep_move_to_new_component(struct bcluster *bc,int mrgn,int idx,int cl_old,int cl_new,int empty)
{
	
	int i,j,ii,z,k,wg_old,wg_new,ng_new,ng_old,r1,r2,c1,c2;
	int *numzero,*numnonzero,st,end;
	k = 1-mrgn;
	numzero = calloc(bc->margins[k]->G,sizeof(int));
	numnonzero = calloc(bc->margins[k]->G,sizeof(int));
	double **values;
	
	wg_old = bc->margins[mrgn]->where_is[cl_old];
	wg_new = bc->margins[mrgn]->where_is[cl_new];
	
	bc->margins[mrgn]->z[idx] = cl_new;
	
	bc->margins[mrgn]->ng[cl_old] -= 1;
	bc->margins[mrgn]->ng[cl_new] += 1;
	
	ng_new = bc->margins[mrgn]->ng[cl_new];
	ng_old = bc->margins[mrgn]->ng[cl_old];
	
	st = bc->margins[mrgn]->sparse_Y->p[idx];
	end = bc->margins[mrgn]->sparse_Y->p[idx+1];
	int nnz = end-st;
	values = calloc(bc->margins[k]->G,sizeof(double *));
	for(i=0;i<bc->margins[k]->G;i++)
	{
		values[i] = calloc(nnz,sizeof(double));
		numzero[i] = bc->margins[k]->ng[i];
	}

	for(i=st;i<end;i++)
	{	
		//get relevant non-zero row/col
		j = bc->margins[mrgn]->sparse_Y->i[ i ]; //this gives the position of the nz entry in row/col
		//get cluster that this belongs to
		z = bc->margins[1-mrgn]->z[ j ];
		numzero[z] -= 1;
		values[ z ][ numnonzero[z] ] = bc->margins[mrgn]->sparse_Y->x[ i ];
		numnonzero[z] += 1;			
	}

	switch(mrgn)
	{
		case 0:
			r1 = bc->margins[mrgn]->where_is[cl_old];
			r2 = bc->margins[mrgn]->where_is[cl_new];
		break;
		case 1:
			c1 = bc->margins[mrgn]->where_is[cl_old];
			c2 = bc->margins[mrgn]->where_is[cl_new];
		break;
	}
	
	for(i=0;i<bc->margins[k]->G;i++)
	{
		switch(mrgn)
		{
			case 0:
				c1 = bc->margins[k]->where_is[i];
				c2 = c1;
			break;
			case 1:
				r1 = bc->margins[k]->where_is[i];
				r2 = r1;
			break;
		}
		for(j=0;j<numnonzero[i];j++)
		{
			bc->model->add_to_stats(values[i][j],bc->blocks[r1][c1]->stats,-1);
			bc->model->add_to_stats(values[i][j],bc->blocks[r2][c2]->stats,1);
		}
		bc->model->add_zeros_to_stats(numzero[i],bc->blocks[r1][c1]->stats,-1);
		bc->model->add_zeros_to_stats(numzero[i],bc->blocks[r2][c2]->stats,1);
		
		bc->blocks[r1][c1]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(bc->blocks[r1][c1]->stats,bc->model->hyperparameters);
		bc->blocks[r2][c2]->log_marginal_likelihood = bc->model->compute_log_marginal_likelihood_from_stats(bc->blocks[r2][c2]->stats,bc->model->hyperparameters);
	}
	

	bc->margins[mrgn]->idxz[wg_new][ ng_new-1 ] = idx;
	j=0;
	while( bc->margins[mrgn]->idxz[ wg_old ][j] != idx )
	{
		j += 1;
	}
	for(i=j;i<ng_old;i++)
	{
		bc->margins[mrgn]->idxz[ wg_old ][i] = bc->margins[mrgn]->idxz[ wg_old ][i+1];
	}	
		
	if(empty)
	{

		if(bc->greedy)
		{
			//free up the block memory that's not needed anymore
			for(i=0;i<bc->margins[k]->G;i++)
			{
				ii = bc->margins[k]->where_is[i];
				if(!mrgn)
				{
					bc->model->destroy_block(bc->blocks[wg_old][ii]);
				}
				else
				{
					bc->model->destroy_block(bc->blocks[ii][wg_old]);
				}
			}
		}
		
		for(i=cl_old+1;i<bc->margins[mrgn]->G;i++)
		{
			j = bc->margins[mrgn]->where_is[i];
			bc->margins[mrgn]->where_is[i-1] = j;
			bc->margins[mrgn]->ng[i-1] = bc->margins[mrgn]->ng[i];
		}
		
		for(i=cl_old+1;i<bc->margins[mrgn]->G;i++)
		{
			for(j=0;j<bc->margins[mrgn]->n;j++)
			{
				if(bc->margins[mrgn]->z[j] == i) bc->margins[mrgn]->z[j] -= 1;
			}
		}
		
		bc->margins[mrgn]->G -= 1;
	}
	return;

	free(numzero);
	free(numnonzero);
	for(i=0;i<bc->margins[k]->G;i++) free(values[i]);
	free(values);
}


double get_log_normalizing_constant_margin(struct bcluster *bc,int mrgn,int G)
{
	//this returns the normalizing constant over a margin
	double l = lgamma(bc->alpha*G) - G*lgamma(bc->alpha) - lgamma(bc->margins[mrgn]->n + bc->alpha*G);
	return(l);
}

double get_full_log_posterior_of_model(struct bcluster *bc)
{
	int i,j,m;
	double l=0.;
	
	for(m=0;m<bc->nmargin;m++)
	{
		for(i=0;i<bc->margins[m]->G;i++)
		{
			if(!m)
			{
				for(j=0;j<bc->margins[1-m]->G;j++)
				{
					//only executed for m==0
					l += bc->blocks[ bc->margins[m]->where_is[i] ][ bc->margins[1-m]->where_is[j] ]->log_marginal_likelihood;
				}
			}
			
			l += lgamma(bc->margins[m]->ng[i]+bc->alpha);
		}
		l += lgamma(bc->alpha*bc->margins[m]->G) - bc->margins[m]->G*lgamma(bc->alpha) 
				- lgamma(bc->margins[m]->n + bc->alpha*bc->margins[m]->G);
	}
	return(l);
}


/********************** handling of the results and chain outputs ***********************/

struct results ** set_up_results(struct bcluster *bc,int nstored)
{
	int i;
	struct results **Result = (struct results **)malloc(bc->nmargin*sizeof(struct results *));
	for(i=0;i<bc->nmargin;i++) Result[i] = allocate_results(bc->margins[i],nstored);
	return(Result);
}

void tidy_up_results(struct bcluster *bc,struct results **Result)
{
	int i;
	for(i=0;i<bc->nmargin;i++) free_results(Result[i]);
	free(Result);
}


struct results * allocate_results(struct margin *margin,int nstored)
{
	int i;
	struct results *results = (struct results *)malloc(sizeof(struct results));
	results->n = margin->n;
	results->nstored = nstored;
	results->labels = calloc(nstored,sizeof(int *));
	for(i=0;i<nstored;i++) results->labels[i] = calloc(margin->n,sizeof(int));
	results->ngroups = calloc(nstored,sizeof(int));
	return(results);
}

void free_results(struct results *results)
{
	int i;
	for(i=0;i<results->nstored;i++)
	{
		free(results->labels[i]);
	}
	free(results->labels);
	free(results->ngroups);
	free(results);
	return;
}

void write_to_results(struct results *results,struct margin *margin,int idx)
{
	int i;
	/*if(debug) printf("\n in here in idx = %d",idx);
	if(debug) printf("\n in here in idx = %d",idx);*/
	for(i=0;i<margin->n;i++)
	{
		results->labels[idx][i] = margin->z[i];
	}
	results->ngroups[idx] = margin->G;
	return;
}

/*void write_results_to_file(struct results *results,FILE *fp_labels,FILE *fp_ngroups)
{
	//fp is open stream
	int i,j;
	for(i=0;i<results->nstored;i++)
	{
		for(j=0;j<results->n;j++)
		{
			fprintf(fp_labels,"%d ",results->labels[i][j]);
		}
		fprintf(fp_labels,"\n");
		fprintf(fp_ngroups,"%d\n",results->ngroups[i]);
	}
	return;
}*/

/*************************************************************************************/

/******************* utilities ****************************/

double get_max(double *x,int len)
/*returns maximum of a vector x*/
{
	int i;
	double max=x[0];
	
	if(len > 1){
		for(i=1;i<len;i++){
			if(x[i]>max)
				max = x[i];
		}
	
	}
	return(max);
}

double get_min(double *x,int len)
/*returns maximum of a vector x*/
{
	int i;
	double min=x[0];
	
	if(len > 1){
		for(i=1;i<len;i++){
			if(x[i]<min)
				min = x[i];
		}
	
	}
	return(min);
}

/*int get_imax(int *x,int len)
//returns maximum of a vector x
{
	int i;
	int max=x[0];
	
	if(len > 1){
		for(i=1;i<len;i++){
			if(x[i]>max)
				max = x[i];
		}
	
	}
	return(max);
}*/


int sample_discrete( double *weights, int len )
{
	/*sample once from a multinomial distribution with weights*/
	
	int i=0;
	double w , u;
	
	u = runif(0.0,1.0) ;
	
	w = weights[0];
	
	while( w < u && i < len )
	{
		i++ ;
		w += weights[i];		
	}
	
	return(i);	
}

/*********************** Debugging************************************/



int check_membership_counts_against_labels(struct bcluster *bc,int mrgn)
{
	int i,j,*n;
	n = calloc(bc->margins[mrgn]->G,sizeof(int));
	for(i=0;i<bc->margins[mrgn]->n;i++)
	{
		n[ bc->margins[mrgn]->z[i] ] += 1;
	}
	for(i=0;i<bc->margins[mrgn]->G;i++)
	{
		for(j=0;j<n[i];j++)
		{
			//printf(" %d ",bc->margins[mrgn]->idxz[bc->margins[mrgn]->where_is[i]][j]);
			if(bc->margins[mrgn]->z[ bc->margins[mrgn]->idxz[bc->margins[mrgn]->where_is[i]][j] ] != i){
			free(n);
			//printf("\nCheck failed in first part");
			return(1);
			}
		}
		//printf("\n");
	}	
	//free(n);
	//return(1);
	
	for(i=0;i<bc->margins[mrgn]->G;i++)
	{
		if(n[i] != bc->margins[mrgn]->ng[i]){
			free(n);
			return(1);
		}
	}
	free(n);
	return(0);
}


int compute_check_stats(struct bcluster *bc,void *compare_stats)
{
	//computes a check on the block statistics for all blocks
	//	for comparison with sum at beginning. This can be used
	// to debug the moves
	
	int i,j,k,l;
	struct block *blnew = bc->model->create_new_block(bc->model->dimensions);
	
	for(i=0;i<bc->margins[0]->G;i++)
	{
		k = bc->margins[0]->where_is[i];
		for(j=0;j<bc->margins[1]->G;j++)
		{
			l = bc->margins[1]->where_is[j];
			bc->model->add_block_stats(bc->blocks[k][l]->stats,blnew->stats);	
		}
	}
	
	i = bc->model->compare_stats(blnew->stats,compare_stats);
	bc->model->destroy_block(blnew);
	//i is 0 if stats equal, and i if unequal
	return(i);
}

/* a util to permute a vector  */
void random_ranshuffle( int *a, int n )
{
	//randomly permute the first n elements of a using Fisher-Yates algorithm
	//  using RNG from R
	
	int i, j, x;
	
	for( i=n-1; i>0; i-- )
	{
		j = (int)( i * runif(0.0,1.0) ) ;
		x = a[i] ;
		a[i] = a[j] ;
		a[j] = x;
	}
	
	return;
}
