#==================================================================
#	Code accompanying the paper: 
#		Wyse J, Friel N, Latouche P (2015) 
#		Inferring structure in bipartite networks 
#		using the latent block model and exact ICL
#		arXiv TR id 1404.2911	
#		
#	Author: 
#		Jason Wyse, 
#		Discipline of Statistics,
#		School of Computer Science and Statistics,
#		Trinity College Dublin,
#		Dublin 2, Ireland
#		e-mail: wyseja@tcd.ie
#
#	Last update:
#		Fri 16 Oct 2015 04:15:52 PM IST 
#
#	This file:
#		Run the greedy algorithm in sparse and reduced complexity form
#		for the congressional voting dataset
#==================================================================


library( bibloco )

data( congressional )

congressional <- as.matrix( congressional )

params = list(ncat=2,alpha=1,beta=1)

#compute sparse form
iidx = NULL
jidx = NULL
x = NULL

for(i in 1:nrow(congressional))
{
	for(j in 1:ncol(congressional))
	{
		if(congressional[i,j] == 1)
		{
			iidx = c(iidx,i)
			jidx = c(jidx,j)
			x = c(x,congressional[i,j])
		}
	}
}

params = list(ncat=2,alpha=1,beta=1)


result = matrix(0,nrow=4,ncol=4)
rownames(result) = c("A0","A1","A2","A3")
colnames(result) = c("max ICL","average run time","K","G")

#A0 
fit0 = bibloco.fit( congressional , model.type = "Bernoulli", model.params = params, init.groups=c(100, ncol(congressional)), init.type = 0, n.runs = 10, n.restarts  = 2, use.same.seed = TRUE, keepICL = FALSE)
result[1,] = c(fit0$maxICL,fit0$avtime[3],fit0$ngroups)

#equivalent in MCMC
fit0 = bibloco.fit( congressional , model.type = "Bernoulli", model.params = params, init.groups=c(100, ncol(congressional)), max.groups=c(100, ncol(congressional)), init.type = 0, alg.type="MCMC")
result[1,] = c(fit0$maxICL,fit0$avtime[3],fit0$ngroups)

#A1 
fit1 = bibloco.fit(model.type = "Bernoulli", model.params = params, init.groups = c(100,ncol(congressional)), init.type = 0, sparse = TRUE, matrix.dims = c(nrow(Co), ncol(Co)), row.index = iidx-1, col.index = jidx-1, values = x,n.runs=10, n.restarts = 2, use.same.seed = TRUE, keepICL = FALSE)
result[2,] = c(fit1$maxICL,fit1$avtime[3],fit1$ngroups)

#A2
fit2 = bibloco.fit(model.type = "Bernoulli", model.params = params , init.groups = c(100,ncol(congressional)), init.type = 0, n.runs = 10, n.restarts = 2, greedy.fast = TRUE, use.same.seed = TRUE, keepICL = FALSE)
result[3,] = c(fit2$maxICL,fit2$avtime[3],fit2$ngroups)

#A3
fit3 = bibloco.fit(congressional, model.type = "Bernoulli", model.params = params,init.groups = c(100,ncol(congressional)), init.type = 0, sparse = TRUE, matrix.dims = c(nrow(congressional), ncol(congressional)), row.index = iidx-1, col.index = jidx-1, values = x, greedy.fast = TRUE, n.runs = 10, n.restarts=2, use.same.seed = TRUE, keepICL = FALSE)
result[4,] = c(fit3$maxICL,fit3$avtime[3],fit3$ngroups)

print(result)




