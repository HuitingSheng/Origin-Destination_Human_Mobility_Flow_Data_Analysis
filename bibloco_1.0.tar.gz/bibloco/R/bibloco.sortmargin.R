#--------------------------------------------------------------------
#
# file: bibloco.sortmargin.R
#
# Functions to perform block clustering for bipartite networks and 
#	data matrices exact ICL and MCMC.
#
#	Author:	Jason Wyse, 
#			School of Computer Science and Statistics,
#			Trinity College Dublin,
#			Dublin 2, Ireland.
#			email: wyseja@tcd.ie
#			
#Last modified: Fri 06 May 2016 06:01:57 IST 
#
#---------------------------------------------------------------------

bibloco.sortmargin <- function(labels)
{
	#---------------------------------------------
	#	sort the margins in order of cluster size
	# 	for plotting 
	#---------------------------------------------
	
	xx <- list()
	xx$cluster.members <- list()
	G <- max(labels)
	ng <- numeric(G)

	for(i in 1:G)
	{
		ng[i] <- length(which(labels==i))
	}
	t <- sort(ng,index.return=TRUE,decreasing=TRUE)
	if(G > 1) prorder <- (1:G)[t$ix] else prorder <- 1
	order <- NULL
	for(i in 1:G)
	{
		order <- c(order,which(labels == prorder[i]))
		xx$cluster.members[[i]] <- which(labels == prorder[i])
	}	
	xx$order = order
	
	return(xx)
}

