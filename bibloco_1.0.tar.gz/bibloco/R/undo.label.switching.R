#=========================================================
#	Implementation of the label switching algorithm
#	of Nobile and Fearnside (2007) Statistics & Computing.
#
#	Author of this implementation:
#		Jason Wyse,
#		Discipline of Statistics,
#		School of Computer Science and Statistics,
#		Trinity College Dublin,
#		Dublin 2, Ireland.
#
#	Last update:
#		Fri 06 May 2016 06:00:25 IST 
#=========================================================


undo.label.switching = function(labels,ngroups)
#undo label switching using Nobile and Fearnside approach
{
  
    
    #different no.'s groups
    
    nobs = ncol(labels)
    
    G = unique(ngroups)
    
    ret = list()
    ret$groups = ngroups
    ret$ncomponents = numeric(length(G))
    ret$item.tags = list()
    
    j = 1
    
    for(k in G){
      
      idx.k = which(ngroups == k)
      labels.k = labels[idx.k,]
      
      nsamp.k = length(idx.k)
      ngrp.k = k

      if((k!=1) && (length(idx.k) > 1)){
        
        nonempty.k = apply(labels.k,1,function(x) length(unique(x)))
        t.k = sort(nonempty.k,index.return=TRUE)
        
        labels.arranged.k = labels.k[t.k$ix,]
        
        item.tags.k = idx.k[t.k$ix] #this is to keep track of the variable indicator for prediction or marginal calculation
        
        labels.out.k = numeric(nsamp.k*nobs)
        
        w = .C("Relabel",as.integer(nobs),as.integer(nsamp.k),as.integer(ngrp.k),as.integer(labels.arranged.k),x=as.integer(labels.out.k), PACKAGE = "bibloco" )
        
        
        ret$ncomponents[j] = k
        ret$memberships[[j]] = matrix(w$x,nrow = nsamp.k,ncol=nobs,byrow=FALSE)
        
        #compute membership probabilities for each data pt
        
        probs = matrix(nrow=nobs,ncol=k)
        for(id in 1:nobs){
        	for(c in 1:k){
        		probs[id,c] = length(which(ret$memberships[[j]][,id] == c))
        	}
        }
        
        probs = probs/nsamp.k
        
        ret$membership.probabilities[[j]] = probs
 
        #for variable indicator
		  ret$item.tags[[j]] = item.tags.k        
        
      }else{
        
        ret$ncomponents[j] = k
        ret$memberships[[j]] = labels.k
        
        idx.k = which(ngroups == k)
        ret$item.tags[[j]] = idx.k #only in this case
        
      }
      
      j = j+1
      
    }
    
    return(ret)
    
  
  
}

