#--------------------------------------------------------------------
#
# file: plot.bibloco.R
#
# Functions to perform block clustering for bipartite networks and 
#	data matrices exact ICL and MCMC.
#
#	Author:	Jason Wyse, 
#			School of Computer Science and Statistics,
#			Trinity College Dublin,
#			Dublin 2, Ireland.
#			email: wyseja@tcd.ie
#			
#Last modified: Fri 06 May 2016 06:01:17 IST 
#
#---------------------------------------------------------------------

plot.bibloco <- function(xx,aspect=1,r.names="Row",c.names="Column",title="Re-ordered matrix")
{
	
	#--------------------------------------------
	# 	plot the result of the bibloco clustering
	#--------------------------------------------

	if( class(xx) != "bibloco" ) stop("\nObject not of class 'bibloco' ")

	indexesr <- xx$plotting$rows$order
	indexesc <- xx$plotting$columns$order
	
	if(xx$args$sparse == FALSE)
	{
		Y <- xx$args$Y[indexesr,indexesc]
		Y <- as.matrix(Y)
		X <- Matrix(Y)
		if(xx$args$model.type=="Bernoulli"){
			image(X,main=title,sub="",xlab=c.names,ylab=r.names,aspect=aspect)
		}else if(xx$args$model.type=="Multinomial"){
			image(X,main=title,xlab=c.names,ylab=r.names,sub="",aspect=aspect)
		}else{
			image(X,xlab=c.names,ylab=r.names,sub="",aspect=aspect,main=title)
		}
	}else{
		nnz <- length(xx$args$row.index)
		iidx <- numeric(nnz)
		jidx <- numeric(nnz)
		v <- numeric(nnz)
		for(i in 1:nnz)
		{
			iidx[i] <- which(indexesr == xx$args$row.index[i]+1)
			jidx[i] <- which(indexesc == xx$args$col.index[i]+1)
			v[i] <- xx$args$values[i]
		}
		
		X <- spMatrix(nrow=xx$args$matrix.dims[1],ncol=xx$args$matrix.dims[2],i=iidx,j=jidx,x=v)
		image(X,main=title,sub="",xlab=c.names,ylab=r.names,aspect=aspect)
	}
	
}
