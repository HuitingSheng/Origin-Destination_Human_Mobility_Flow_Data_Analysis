#--------------------------------------------------------------------
#
# file: bibloco.fit.R
#
# Functions to perform block clustering for bipartite networks and 
#	data matrices exact ICL and MCMC.
#
#	Author:	Jason Wyse, 
#			School of Computer Science and Statistics,
#			Trinity College Dublin,
#			Dublin 2, Ireland.
#			email: wyseja@tcd.ie
#			
#Last modified: Fri 06 May 2016 06:00:56 IST 
#
#---------------------------------------------------------------------


bibloco.fit <- function( data = NULL, model.type, model.params, alg.type="greedy",  init.type = 0, init.groups = NULL, max.groups = NULL, rlab.init = NULL, clab.init = NULL, greedy.merge = TRUE, greedy.fast = FALSE, fixed.groups=FALSE, n.iterations = 6000, n.burn = 1000, thin.by = 1, only.gibbs = FALSE,  sparse = FALSE, matrix.dims = NULL, row.index = NULL, col.index = NULL, values = NULL, n.runs=1, n.restarts=0, delta=0.05, merge.thresh =  0., keepICL = TRUE, n.margin = 2 )
{
	#-------------------------------------------------------------------
	#	methods to bi-cluster a data matrix using model based approaches
	#	using either greedy search with exact ICL or MCMC 
	#-------------------------------------------------------------------
	
	Y <- data
	
	if(!is.matrix(Y) && !sparse)
	{
		if( !is.vector(Y) ) stop("\nData must be numeric type or appropriately coded.")
	}
	
	if( is.vector(Y) ) Y <- matrix( Y , nrow=length(Y) , ncol=1 )

	
	if(alg.type == "MCMC" && sparse) stop("\nSparse methods for MCMC based algorithm not available.")
	if(!sparse)
	{	
		nrow <- nrow(Y)
		ncol <- ncol(Y)
	}else{
		nrow <- matrix.dims[1]
		ncol <- matrix.dims[2]
		
		if(is.null(row.index) || is.null(col.index)||is.null(values))
			stop("\nIf using sparse representation give all information!")
	}
	#check row dimension and decide on hard tolerance satisfaction or not
	hardtol <- TRUE
	if(sparse && (nrow > 2000 || ncol > 2000)) hardtol <- FALSE
	
	if(is.null(init.groups)) init.groups <- c(nrow,ncol)
	
	if(is.null(max.groups)) max.groups <- c(nrow,ncol)
	
	if(is.null(model.params)) stop("\nPlease provide parameterization for the model.")
	
	if(model.type == "Multinomial"||model.type=="Bernoulli")
	{
		modty <- 0
		hyperparams <- numeric(3)
		hyperparams[1] <- model.params$alpha
		hyperparams[2] <- model.params$ncat
		hyperparams[3] <- model.params$beta
		dimensions <- numeric(2)
		dimensions[1] <- model.params$ncat
		sample.hyperparameters <- FALSE
	}else if(model.type == "Gaussian"){
		modty <- 1
		hyperparams <- numeric(5)
		hyperparams[1] <- model.params$alpha
		hyperparams[2] <- model.params$kappa
		hyperparams[3] <- model.params$delta
		hyperparams[4] <- model.params$gamma
		hyperparams[5] <- model.params$xi
		dimensions <- numeric(2)
		sample.hyperparameters <- FALSE
	}else if(model.type=="Poisson"){
		modty <- 2
		hyperparams <- numeric(3)
		hyperparams[1] <- model.params$alpha
		hyperparams[2] <- model.params$delta
		hyperparams[3] <- model.params$gamma
		dimensions <- numeric(2)
		sample.hyperparameters <- FALSE
	}else if(model.type=="MV Gaussian"){
		modty <- 3
		dimen <- length(model.params$xi)
		hyperparams <- numeric(4+dimen)
		hyperparams[1] <- model.params$alpha
		hyperparams[2] <- model.params$kappa
		hyperparams[3] <- model.params$delta
		hyperparams[4] <- model.params$gamma
		hyperparams[5:(4+dimen)] <- model.params$xi
		dimensions <- numeric(2)
		dimensions[1] <- dimen
	}else{
		stop("\nOnly support for multinomial type models at the moment!")
	}
	
	if(init.type==0 && !(init.groups[1]==1 && init.groups[2]==1))
	{
		#initialize randomly
		Ginitr <- init.groups[1]
		Ginitc <- init.groups[2]
	
		rlab.init <- sample(1:Ginitr,size=nrow,replace=TRUE)-1
		clab.init <- sample(1:Ginitc,size=ncol,replace=TRUE)-1
		init.type <- 0
	}else if(init.groups[1] == 1 && init.groups[2] == 1)
	{
		Ginitr <- init.groups[1]
		Ginitc <- init.groups[2]
		rlab.init <- rep(0,nrow)
		clab.init <- rep(0,ncol)
		init.type <- 1
	}else if( init.groups[2] == 1 && n.margin == 1)
	{
		Ginitr <- init.groups[1]
		init.groups[2] <- 1
		rlab.init <- sample(1:Ginitr,size=nrow,replace=TRUE)-1
		clab.init <- rep(0,ncol)
		init.type <- 1
	}	
	
	if(alg.type=="MCMC")
	{
		N <- (n.iterations-n.burn)/thin.by
		r.memberships <- numeric(N*nrow)
		c.memberships <- numeric(N*ncol)
		r.ngroups <- numeric(N)
		c.ngroups <- numeric(N)
		l.posterior <- numeric(N)
		acc.rates <- numeric(10)
	}else{
		r.memb.gr <- numeric(nrow)
		c.memb.gr <- numeric(ncol)
		ICL.min <- 0.
		ICL.max <- 0.
		ICL.store <- numeric(n.runs)
	}
	
	#now redundant-- legacy purposes
	use.same.seed <- 0
	
	tstart <- proc.time()
	
	if(alg.type == "MCMC")
	{
		res <- .C(	"bcluster_mcmc_R", 					as.double(Y), 
					as.integer(nrow), 					as.integer(ncol), 
					as.integer(modty), 					as.integer(max.groups), 
					as.integer(init.groups), 			as.integer(rlab.init), 
					as.integer(clab.init), 				as.integer(init.type), 
					as.double(hyperparams), 			as.integer(n.iterations), 
					as.integer(n.burn), 				as.integer(thin.by), 
					as.integer(only.gibbs), 			as.integer(fixed.groups), 
					as.integer(sparse), 				as.integer(row.index), 
					as.integer(col.index), 				as.double(values), 
					as.integer(length(row.index)), 
					r.res = as.integer(r.memberships), 	r.ngrps = as.integer(r.ngroups), 
					c.res = as.integer(c.memberships), 	c.ngrps = as.integer(c.ngroups), 
					as.double(l.posterior), 			acc = as.double(acc.rates), 
					as.integer(use.same.seed), 			as.integer(n.margin),
					as.integer(dimensions),				as.integer(sample.hyperparameters),
					PACKAGE = "bibloco" )
	}else if(init.type != 2){
	
		res <- .C(	"bcluster_greedy_R", 				as.double(Y), 
					as.integer(nrow), 					as.integer(ncol), 
					as.integer(modty), 					as.integer(init.groups), 
					as.integer(init.groups), 			as.integer(rlab.init), 
					as.integer(clab.init), 				as.integer(init.type), 
					as.integer(greedy.merge), 			as.double(hyperparams), 
					as.integer(greedy.fast), 			as.integer(n.runs), 
					as.integer(n.restarts), 			as.integer(sparse), 
					as.integer(row.index), 				as.integer(col.index), 
					as.double(values), 					as.integer(length(row.index)), 
					r.res = as.integer(r.memb.gr), 		c.res = as.integer(c.memb.gr), 
					ICL = as.double(numeric(2)),		as.integer(hardtol), 
					as.integer(use.same.seed), 			as.integer(keepICL), 
					ICL.store = as.double(ICL.store), 	as.double(delta), 
					as.integer(n.margin),				as.integer(dimensions),
					as.double(merge.thresh),
					PACKAGE = "bibloco" )
	}else if(init.type == 2){
		
		if(keepICL) ICL.store.0 <- ICL.store
		
		# this is necessary to reinitialize each time using spectral clustering algorithm of Rohe & Yu (2015)
		for(r in 1:n.runs)
		{
			#initialize
			#spec.init <- regspec( Y , k=c(init.groups[1],init.groups[2]), tau=-1 , quiet=1 ) 
		
			Ginitr <- init.groups[1]
			Ginitc <- init.groups[2]
		
			rlab.init <- spec.init$uclst - 1
			clab.init <- spec.init$vclst - 1
			
			#run
			res <- .C(	"bcluster_greedy_R", 			as.double(Y), 
						as.integer(nrow), 				as.integer(ncol), 
						as.integer(modty), 				as.integer(init.groups), 
						as.integer(init.groups), 		as.integer(rlab.init), 
						as.integer(clab.init), 			as.integer(init.type), 
						as.integer(greedy.merge), 		as.double(hyperparams), 
						as.integer(greedy.fast), 		as.integer(1), 
						as.integer(n.restarts), 		as.integer(sparse), 
						as.integer(row.index), 			as.integer(col.index), 
						as.double(values), 				as.integer(length(row.index)), 
						r.res = as.integer(r.memb.gr), 	c.res = as.integer(c.memb.gr), 
						ICL = as.double(numeric(2)),	as.integer(hardtol), 
						as.integer(use.same.seed), 		as.integer(keepICL), 
						ICL.store = as.double(ICL.store), 
						as.double(delta), 				as.integer(n.margin),
						as.integer(dimensions),
						PACKAGE = "bibloco"  )
			
			if(keepICL) ICL.store.0[r] <- res$ICL.store[1]
			
		}
		
		
	}
	
	tend <- proc.time()
	
	#----------------------------------
	#	collect call details and result
	#----------------------------------
	
	xx <- list()
	xx$args <- c(as.list(environment()))
	
	xx$times <- list()
	
	if(alg.type == "MCMC")
	{
	
		xx$rows <- list()
		xx$cols <- list()
		xx$rows$memberships <- matrix(res$r.res,nrow=N,ncol=nrow,byrow = TRUE) + 1
		xx$rows$ngroups <- res$r.ngrps
		xx$rows$acc_rt_m1 <- res$acc[1]
		xx$rows$acc_rt_m2 <- res$acc[2]
		xx$rows$acc_rt_m3 <- res$acc[3]
		xx$rows$acc_rt_eject <- res$acc[4]
		xx$rows$acc_rt_absorb <- res$acc[5]
		xx$cols$memberships <- matrix(res$c.res,nrow=N,ncol=ncol,byrow=TRUE) + 1
		xx$cols$ngroups <- res$c.ngrps
		xx$cols$acc_rt_m1 <- res$acc[6]
		xx$cols$acc_rt_m2 <- res$acc[7]
		xx$cols$acc_rt_m3 <- res$acc[8]
		xx$cols$acc_rt_eject <- res$acc[9]
		xx$cols$acc_rt_absorb <- res$acc[10]
	
		tstart.ls = proc.time()
	
		xx$rows$label.swap <- undo.label.switching(xx$rows$memberships,xx$rows$ngroups)
		xx$cols$label.swap <- undo.label.switching(xx$cols$memberships,xx$cols$ngroups)
	
		tend.ls = proc.time()
	
		#xx$times$labelswap <- tend-tstart
	
		xx$MAP = list()
	
		#find the MAP for plotting a summary of the MCMC run
		idx.map <- which.max(l.posterior)
		if(length(idx.map > 1)) idx.map <- idx.map[1]
		K.map <- xx$rows$ngroups[idx.map]
		G.map <- xx$cols$ngroups[idx.map]
	
		xx$MAP$ngroups.rows <- K.map
		xx$MAP$ngroups.cols <- G.map


	  #find the two level MAP - MAP(K,G) then conditional labels
	  # this repeats the analysis in Wyse and Friel (2012) STCO 
	  
		xx$MAP_1 = list()
	  
	  #compute the joint K,G distribution
	  Kmin <- min(xx$rows$ngroups)
	  Kmax <- max(xx$rows$ngroups)
	  Gmin <- min(xx$cols$ngroups)
	  Gmax <- max(xx$cols$ngroups)
	  jt <- matrix(0,nrow=Kmax-Kmin+1,ncol=Gmax-Gmin+1)
	  for(i in Kmin:Kmax){
		 for(j in Gmin:Gmax){
		   r <- sum( (xx$rows$ngroups == i) * (xx$cols$ngroups == j)  )
		   jt[i-Kmin+1,j-Gmin+1] <- r/N
		 }
	  }
	  rownames(jt) <- Kmin:Kmax
	  colnames(jt) <- Gmin:Gmax
	  
	  m <- apply(jt,1,max)
	  kh <- which.max(m)
	  gh <- which.max(jt[kh,])
	  
	  	xx$MAP_1$max_joint <- as.numeric(c(rownames(jt)[kh],colnames(jt)[gh]))
	  	xx$MAP_1$joint <- jt
	  	
	  	retmax <- function(w)
		{
			ww <- which.max(w)
			if(length(ww)>1) ww <- ww[1]
			return(ww)
		}
	  	
	  	if(xx$MAP_1$max_joint[1] == 1)
	  	{
	  		zr = rep(1,nrow)
	  	
	  	}else{
	  
			p <- xx$rows$label.swap
			j <- which(p$ncomponents == xx$MAP_1$max_joint[1])
			idx <- which(p$item.tags[[j]] == idx.map)
			if(length(idx)>1) idx <- idx[1]
			zr <- apply(p$membership.probabilities[[j]],1,function(x) retmax(x))
		}
	
		if(xx$MAP_1$max_joint[2] == 1)
		{
			zc <- rep(1,ncol)
		}else{
	
			q <- xx$cols$label.swap
			l <- which(q$ncomponents == xx$MAP_1$max_joint[2])
			jdx <- which(q$item.tags[[l]] == idx.map)
			zc <- apply(q$membership.probabilities[[l]],1,which.max)
	
		}
	
	
		xx$MAP_1$row.membership <- zr
		xx$MAP_1$col.membership <- zc
		
		# timings from the run
		
		xx$times$MCMC <- tend - tstart
		xx$times$label.switching <- tend.ls - tstart.ls
		if(n.runs > 1) xx$avtime <- (tend - tstart)/n.runs
	
	}else{
	
		#this is for the greedy algorithm
		
		xx$minICL <- res$ICL[1]
		xx$maxICL <- res$ICL[2]
		xx$ngroups = c(max(res$r.res)+1,max(res$c.res)+1)
		if(init.type != 2  && keepICL) xx$ICL.store = res$ICL.store else if( keepICL) xx$ICL.store = ICL.store.0
		
		zr <- res$r.res+1
		zc <- res$c.res+1
		
		xx$times$greedy.search <- tend - tstart
		if(n.runs > 1) xx$avtime <- (tend - tstart)/n.runs
	
	}
  
  	xx$row.membership <- zr
   xx$col.membership <- zc
   
	if(length(unique(zr))>1){
		xr <- bibloco.sortmargin(zr)
	}else{
		xr <- bibloco.sortmargin(zr)
	}
	if(length(unique(zc))>1){
		xc <- bibloco.sortmargin(zc)	
	}else{
		xc <- bibloco.sortmargin(zc)
	}
	
	xx$plotting <- list()
	xx$plotting$rows <- xr
	xx$plotting$columns <- xc
   
	class(xx) <- "bibloco"

	return(xx)
		
}
