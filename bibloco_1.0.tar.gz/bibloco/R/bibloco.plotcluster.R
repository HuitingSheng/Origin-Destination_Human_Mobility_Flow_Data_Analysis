#--------------------------------------------------------------------
#
# file: bibloco.plotcluster.R
#
# Functions to perform block clustering for bipartite networks and 
#	data matrices exact ICL and MCMC.
#
#	Author:	Jason Wyse, 
#			School of Computer Science and Statistics,
#			Trinity College Dublin,
#			Dublin 2, Ireland.
#			email: wyseja@tcd.ie
#			
#Last modified: Fri 06 May 2016 06:01:38 IST 
#
#---------------------------------------------------------------------

bibloco.plotcluster <- function(xx,aspect=1,rowcl=1,colcl=1)
{

	#-------------------------------------------------------
	#	Extract and plot a specific row-column (k,g) cluster
	#-------------------------------------------------------
	
	indexesr <- NULL
	for(i in rowcl) indexesr <- c(indexesr,xx$plotting$rows$cluster.members[[i]])
	indexesc <- NULL
	for(i in colcl) indexesc <- c(indexesc,xx$plotting$columns$cluster.members[[i]])
	
	if(xx$args$sparse == FALSE)
	{
		X <- Matrix(xx$args$Y[indexesr,indexesc])
	
		if(xx$args$model.type=="Bernoulli"){
			image(X,main="Re-ordered matrix",sub="",aspect=aspect)
		}else if(xx$args$model.type=="Multinomial"){
			image(X,main="Re-ordered matrix",sub="",aspect=aspect)
		}else{
			image(X,main="Re-ordered matrix",sub="",aspect=aspect)
		}
	}else{
	
		row.index <- xx$args$row.index+1
		col.index <- xx$args$col.index+1
		r <- intersect(indexesr,row.index)
		c < intersect(indexesc,col.index)
	
		if(length(r)==0 || length(c) == 0)
			stop("\nEither there are no rows or no columns in this cluster... funny...")
		
		check <- function(x)
		{
			any(r==x[1]) + any(c==x[2])
		}
		mat <- cbind(row.index,col.index)
		k0 <- apply(mat,1,function(x) check(x))	
		k <- which(k0 == 2)
		#extract the rows k that matter
		iidx <- row.index[k]
		jidx <- col.index[k]
		nv <- xx$args$values[k]
		niidx <- numeric(length(iidx))
		njidx <- niidx
		uiidx <- unique(iidx)
		ujidx <- unique(jidx)
		for(i in 1:length(uiidx))
		{
			w <- which(iidx == uiidx[i])
			niidx[w] <- i
		}
		for(i in 1:length(ujidx))
		{
			w <- which(jidx == ujidx[i])
			njidx[w] <- i
		}
		X <- spMatrix(nrow=length(indexesr),ncol=length(indexesc),i=niidx,j=njidx,x=nv)
		str <- paste("Row cluster ",rowcl," Col cluster ",colcl,sep="")
		image(X,main=str,sub="",aspect=aspect,)
	}
	
}
